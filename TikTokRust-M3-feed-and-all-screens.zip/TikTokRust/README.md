# TikTok Rust — этапы 1–3

Нативный Android: Kotlin + Jetpack Compose, minSdk 26. Модули `:app` и `:core`.

1. Android Studio, JDK 17: `File → Open` → папка проекта → Sync → Run.
2. Тесты ядра: `./gradlew :core:test`.
3. Превью без запуска: `ui/screens/Screens.kt` → `GalleryPreview`.

Все экраны реализованы: лента, плеер, поиск, профиль, друзья, входящие, создание, настройки, функции мода, темы, загрузки, о приложении.
Возможности и ограничения: `docs/FEATURES.md`. Что разрешает TikTok: `docs/TIKTOK_API_NOTES.md`. Rust: `rust/README.md`.
Бренд: `app/src/main/res/values/brand.xml` и `drawable/ic_launcher_foreground.xml`.
