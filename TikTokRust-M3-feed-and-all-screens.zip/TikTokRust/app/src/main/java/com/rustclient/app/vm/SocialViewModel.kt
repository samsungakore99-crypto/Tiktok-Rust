package com.rustclient.app.vm

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.annotation.DrawableRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rustclient.app.R
import com.rustclient.app.data.PostRecord
import com.rustclient.app.data.Social
import com.rustclient.app.data.SocialStore
import com.rustclient.app.data.Toasts
import com.rustclient.core.MediaKind
import com.rustclient.core.MediaVariant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

/** What the full-screen player should show. Set before navigating to the player route. */
data class PlayerRequest(
    val title: String,
    val kind: MediaKind,
    val variants: List<MediaVariant>,
    @DrawableRes val photoRes: Int? = null,
)

class SocialViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SocialStore(app)

    val social: StateFlow<Social> = store.social.stateIn(viewModelScope, SharingStarted.Eagerly, Social())

    private val _player = MutableStateFlow<PlayerRequest?>(null)
    val player: StateFlow<PlayerRequest?> = _player.asStateFlow()

    fun openPlayer(request: PlayerRequest) {
        _player.value = request
    }

    private fun update(transform: (Social) -> Social) {
        viewModelScope.launch { store.update(transform) }
    }

    private fun <T> Set<T>.toggled(value: T): Set<T> = if (value in this) this - value else this + value

    fun toggleFollow(handle: String) = update { it.copy(following = it.following.toggled(handle)) }

    fun toggleLike(id: String) = update { it.copy(liked = it.liked.toggled(id)) }

    fun toggleSave(id: String) = update { it.copy(saved = it.saved.toggled(id)) }

    fun markInboxSeen(now: Long) = update { it.copy(inboxSeenAt = maxOf(it.inboxSeenAt, now)) }

    fun deletePost(id: String) = update { s -> s.copy(posts = s.posts.filter { it.id != id }) }

    fun clearAll() {
        viewModelScope.launch { store.clear() }
    }

    /** Adds a post from a picked file. The persistable grant keeps the file readable after restarts. */
    fun addPost(uri: Uri, kind: MediaKind, caption: String) {
        try {
            getApplication<Application>().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            Toasts.emit(R.string.toast_post_failed)
            return
        }
        val record = PostRecord(UUID.randomUUID().toString(), uri.toString(), kind, caption.trim().take(150), System.currentTimeMillis())
        update { it.copy(posts = it.posts + record) }
        Toasts.emit(R.string.toast_posted)
    }
}
