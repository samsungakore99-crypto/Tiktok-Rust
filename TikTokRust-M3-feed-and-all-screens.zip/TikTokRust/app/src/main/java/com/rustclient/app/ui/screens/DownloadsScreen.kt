package com.rustclient.app.ui.screens

import android.graphics.Bitmap
import androidx.annotation.StringRes
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rustclient.app.R
import com.rustclient.app.data.DeviceStats
import com.rustclient.app.data.DlState
import com.rustclient.app.data.Launch
import com.rustclient.app.data.MediaInfo
import com.rustclient.app.data.Thumbs
import com.rustclient.app.data.formatBytes
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.app.vm.DownloadUi
import com.rustclient.app.vm.DownloadsViewModel
import com.rustclient.core.AppSettings
import com.rustclient.core.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@StringRes
private fun failedReason(code: Int): Int = when {
    code == 1006 -> R.string.dl_err_space
    code in 400..599 || code == 1002 || code == 1004 || code == 1005 -> R.string.dl_err_server
    code == 1001 || code == 1007 || code == 1009 -> R.string.dl_err_file
    else -> R.string.dl_err_failed
}

@Composable
private fun statusLine(item: DownloadUi, info: MediaInfo?): String {
    val st = item.status ?: return stringResource(R.string.dl_missing)
    return when (st.state) {
        DlState.DONE -> {
            val size = formatBytes(maxOf(st.total, st.downloaded))
            val label = when {
                info == null || info.width <= 0 -> null
                item.kind == MediaKind.VIDEO -> "${minOf(info.width, info.height)}p"
                else -> "${info.width}×${info.height}"
            }
            if (label != null) "$size · $label" else size
        }
        DlState.RUNNING ->
            if (st.total > 0) "${formatBytes(st.downloaded)} / ${formatBytes(st.total)}" else formatBytes(st.downloaded)
        DlState.QUEUED -> stringResource(R.string.dl_queued)
        DlState.PAUSED -> stringResource(
            when (st.reason) {
                3 -> R.string.dl_wait_wifi
                2 -> R.string.dl_wait_network
                1 -> R.string.dl_wait_retry
                else -> R.string.dl_paused
            },
        )
        DlState.FAILED -> stringResource(failedReason(st.reason))
    }
}

@Composable
private fun Thumb(bitmap: Bitmap?, kind: MediaKind) {
    val p = Rust.palette
    Box(
        Modifier
            .size(64.dp)
            .clip(RustShape.icon)
            .background(p.accent.copy(alpha = 0.15f))
            .border(1.dp, p.accent.copy(alpha = 0.3f), RustShape.icon),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            RustIcon(if (kind == MediaKind.VIDEO) RustGlyph.Video else RustGlyph.Image, tint = p.accentBright, size = 26.dp)
        }
    }
}

@Composable
private fun DownloadRow(item: DownloadUi, onOpen: () -> Unit, onRetry: () -> Unit, onMenu: () -> Unit) {
    val context = LocalContext.current
    val p = Rust.palette
    val status = item.status
    val uri = status?.uri
    val info by produceState<MediaInfo?>(null, uri) {
        value = if (uri != null) Thumbs.info(context, uri, item.kind) else null
    }
    val active = status != null && (status.state == DlState.RUNNING || status.state == DlState.QUEUED || status.state == DlState.PAUSED)
    GlassCard {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Thumb(info?.thumb, item.kind)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                RustText(item.fileName, RustType.rowTitle, maxLines = 1)
                RustText(
                    statusLine(item, info),
                    RustType.rowSubtitle,
                    color = if (status?.state == DlState.FAILED) RustNeutral.Danger else RustNeutral.TextSecondary,
                    maxLines = 2,
                )
                if (active && status != null) {
                    RustProgress(if (status.total > 0) status.downloaded.toFloat() / status.total else 0f, height = 5.dp)
                }
            }
            when {
                status?.state == DlState.DONE -> Box(
                    Modifier.size(42.dp).pressable(onOpen, pressedScale = 0.9f).clip(CircleShape).background(p.gradient),
                    contentAlignment = Alignment.Center,
                ) { RustIcon(RustGlyph.Play, tint = p.onAccent, size = 20.dp) }
                status == null || status.state == DlState.FAILED ->
                    GlassIconButton(RustGlyph.Refresh, onRetry, stringResource(R.string.dl_retry), Modifier.size(42.dp))
            }
            GlassIconButton(RustGlyph.More, onMenu, stringResource(R.string.dl_more), Modifier.size(38.dp))
        }
    }
}

@Composable
private fun StorageCard(free: Long, total: Long, modifier: Modifier = Modifier) {
    val used = (total - free).coerceAtLeast(0L)
    GlassCard(modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RustIcon(RustGlyph.Folder, tint = Rust.palette.accentBright, size = 22.dp)
                RustText(
                    stringResource(R.string.dl_storage, formatBytes(free), formatBytes(total)),
                    RustType.rowTitle,
                    Modifier.weight(1f),
                    maxLines = 1,
                )
            }
            RustProgress(if (total > 0) used.toFloat() / total else 0f)
        }
    }
}

@Composable
private fun AddDownloadDialog(onSubmit: (String) -> Unit, onDismiss: () -> Unit) {
    var url by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    RustDialog(onDismiss) {
        RustText(stringResource(R.string.dl_add), RustType.screenTitle)
        RustTextField(
            value = url,
            onValueChange = { url = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = "https://example.com/clip.mp4",
            leading = RustGlyph.Link,
            keyboardType = KeyboardType.Uri,
            onImeAction = {
                if (url.isNotBlank()) {
                    onSubmit(url)
                    onDismiss()
                }
            },
            trailing = {
                RustButton(
                    stringResource(R.string.action_paste),
                    { clipboard.getText()?.text?.let { url = it } },
                    style = ButtonStyle.Ghost,
                    height = 34.dp,
                )
            },
        )
        RustText(stringResource(R.string.dl_policy), RustType.caption, color = RustNeutral.TextSecondary)
        RustButton(
            stringResource(R.string.dl_start),
            {
                onSubmit(url)
                onDismiss()
            },
            Modifier.fillMaxWidth(),
            icon = RustGlyph.Download,
            height = 48.dp,
            enabled = url.isNotBlank(),
        )
    }
}

/** The download manager: add direct links, watch progress, open / share / retry / delete. */
@Composable
fun DownloadsScreen(
    vm: DownloadsViewModel,
    settings: AppSettings,
    onBack: () -> Unit,
    onPlayVideo: (title: String, uri: String) -> Unit = { _, _ -> },
) {
    val context = LocalContext.current
    val items by vm.items.collectAsStateWithLifecycle()
    val tiktokLink by vm.tiktokLink.collectAsStateWithLifecycle()
    val keepHistory = settings.privacy.keepHistory
    var tab by rememberSaveable { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<DownloadUi?>(null) }
    var deleteFor by remember { mutableStateOf<DownloadUi?>(null) }

    LaunchedEffect(keepHistory) {
        while (true) {
            vm.refresh(keepHistory)
            delay(if (vm.hasActive) 600 else 2000)
        }
    }
    val storage by produceState(0L to 0L, items) {
        value = withContext(Dispatchers.IO) { DeviceStats.storage() }
    }

    val videos = items.filter { it.kind == MediaKind.VIDEO }
    val photos = items.filter { it.kind == MediaKind.PHOTO }
    val shown = if (tab == 0) videos else photos

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.route_downloads), onBack = onBack) {
            GlassIconButton(RustGlyph.Plus, { showAdd = true }, stringResource(R.string.dl_add))
            GlassIconButton(RustGlyph.Folder, { Launch.downloadsApp(context) }, stringResource(R.string.dl_open_folder))
        }
        SegmentedControl(
            options = listOf(
                stringResource(R.string.dl_tab_videos) + " " + videos.size,
                stringResource(R.string.dl_tab_photos) + " " + photos.size,
            ),
            selected = tab,
            onSelect = { tab = it },
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        if (!settings.downloads.allowVideo && !settings.downloads.allowPhoto) {
            InfoNote(R.string.dl_all_disabled, Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (shown.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    CrownMark(size = 96.dp)
                    Spacer(Modifier.height(18.dp))
                    RustText(stringResource(R.string.dl_empty_title), RustType.screenTitle, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    RustText(
                        stringResource(R.string.dl_empty_body),
                        RustType.rowSubtitle,
                        color = RustNeutral.TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                    Spacer(Modifier.height(20.dp))
                    RustButton(stringResource(R.string.dl_add), { showAdd = true }, icon = RustGlyph.Plus, height = 46.dp)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(shown, key = { it.id }) { item ->
                        DownloadRow(
                            item = item,
                            onOpen = {
                                val uri = item.status?.uri
                                if (uri != null) {
                                    if (item.kind == MediaKind.VIDEO) onPlayVideo(item.fileName, uri.toString()) else Launch.open(context, uri, item.kind)
                                }
                            },
                            onRetry = { vm.retry(item, settings) },
                            onMenu = { menuFor = item },
                        )
                    }
                }
            }
        }
        StorageCard(storage.first, storage.second, Modifier.padding(16.dp))
    }

    if (showAdd) AddDownloadDialog(onSubmit = { vm.submit(it, settings) }, onDismiss = { showAdd = false })

    tiktokLink?.let { link ->
        ConfirmDialog(
            title = stringResource(R.string.dl_tiktok_title),
            message = stringResource(R.string.dl_tiktok_msg),
            confirmLabel = stringResource(R.string.dl_open_tiktok),
            cancelLabel = stringResource(R.string.action_close),
            onConfirm = { Launch.url(context, link) },
            onDismiss = { vm.dismissTikTokLink() },
        )
    }

    menuFor?.let { item ->
        val status = item.status
        val uri = status?.uri
        val actions = buildList<SheetAction> {
            if (status?.state == DlState.DONE && uri != null) {
                add(SheetAction(stringResource(R.string.dl_open), RustGlyph.Play, onClick = { Launch.open(context, uri, item.kind) }))
                add(SheetAction(stringResource(R.string.dl_share), RustGlyph.Share, onClick = { Launch.share(context, uri, item.kind) }))
                add(SheetAction(stringResource(R.string.dl_forget), RustGlyph.Close, onClick = { vm.forget(item, keepHistory) }))
                add(SheetAction(stringResource(R.string.dl_delete), RustGlyph.Trash, destructive = true, onClick = { deleteFor = item }))
            } else if (status == null || status.state == DlState.FAILED) {
                add(SheetAction(stringResource(R.string.dl_retry), RustGlyph.Refresh, onClick = { vm.retry(item, settings) }))
                add(SheetAction(stringResource(R.string.dl_forget), RustGlyph.Close, onClick = { vm.forget(item, keepHistory) }))
            } else {
                add(SheetAction(stringResource(R.string.dl_cancel), RustGlyph.Close, destructive = true, onClick = { vm.deleteFile(item, keepHistory) }))
            }
        }
        ActionSheetDialog(item.fileName, actions, onDismiss = { menuFor = null })
    }

    deleteFor?.let { item ->
        ConfirmDialog(
            title = stringResource(R.string.dl_delete),
            message = stringResource(R.string.dl_delete_msg, item.fileName),
            confirmLabel = stringResource(R.string.action_delete),
            cancelLabel = stringResource(R.string.action_cancel),
            onConfirm = { vm.deleteFile(item, keepHistory) },
            onDismiss = { deleteFor = null },
            destructive = true,
        )
    }
}
