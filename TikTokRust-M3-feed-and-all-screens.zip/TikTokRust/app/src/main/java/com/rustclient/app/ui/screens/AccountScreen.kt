package com.rustclient.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings
import com.rustclient.core.SettingsCodec

private const val TIKTOK_DOCS = "https://developers.tiktok.com/docs/en/get-started"

@Composable
private fun FieldLabel(text: String, counter: String? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RustText(text, RustType.label, Modifier.weight(1f), color = RustNeutral.TextSecondary)
        if (counter != null) RustText(counter, RustType.caption, color = RustNeutral.TextTertiary)
    }
}

/** Local profile: name, @handle, bio and picture are stored on the device only. */
@Composable
fun AccountScreen(
    settings: AppSettings,
    avatar: Bitmap?,
    onSave: (name: String, handle: String, bio: String) -> Unit,
    onAvatarPicked: (Uri) -> Unit,
    onRemoveAvatar: () -> Unit,
    onBack: () -> Unit,
    onOpenUrl: (String) -> Unit,
) {
    val profile = settings.profile
    var name by remember { mutableStateOf(profile.displayName) }
    var handle by remember { mutableStateOf(profile.handle) }
    var bio by remember { mutableStateOf(profile.bio) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onAvatarPicked(uri)
    }

    val cleanName = SettingsCodec.cleanName(name, "")
    val cleanHandle = SettingsCodec.cleanHandle(handle, profile.handle)
    val cleanBio = SettingsCodec.cleanBio(bio)
    val valid = cleanName.isNotEmpty()
    val changed = cleanName != profile.displayName || cleanHandle != profile.handle || cleanBio != profile.bio

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.set_account), onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Avatar(avatar, name.ifBlank { profile.displayName }, 104.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RustButton(
                        stringResource(R.string.acc_change_photo),
                        { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        style = ButtonStyle.Ghost,
                        icon = RustGlyph.Image,
                        height = 40.dp,
                    )
                    if (avatar != null) {
                        RustButton(stringResource(R.string.acc_remove_photo), onRemoveAvatar, style = ButtonStyle.Ghost, height = 40.dp)
                    }
                }
            }

            FieldLabel(stringResource(R.string.acc_name), "${name.length}/32")
            RustTextField(name, { name = it.take(32) }, Modifier.fillMaxWidth(), placeholder = stringResource(R.string.acc_name_hint))

            FieldLabel(stringResource(R.string.acc_handle), "@$cleanHandle")
            RustTextField(handle, { handle = it.take(24) }, Modifier.fillMaxWidth(), placeholder = "tiktok_rust", leading = RustGlyph.Profile)

            FieldLabel(stringResource(R.string.acc_bio), "${bio.length}/120")
            RustTextField(
                bio,
                { bio = it.take(120) },
                Modifier.fillMaxWidth(),
                placeholder = stringResource(R.string.acc_bio_hint),
                singleLine = false,
                minHeight = 96.dp,
            )

            RustButton(
                stringResource(R.string.action_save),
                { onSave(cleanName, cleanHandle, cleanBio) },
                Modifier.fillMaxWidth(),
                enabled = valid && changed,
            )

            GlassCard {
                SettingsRow(
                    glyph = RustGlyph.Link,
                    title = stringResource(R.string.acc_tiktok_t),
                    subtitle = stringResource(R.string.acc_tiktok_s),
                    onClick = { onOpenUrl(TIKTOK_DOCS) },
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
