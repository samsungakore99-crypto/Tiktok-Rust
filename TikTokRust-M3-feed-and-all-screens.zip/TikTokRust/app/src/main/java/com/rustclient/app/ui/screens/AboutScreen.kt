package com.rustclient.app.ui.screens

import android.os.Build
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.*
import androidx.core.content.pm.PackageInfoCompat
import com.rustclient.app.R
import com.rustclient.app.data.Launch
import com.rustclient.app.data.Toasts
import com.rustclient.app.rust.Engines
import com.rustclient.app.rust.RustBridge
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.theme.*

/** Real build information only: no update checker, because there is no update server to ask. */
@Composable
fun AboutScreen(onBack: () -> Unit, onOpenGallery: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val info = remember { context.packageManager.getPackageInfo(context.packageName, 0) }
    val version = "${info.versionName} (${PackageInfoCompat.getLongVersionCode(info)})"
    val android = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
    val engine = Engines.current.name + (RustBridge.version?.let { " + Rust $it" } ?: "")
    val report = "${stringResource(R.string.brand_name)} $version\n$android\n${Build.MANUFACTURER} ${Build.MODEL}\n${stringResource(R.string.engine_title)}: $engine"

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.route_about), onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            CrownMark(size = 120.dp)
            RustText(stringResource(R.string.brand_name), RustType.screenTitle)
            RustText(stringResource(R.string.about_version, version), RustType.rowSubtitle, color = RustNeutral.TextSecondary)
            RustText(stringResource(R.string.brand_tagline), RustType.rowTitle, color = RustNeutral.TextSecondary)
            GlassCard(Modifier.fillMaxWidth()) {
                SettingsRow(RustGlyph.Info, stringResource(R.string.about_android), android, trailing = {})
                RowDivider()
                SettingsRow(RustGlyph.Monitor, stringResource(R.string.about_device), "${Build.MANUFACTURER} ${Build.MODEL}", trailing = {})
                RowDivider()
                SettingsRow(RustGlyph.Bolt, stringResource(R.string.engine_title), engine, trailing = {})
            }
            RustButton(
                stringResource(R.string.about_copy),
                {
                    clipboard.setText(AnnotatedString(report))
                    Toasts.emit(R.string.about_copied_toast)
                },
                Modifier.fillMaxWidth(),
                icon = RustGlyph.Share,
            )
            RustButton(
                stringResource(R.string.about_docs),
                { Launch.url(context, "https://developers.tiktok.com/docs/en/get-started") },
                Modifier.fillMaxWidth(),
                style = ButtonStyle.Ghost,
                icon = RustGlyph.Link,
            )
            RustButton(stringResource(R.string.about_gallery), onOpenGallery, Modifier.fillMaxWidth(), style = ButtonStyle.Ghost, icon = RustGlyph.Palette)
            Spacer(Modifier.height(24.dp))
        }
    }
}
