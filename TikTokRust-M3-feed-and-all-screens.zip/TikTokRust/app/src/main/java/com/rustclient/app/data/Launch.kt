package com.rustclient.app.data

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.rustclient.app.R
import com.rustclient.core.MediaKind

/** Hand-offs to other apps and system screens. Failures surface as a toast instead of a crash. */
object Launch {
    fun url(context: Context, url: String) = start(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    fun notificationSettings(context: Context) = start(
        context,
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
    )

    fun language(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= 33) {
            Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.fromParts("package", context.packageName, null))
        } else {
            Intent(Settings.ACTION_LOCALE_SETTINGS)
        }
        start(context, intent)
    }

    fun downloadsApp(context: Context) = start(context, Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))

    fun open(context: Context, uri: Uri, kind: MediaKind) = start(
        context,
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, if (kind == MediaKind.VIDEO) "video/*" else "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
    )

    fun share(context: Context, uri: Uri, kind: MediaKind) {
        val send = Intent(Intent.ACTION_SEND)
            .setType(if (kind == MediaKind.VIDEO) "video/*" else "image/*")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        start(context, Intent.createChooser(send, null))
    }

    fun shareText(context: Context, text: String) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        start(context, Intent.createChooser(send, null))
    }

    private fun start(context: Context, intent: Intent) {
        try {
            if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toasts.emit(R.string.toast_no_app)
        }
    }
}
