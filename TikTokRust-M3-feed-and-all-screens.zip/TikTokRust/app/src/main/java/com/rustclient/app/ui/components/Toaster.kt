package com.rustclient.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.rustclient.app.data.Toasts
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import kotlinx.coroutines.delay

/** Shows [Toasts] as an animated glass pill. Place it at the bottom of the shell. */
@Composable
fun ToastHost(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val p = Rust.palette
    var text by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        Toasts.events.collect { m ->
            text = if (m.arg != null) context.getString(m.res, m.arg) else context.getString(m.res)
            visible = true
            delay(2600)
            visible = false
        }
    }
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = slideInVertically(spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(),
        exit = slideOutVertically(tween(200)) { it / 2 } + fadeOut(tween(200)),
    ) {
        Row(
            Modifier
                .padding(horizontal = 24.dp)
                .glass(RustShape.pill, 0.6f)
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            RustIcon(RustGlyph.Check, tint = p.accentBright, size = 18.dp)
            RustText(text, RustType.rowTitle, maxLines = 2)
        }
    }
}
