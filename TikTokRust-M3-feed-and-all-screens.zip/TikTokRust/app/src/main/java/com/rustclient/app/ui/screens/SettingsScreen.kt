package com.rustclient.app.ui.screens

import android.graphics.Bitmap
import androidx.annotation.StringRes
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.Routes
import com.rustclient.app.data.rememberFps
import com.rustclient.app.data.rememberMemoryMb
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings
import kotlinx.coroutines.delay

private class RowDef(
    val glyph: RustGlyph,
    @StringRes val title: Int,
    @StringRes val sub: Int,
    val route: String? = null,
    val action: String? = null,
    val emphasized: Boolean = false,
)

private val Rows = listOf(
    RowDef(RustGlyph.Profile, R.string.set_account, R.string.set_account_s, Routes.SettingsAccount),
    RowDef(RustGlyph.Lock, R.string.set_privacy, R.string.set_privacy_s, Routes.SettingsPrivacy),
    RowDef(RustGlyph.Bell, R.string.set_notifications, R.string.set_notifications_s, Routes.SettingsNotifications),
    RowDef(RustGlyph.Monitor, R.string.set_appearance, R.string.set_appearance_s, Routes.SettingsAppearance),
    RowDef(RustGlyph.Gauge, R.string.set_performance, R.string.set_performance_s, Routes.SettingsPerformance),
    RowDef(RustGlyph.Crown, R.string.route_mod, R.string.sub_mod, Routes.mod(), emphasized = true),
    RowDef(RustGlyph.Download, R.string.set_downloads, R.string.set_downloads_s, Routes.mod("downloads")),
    RowDef(RustGlyph.Globe, R.string.set_language, R.string.set_language_s, action = "language"),
    RowDef(RustGlyph.Info, R.string.route_about, R.string.sub_about, Routes.About),
)

/** Live memory / frame-rate / theme-count tiles. Shared by Settings and Performance. */
@Composable
fun LiveStatsRow(settings: AppSettings, modifier: Modifier = Modifier) {
    val memory by rememberMemoryMb()
    val fps by rememberFps(settings.performance.showFps)
    val memoryOk = memory < 400
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatTile(
            RustGlyph.Bolt,
            stringResource(R.string.stat_memory),
            "$memory MB",
            Modifier.weight(1f),
            status = stringResource(if (memoryOk) R.string.stat_good else R.string.stat_high),
            statusColor = if (memoryOk) RustNeutral.Success else RustNeutral.Gold,
        )
        val shown = settings.performance.showFps && fps > 0
        StatTile(
            RustGlyph.Bars,
            stringResource(R.string.stat_fps),
            if (shown) "$fps" else "—",
            Modifier.weight(1f),
            status = if (shown) stringResource(if (fps >= 55) R.string.stat_excellent else if (fps >= 30) R.string.stat_ok else R.string.stat_low) else null,
            statusColor = if (fps >= 55) RustNeutral.Success else if (fps >= 30) RustNeutral.Gold else RustNeutral.Danger,
        )
        StatTile(
            RustGlyph.Palette,
            stringResource(R.string.stat_themes),
            "${PaletteResolver.presets.size + 1}",
            Modifier.weight(1f),
        )
    }
}

@Composable
private fun ModBanner(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = Rust.palette
    Row(
        modifier
            .fillMaxWidth()
            .pressable(onClick, pressedScale = 0.985f)
            .clip(RustShape.card)
            .background(Brush.linearGradient(listOf(p.accentDeep.copy(alpha = 0.6f), p.surface, p.accent.copy(alpha = 0.3f))))
            .border(
                1.dp,
                Brush.linearGradient(listOf(p.accentBright.copy(alpha = 0.55f), p.accent.copy(alpha = 0.1f))),
                RustShape.card,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        CrownMark(size = 56.dp)
        Column(Modifier.weight(1f)) {
            RustText(stringResource(R.string.route_mod), RustType.sectionTitle, maxLines = 1)
            RustText(stringResource(R.string.banner_mod_sub), RustType.rowSubtitle, color = RustNeutral.TextSecondary, maxLines = 2)
        }
        RustIcon(RustGlyph.ChevronRight, tint = p.accentBright, size = 22.dp)
    }
}

@Composable
fun SettingsScreen(
    settings: AppSettings,
    avatar: Bitmap?,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onAction: (String) -> Unit,
) {
    val context = LocalContext.current
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(searching) {
        if (searching) {
            delay(80)
            try { focus.requestFocus() } catch (e: IllegalStateException) { /* field not attached yet */ }
        }
    }
    val results = remember(query) {
        if (query.isBlank()) {
            emptyList()
        } else {
            SectionCatalog.index.filter { e ->
                val sub = e.spec.sub?.let { context.getString(it) } ?: ""
                context.getString(e.spec.title).contains(query, ignoreCase = true) || sub.contains(query, ignoreCase = true)
            }.take(12)
        }
    }

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.route_settings), onBack = onBack) {
            GlassIconButton(
                if (searching) RustGlyph.Close else RustGlyph.Search,
                {
                    searching = !searching
                    if (!searching) query = ""
                },
                stringResource(R.string.action_search),
            )
        }
        AnimatedVisibility(visible = searching) {
            RustTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).focusRequester(focus),
                placeholder = stringResource(R.string.search_settings_hint),
                leading = RustGlyph.Search,
                imeAction = ImeAction.Search,
            )
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (searching && query.isNotBlank()) {
                if (results.isEmpty()) {
                    RustText(
                        stringResource(R.string.search_none),
                        RustType.rowSubtitle,
                        Modifier.padding(horizontal = 24.dp, vertical = 24.dp),
                        color = RustNeutral.TextSecondary,
                    )
                } else {
                    GlassCard(Modifier.padding(horizontal = 16.dp)) {
                        results.forEachIndexed { index, entry ->
                            if (index > 0) RowDivider()
                            SettingsRow(
                                glyph = entry.spec.glyph,
                                title = stringResource(entry.spec.title),
                                subtitle = stringResource(entry.groupTitle),
                                onClick = { onNavigate(entry.route) },
                            )
                        }
                    }
                }
            } else {
                GlassCard(Modifier.padding(horizontal = 16.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Avatar(avatar, settings.profile.displayName, 64.dp)
                        Column(Modifier.weight(1f)) {
                            RustText(settings.profile.displayName, RustType.sectionTitle, maxLines = 1)
                            RustText("@" + settings.profile.handle, RustType.rowSubtitle, color = RustNeutral.TextSecondary, maxLines = 1)
                        }
                        RustButton(
                            stringResource(R.string.action_edit),
                            { onNavigate(Routes.SettingsAccount) },
                            style = ButtonStyle.Ghost,
                            height = 38.dp,
                        )
                    }
                }
                ModBanner({ onNavigate(Routes.mod()) }, Modifier.padding(horizontal = 16.dp))
                LiveStatsRow(settings, Modifier.padding(horizontal = 16.dp))
                GlassCard(Modifier.padding(horizontal = 16.dp)) {
                    Rows.forEachIndexed { index, row ->
                        if (index > 0) RowDivider()
                        SettingsRow(
                            glyph = row.glyph,
                            title = stringResource(row.title),
                            subtitle = stringResource(row.sub),
                            onClick = {
                                if (row.route != null) onNavigate(row.route) else row.action?.let(onAction)
                            },
                            emphasized = row.emphasized,
                            trailing = {
                                if (row.emphasized) {
                                    NewBadge(stringResource(R.string.badge_new))
                                } else {
                                    RustIcon(RustGlyph.ChevronRight, tint = RustNeutral.TextTertiary, size = 20.dp)
                                }
                            },
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
