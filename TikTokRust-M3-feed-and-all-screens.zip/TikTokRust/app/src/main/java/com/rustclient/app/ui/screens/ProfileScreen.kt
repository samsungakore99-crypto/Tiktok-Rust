package com.rustclient.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.data.FeedRepository
import com.rustclient.app.data.Social
import com.rustclient.app.data.Thumbs
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings
import com.rustclient.core.ContentKind
import com.rustclient.core.FeedItem
import com.rustclient.core.MediaKind

@Composable
private fun Stat(value: Int, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        RustText("$value", RustType.screenTitle)
        RustText(label, RustType.caption, color = RustNeutral.TextSecondary, maxLines = 1)
    }
}

@Composable
private fun PostCell(item: FeedItem, onClick: () -> Unit, onLongPress: () -> Unit) {
    val context = LocalContext.current
    val p = Rust.palette
    val mine = FeedRepository.isMine(item)
    val url = item.variants.firstOrNull()?.url
    val thumb by produceState<Bitmap?>(null, url) {
        value = if (mine && url != null) {
            Thumbs.info(context, Uri.parse(url), if (item.kind == ContentKind.PHOTO) MediaKind.PHOTO else MediaKind.VIDEO).thumb
        } else {
            null
        }
    }
    val res = FeedRepository.photoRes(item.id)
    val playable = item.kind == ContentKind.VIDEO || item.kind == ContentKind.REPOST
    Box(
        Modifier
            .aspectRatio(0.75f)
            .clip(RustShape.icon)
            .background(Brush.verticalGradient(listOf(p.accent.copy(alpha = 0.35f), p.surface)))
            .border(1.dp, p.accent.copy(alpha = 0.25f), RustShape.icon)
            .pointerInput(item.id) { detectTapGestures(onTap = { onClick() }, onLongPress = { onLongPress() }) },
    ) {
        when {
            res != null -> Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            thumb != null -> thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                RustIcon(if (item.kind == ContentKind.PHOTO) RustGlyph.Image else RustGlyph.Play, tint = p.accentBright, size = 30.dp)
            }
        }
        if (playable) {
            RustIcon(RustGlyph.Play, Modifier.align(Alignment.TopEnd).padding(6.dp), tint = Color.White, size = 16.dp)
        }
    }
}

/** Own profile (handle == null) or another account's profile, built from the posts the feed knows about. */
@Composable
fun ProfileScreen(
    handle: String?,
    settings: AppSettings,
    avatar: Bitmap?,
    social: Social,
    allItems: List<FeedItem>,
    onBack: (() -> Unit)?,
    onEdit: () -> Unit,
    onSettings: () -> Unit,
    onDownloads: () -> Unit,
    onToggleFollow: (String) -> Unit,
    onOpenPost: (FeedItem) -> Unit,
    onDeletePost: (String) -> Unit,
) {
    val own = handle == null
    val shownHandle = handle ?: settings.profile.handle
    val name = if (own) settings.profile.displayName else shownHandle
    val myPosts = allItems.filter { FeedRepository.isMine(it) }
    val authored = if (own) myPosts else allItems.filter { it.author.trimStart('@') == shownHandle }
    var tab by rememberSaveable { mutableStateOf(0) }
    var menuFor by remember { mutableStateOf<FeedItem?>(null) }
    val cells = when {
        !own -> authored
        tab == 0 -> myPosts
        tab == 1 -> allItems.filter { it.id in social.saved }
        else -> allItems.filter { it.id in social.liked }
    }
    val following = shownHandle in social.following

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().height(56.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (onBack != null) GlassIconButton(RustGlyph.ChevronLeft, onBack, stringResource(R.string.back))
                    RustText("@$shownHandle", RustType.screenTitle, Modifier.weight(1f), maxLines = 1)
                    if (own) {
                        GlassIconButton(RustGlyph.Download, onDownloads, stringResource(R.string.route_downloads))
                        GlassIconButton(RustGlyph.Tune, onSettings, stringResource(R.string.route_settings))
                    }
                }
                Avatar(if (own) avatar else null, name, 96.dp)
                RustText(name, RustType.screenTitle, maxLines = 1)
                if (!own) SampleTag()
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (own) {
                        Stat(myPosts.size, stringResource(R.string.profile_posts), Modifier.weight(1f))
                        Stat(social.following.size, stringResource(R.string.profile_following), Modifier.weight(1f))
                        Stat(social.saved.size, stringResource(R.string.profile_saved), Modifier.weight(1f))
                    } else {
                        Stat(authored.size, stringResource(R.string.profile_posts), Modifier.weight(1f))
                        Stat(authored.count { it.id in social.liked }, stringResource(R.string.profile_liked_by_you), Modifier.weight(1f))
                        Stat(authored.count { it.id in social.saved }, stringResource(R.string.profile_saved_by_you), Modifier.weight(1f))
                    }
                }
                if (own && settings.profile.bio.isNotBlank()) {
                    RustText(settings.profile.bio, RustType.rowTitle, color = RustNeutral.TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                if (own) {
                    RustButton(stringResource(R.string.action_edit_profile), onEdit, Modifier.fillMaxWidth(), style = ButtonStyle.Ghost, icon = RustGlyph.Edit, height = 46.dp)
                    SegmentedControl(
                        listOf(stringResource(R.string.profile_posts), stringResource(R.string.profile_saved), stringResource(R.string.profile_liked)),
                        tab,
                        { tab = it },
                    )
                } else {
                    RustButton(
                        stringResource(if (following) R.string.action_following else R.string.action_follow),
                        { onToggleFollow(shownHandle) },
                        Modifier.fillMaxWidth(),
                        style = if (following) ButtonStyle.Ghost else ButtonStyle.Follow,
                        height = 46.dp,
                    )
                }
                if (cells.isEmpty()) {
                    RustText(
                        stringResource(if (own && tab == 0) R.string.profile_empty_posts else R.string.profile_empty),
                        RustType.rowSubtitle,
                        Modifier.padding(vertical = 24.dp),
                        color = RustNeutral.TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }
        items(cells, key = { it.id }) { item ->
            PostCell(item, onClick = { onOpenPost(item) }, onLongPress = { if (FeedRepository.isMine(item)) menuFor = item })
        }
    }

    menuFor?.let { item ->
        ActionSheetDialog(
            title = item.caption.ifBlank { item.author },
            actions = listOf(
                SheetAction(stringResource(R.string.profile_delete_post), RustGlyph.Trash, destructive = true, onClick = { onDeletePost(item.id.removePrefix("my:")) }),
            ),
            onDismiss = { menuFor = null },
        )
    }
}
