package com.rustclient.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.rustclient.app.R
import com.rustclient.app.Routes
import com.rustclient.app.data.DeviceStats
import com.rustclient.app.data.Launch
import com.rustclient.app.data.Toasts
import com.rustclient.app.data.formatBytes
import com.rustclient.app.rust.Engines
import com.rustclient.app.rust.RustBridge
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Generic screen for a list of option groups, with an optional header (status cards, live stats...). */
@Composable
fun SectionScreen(
    @StringRes title: Int,
    groups: List<SpecGroup>,
    settings: AppSettings,
    onUpdate: Update,
    onBack: () -> Unit,
    onAction: (String) -> Unit,
    actionValue: (String) -> String? = { null },
    header: @Composable ColumnScope.() -> Unit = {},
) {
    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(title), onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            header()
            groups.forEach { group ->
                SpecGroupCard(group, settings, onUpdate, onAction, Modifier.padding(horizontal = 16.dp), actionValue = actionValue)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun PrivacyScreen(
    settings: AppSettings,
    onUpdate: Update,
    onBack: () -> Unit,
    onClearHistory: () -> Unit,
    onResetAll: () -> Unit,
) {
    var confirm by remember { mutableStateOf<String?>(null) }
    SectionScreen(
        title = R.string.set_privacy,
        groups = SectionCatalog.privacy,
        settings = settings,
        onUpdate = onUpdate,
        onBack = onBack,
        onAction = { id -> if (id == "clear_history" || id == "reset_all") confirm = id },
    )
    when (confirm) {
        "clear_history" -> ConfirmDialog(
            title = stringResource(R.string.sp_clearhist_t),
            message = stringResource(R.string.confirm_clear_history),
            confirmLabel = stringResource(R.string.action_clear),
            cancelLabel = stringResource(R.string.action_cancel),
            onConfirm = onClearHistory,
            onDismiss = { confirm = null },
            destructive = true,
        )
        "reset_all" -> ConfirmDialog(
            title = stringResource(R.string.sp_reset_t),
            message = stringResource(R.string.confirm_reset_all),
            confirmLabel = stringResource(R.string.action_reset),
            cancelLabel = stringResource(R.string.action_cancel),
            onConfirm = onResetAll,
            onDismiss = { confirm = null },
            destructive = true,
        )
    }
}

@Composable
private fun NotificationStatusCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val p = Rust.palette
    var enabled by remember { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        enabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) enabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    GlassCard(modifier) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            IconTile(RustGlyph.Bell, emphasized = enabled)
            Column(Modifier.weight(1f)) {
                RustText(
                    stringResource(if (enabled) R.string.notif_allowed else R.string.notif_blocked),
                    RustType.rowTitle,
                    maxLines = 1,
                )
                RustText(
                    stringResource(if (enabled) R.string.notif_allowed_s else R.string.notif_blocked_s),
                    RustType.rowSubtitle,
                    color = RustNeutral.TextSecondary,
                    maxLines = 3,
                )
            }
            if (!enabled) {
                RustButton(
                    stringResource(R.string.action_allow),
                    {
                        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else Launch.notificationSettings(context)
                    },
                    height = 38.dp,
                )
            } else {
                RustIcon(RustGlyph.Check, tint = p.accentBright, size = 22.dp)
            }
        }
    }
}

@Composable
fun NotificationsScreen(settings: AppSettings, onUpdate: Update, onBack: () -> Unit) {
    val context = LocalContext.current
    SectionScreen(
        title = R.string.set_notifications,
        groups = SectionCatalog.notifications,
        settings = settings,
        onUpdate = onUpdate,
        onBack = onBack,
        onAction = { id -> if (id == "notif_system") Launch.notificationSettings(context) },
        header = { NotificationStatusCard(Modifier.padding(horizontal = 16.dp)) },
    )
}

@Composable
fun PerformanceScreen(settings: AppSettings, onUpdate: Update, onBack: () -> Unit) {
    val context = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    val cacheBytes by produceState(0L, tick) {
        value = withContext(Dispatchers.IO) { DeviceStats.cacheBytes(context) }
    }
    val engine = Engines.current.name
    val rust = RustBridge.version
    SectionScreen(
        title = R.string.set_performance,
        groups = SectionCatalog.performance,
        settings = settings,
        onUpdate = onUpdate,
        onBack = onBack,
        onAction = { id ->
            if (id == "clear_cache") {
                DeviceStats.clearCache(context)
                tick++
                Toasts.emit(R.string.toast_cache_cleared)
            }
        },
        actionValue = { id -> if (id == "clear_cache") formatBytes(cacheBytes) else null },
        header = {
            LiveStatsRow(settings, Modifier.padding(horizontal = 16.dp))
            GlassCard(Modifier.padding(horizontal = 16.dp)) {
                SettingsRow(
                    glyph = RustGlyph.Bolt,
                    title = stringResource(R.string.engine_title),
                    subtitle = stringResource(
                        R.string.engine_sub,
                        engine,
                        rust ?: stringResource(R.string.engine_rust_none),
                    ),
                    trailing = {},
                )
            }
        },
    )
}

@Composable
fun AppearanceScreen(settings: AppSettings, onUpdate: Update, onBack: () -> Unit, onNavigate: (String) -> Unit) {
    SectionScreen(
        title = R.string.set_appearance,
        groups = SectionCatalog.appearance,
        settings = settings,
        onUpdate = onUpdate,
        onBack = onBack,
        onAction = { id -> if (id == "open_themes") onNavigate(Routes.Themes) },
        actionValue = { id -> if (id == "open_themes") themeName(settings) else null },
    )
}
