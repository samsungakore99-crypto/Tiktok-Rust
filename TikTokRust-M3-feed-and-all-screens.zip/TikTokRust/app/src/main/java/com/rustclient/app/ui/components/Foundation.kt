package com.rustclient.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.rustclient.app.ui.theme.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Spring press feedback shared by every tappable surface (replaces the ripple). */
fun Modifier.pressable(
    onClick: () -> Unit,
    enabled: Boolean = true,
    pressedScale: Float = 0.97f,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val reduce = LocalMotion.current.reduce
    val scale by animateFloatAsState(if (pressed && !reduce) pressedScale else 1f, RustMotion.press, label = "press")
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }.clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

/** Soft coloured halo drawn outside the bounds, built from stacked translucent rounded rects. */
fun Modifier.neonGlow(
    color: Color,
    spread: Dp = 18.dp,
    alpha: Float = 0.5f,
    cornerRadius: Dp = 999.dp,
): Modifier = drawBehind {
    val layers = 7
    val maxSpread = spread.toPx()
    val base = min(cornerRadius.toPx(), size.minDimension / 2f)
    for (i in layers downTo 1) {
        val g = maxSpread * i / layers
        val a = (alpha / layers) * (1f - (i - 1f) / layers)
        drawRoundRect(
            color = color.copy(alpha = a.coerceIn(0f, 1f)),
            topLeft = Offset(-g, -g),
            size = Size(size.width + g * 2f, size.height + g * 2f),
            cornerRadius = CornerRadius(base + g),
        )
    }
}

/** The signature surface: translucent tinted fill + 1 dp hairline that fades along the diagonal. */
@Composable
fun Modifier.glass(shape: Shape = RustShape.card, strokeAlpha: Float = 0.32f): Modifier {
    val p = Rust.palette
    return this
        .background(
            Brush.verticalGradient(listOf(p.surface.copy(alpha = 0.96f), p.surface.copy(alpha = 0.80f))),
            shape,
        )
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    p.accent.copy(alpha = strokeAlpha),
                    p.accent.copy(alpha = 0.05f),
                    p.accent.copy(alpha = strokeAlpha * 0.6f),
                ),
            ),
            shape,
        )
}

/** Full-screen backdrop: tinted base gradient with three slowly drifting colour blooms. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val p = Rust.palette
    val motion = LocalMotion.current
    val phaseState: State<Float> = if (motion.animatedBackground && !motion.reduce) {
        rememberInfiniteTransition(label = "aurora").animateFloat(
            initialValue = 0f,
            targetValue = (2 * Math.PI).toFloat(),
            animationSpec = infiniteRepeatable(tween(36_000, easing = LinearEasing)),
            label = "phase",
        )
    } else {
        remember { mutableStateOf(0f) }
    }
    Box(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
                val phase = phaseState.value
                val w = size.width
                val h = size.height
                fun bloom(color: Color, cx: Float, cy: Float, radius: Float, alpha: Float) {
                    val c = Offset(cx, cy)
                    drawCircle(
                        Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), center = c, radius = radius),
                        radius = radius,
                        center = c,
                    )
                }
                bloom(p.glowA, w * (0.88f + 0.10f * sin(phase)), h * (0.06f + 0.03f * cos(phase * 0.7f)), w * 1.0f, 0.34f)
                bloom(p.glowB, w * (0.05f + 0.08f * cos(phase * 0.8f)), h * (0.42f + 0.05f * sin(phase)), w * 0.9f, 0.26f)
                bloom(p.accentDeep, w * (0.55f + 0.10f * sin(phase * 0.6f)), h * 1.02f, w * 1.1f, 0.20f)
            },
    )
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    RustText(
        text,
        RustType.label.copy(fontWeight = FontWeight.SemiBold),
        modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp),
        color = RustNeutral.TextSecondary,
    )
}
