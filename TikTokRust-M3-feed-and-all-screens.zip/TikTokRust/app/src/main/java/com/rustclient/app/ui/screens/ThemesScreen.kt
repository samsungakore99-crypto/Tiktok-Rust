package com.rustclient.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings

@Composable
private fun ThemeCard(
    name: String,
    palette: RustPalette,
    selected: Boolean,
    applied: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val glow by animateFloatAsState(if (selected) 1f else 0f, tween(220), label = "themeGlow")
    Column(modifier.pressable(onClick, pressedScale = 0.95f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.95f)
                .neonGlow(palette.accent, 12.dp, 0.5f * glow, 18.dp)
                .clip(RustShape.tile)
                .background(Brush.verticalGradient(listOf(palette.bgTop, palette.bgBottom)))
                .border(
                    if (selected) 2.dp else 1.dp,
                    if (selected) palette.accentBright else palette.accent.copy(alpha = 0.3f),
                    RustShape.tile,
                ),
        ) {
            NeonSkyline(palette, Modifier.fillMaxSize())
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(24.dp)
                        .clip(RustShape.pill)
                        .background(palette.gradient),
                    contentAlignment = Alignment.Center,
                ) {
                    RustIcon(RustGlyph.Check, tint = palette.onAccent, size = 16.dp, strokeWidth = 2.4f)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            RustText(name, RustType.label, color = if (selected) RustNeutral.TextPrimary else RustNeutral.TextSecondary, maxLines = 1)
            if (applied) Box(Modifier.size(6.dp).clip(RustShape.pill).background(RustNeutral.Success))
        }
    }
}

/**
 * Pick one of six themes or build one from any accent colour. The phone on top is a live render
 * of the candidate; nothing changes app-wide until "Apply theme" is pressed.
 */
@Composable
fun ThemesScreen(settings: AppSettings, onApply: (themeId: String, customAccent: Int) -> Unit, onBack: () -> Unit) {
    val applied = settings.appearance
    var selected by rememberSaveable { mutableStateOf(applied.themeId) }
    var custom by rememberSaveable { mutableStateOf(applied.customAccent) }
    val candidate = remember(selected, custom) { PaletteResolver.resolve(selected, custom) }
    val customPalette = remember(custom) { PaletteResolver.custom(custom) }
    val changed = selected != applied.themeId || (selected == ThemeIds.CUSTOM && custom != applied.customAccent)
    val isApplied = !changed

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.route_themes), onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                PhonePreview(candidate, Modifier.width(168.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    RustText(candidate.name, RustType.screenTitle, maxLines = 1)
                    RustText(stringResource(R.string.theme_hint), RustType.rowSubtitle, color = RustNeutral.TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(candidate.accentDeep, candidate.accent, candidate.accentBright, candidate.surface).forEach { c ->
                            Box(Modifier.size(24.dp).clip(RustShape.pill).background(c).border(1.dp, Color.White.copy(alpha = 0.3f), RustShape.pill))
                        }
                    }
                    if (isApplied) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.size(8.dp).clip(RustShape.pill).background(RustNeutral.Success))
                            RustText(stringResource(R.string.theme_applied), RustType.caption, color = RustNeutral.Success)
                        }
                    }
                }
            }

            RustText(stringResource(R.string.theme_presets), RustType.label, color = RustNeutral.TextSecondary)
            PaletteResolver.presets.chunked(3).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { (id, palette) ->
                        ThemeCard(
                            name = palette.name,
                            palette = palette,
                            selected = selected == id,
                            applied = applied.themeId == id,
                            onClick = { selected = id },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            GlassCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth().pressable({ selected = ThemeIds.CUSTOM }, pressedScale = 0.985f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(Modifier.size(44.dp).clip(RustShape.icon).background(customPalette.gradient))
                        Column(Modifier.weight(1f)) {
                            RustText(stringResource(R.string.theme_custom), RustType.rowTitle)
                            RustText(stringResource(R.string.theme_custom_s), RustType.rowSubtitle, color = RustNeutral.TextSecondary)
                        }
                        if (selected == ThemeIds.CUSTOM) RustIcon(RustGlyph.Check, tint = Rust.palette.accentBright, size = 22.dp)
                    }
                    AnimatedVisibility(visible = selected == ThemeIds.CUSTOM) {
                        ColorEditor(color = custom, onColor = { custom = it })
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
            RustButton(
                text = stringResource(if (changed) R.string.theme_apply else R.string.theme_applied),
                onClick = { onApply(selected, custom) },
                modifier = Modifier.fillMaxWidth(),
                enabled = changed,
            )
        }
    }
}
