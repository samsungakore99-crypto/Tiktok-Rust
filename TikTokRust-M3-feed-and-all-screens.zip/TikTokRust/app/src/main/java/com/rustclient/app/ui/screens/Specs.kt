package com.rustclient.app.ui.screens

import androidx.annotation.StringRes
import com.rustclient.app.R
import com.rustclient.app.Routes
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.theme.PaletteResolver
import com.rustclient.core.AppSettings
import com.rustclient.core.AppearancePrefs
import com.rustclient.core.ContentRules
import com.rustclient.core.DownloadPolicy
import com.rustclient.core.DownloadPrefs
import com.rustclient.core.FitMode
import com.rustclient.core.NotificationPrefs
import com.rustclient.core.PerformancePrefs
import com.rustclient.core.PlayerPrefs
import com.rustclient.core.PrivacyPrefs
import com.rustclient.core.Quality
import com.rustclient.core.SaveLocation
import com.rustclient.core.SettingsCodec
import kotlin.math.abs

/*
 * Settings are described as data. One renderer (SpecUi.kt) draws every row, so the Mod Features
 * categories, the Settings sub-screens, search, "show only enabled" and "reset to defaults" all
 * share the same definitions, and a new option is one entry here plus its strings.
 */

enum class ModCategory(@StringRes val label: Int, val key: String) {
    ALL(R.string.cat_all, "all"),
    CONTENT(R.string.cat_content, "content"),
    PLAYER(R.string.cat_player, "player"),
    INTERFACE(R.string.cat_interface, "interface"),
    DOWNLOADS(R.string.cat_downloads, "downloads");

    companion object {
        fun from(key: String?): ModCategory = entries.firstOrNull { it.key == key } ?: ALL
    }
}

sealed interface SpecKind

class SpecToggle(val get: (AppSettings) -> Boolean, val set: (AppSettings, Boolean) -> AppSettings) : SpecKind

class SpecChoice(
    val labels: List<Int>,
    val index: (AppSettings) -> Int,
    val set: (AppSettings, Int) -> AppSettings,
) : SpecKind

class SpecAction(val id: String) : SpecKind

class SpecWords(
    val get: (AppSettings) -> List<String>,
    val set: (AppSettings, List<String>) -> AppSettings,
    @StringRes val hint: Int,
) : SpecKind

class SpecText(
    val get: (AppSettings) -> String,
    val set: (AppSettings, String) -> AppSettings,
    @StringRes val hint: Int,
) : SpecKind

class Spec(
    val id: String,
    val glyph: RustGlyph,
    @StringRes val title: Int,
    @StringRes val sub: Int?,
    val kind: SpecKind,
    val enabled: (AppSettings) -> Boolean = { true },
    val isNew: Boolean = false,
)

class SpecGroup(
    val id: String,
    @StringRes val title: Int,
    val glyph: RustGlyph,
    val specs: List<Spec>,
    val category: ModCategory? = null,
)

fun Spec.isActive(s: AppSettings): Boolean = (kind as? SpecToggle)?.get(s) ?: true

/** Puts this option back to its default value. Actions have nothing to reset. */
fun Spec.resetIn(s: AppSettings): AppSettings {
    val d = AppSettings()
    return when (val k = kind) {
        is SpecToggle -> k.set(s, k.get(d))
        is SpecChoice -> k.set(s, k.index(d))
        is SpecWords -> k.set(s, k.get(d))
        is SpecText -> k.set(s, k.get(d))
        is SpecAction -> s
    }
}

private fun AppSettings.withContent(f: (ContentRules) -> ContentRules) = copy(content = f(content))
private fun AppSettings.withPlayer(f: (PlayerPrefs) -> PlayerPrefs) = copy(player = f(player))
private fun AppSettings.withDownloads(f: (DownloadPrefs) -> DownloadPrefs) = copy(downloads = f(downloads))
private fun AppSettings.withAppearance(f: (AppearancePrefs) -> AppearancePrefs) = copy(appearance = f(appearance))
private fun AppSettings.withPrivacy(f: (PrivacyPrefs) -> PrivacyPrefs) = copy(privacy = f(privacy))
private fun AppSettings.withNotifications(f: (NotificationPrefs) -> NotificationPrefs) = copy(notifications = f(notifications))
private fun AppSettings.withPerformance(f: (PerformancePrefs) -> PerformancePrefs) = copy(performance = f(performance))

private fun toggle(
    id: String,
    glyph: RustGlyph,
    @StringRes title: Int,
    @StringRes sub: Int,
    get: (AppSettings) -> Boolean,
    set: (AppSettings, Boolean) -> AppSettings,
    enabled: (AppSettings) -> Boolean = { true },
) = Spec(id, glyph, title, sub, SpecToggle(get, set), enabled)

private fun choice(
    id: String,
    glyph: RustGlyph,
    @StringRes title: Int,
    @StringRes sub: Int,
    labels: List<Int>,
    index: (AppSettings) -> Int,
    set: (AppSettings, Int) -> AppSettings,
) = Spec(id, glyph, title, sub, SpecChoice(labels, index, set))

private fun action(id: String, glyph: RustGlyph, @StringRes title: Int, @StringRes sub: Int, isNew: Boolean = false) =
    Spec(id, glyph, title, sub, SpecAction(id), isNew = isNew)

private val speedLabels = listOf(R.string.spd_05, R.string.spd_075, R.string.spd_1, R.string.spd_125, R.string.spd_15, R.string.spd_2)
private val qualityLabels = listOf(R.string.q_auto, R.string.q_360, R.string.q_480, R.string.q_720, R.string.q_1080)
private val downloadQualityLabels = listOf(R.string.q_best, R.string.q_360, R.string.q_480, R.string.q_720, R.string.q_1080)

object Specs {
    // ---- Content ----
    val hideAds = toggle("hide_ads", RustGlyph.Block, R.string.sp_ads_t, R.string.sp_ads_s, { it.content.hideAds }, { s, v -> s.withContent { c -> c.copy(hideAds = v) } })
    val hideLive = toggle("hide_live", RustGlyph.Live, R.string.sp_live_t, R.string.sp_live_s, { it.content.hideLive }, { s, v -> s.withContent { c -> c.copy(hideLive = v) } })
    val hidePhotos = toggle("hide_photos", RustGlyph.Image, R.string.sp_photos_t, R.string.sp_photos_s, { it.content.hidePhotos }, { s, v -> s.withContent { c -> c.copy(hidePhotos = v) } })
    val hideStories = toggle("hide_stories", RustGlyph.Story, R.string.sp_stories_t, R.string.sp_stories_s, { it.content.hideStories }, { s, v -> s.withContent { c -> c.copy(hideStories = v) } })
    val hideReposts = toggle("hide_reposts", RustGlyph.Repeat, R.string.sp_reposts_t, R.string.sp_reposts_s, { it.content.hideReposts }, { s, v -> s.withContent { c -> c.copy(hideReposts = v) } })
    val hideFriends = toggle("hide_friends", RustGlyph.Friends, R.string.sp_friends_t, R.string.sp_friends_s, { it.content.hideFriendSuggestions }, { s, v -> s.withContent { c -> c.copy(hideFriendSuggestions = v) } })
    val hideShop = toggle("hide_shop", RustGlyph.Shop, R.string.sp_shop_t, R.string.sp_shop_s, { it.content.hideShop }, { s, v -> s.withContent { c -> c.copy(hideShop = v) } })
    val mutedWords = Spec(
        "muted_words", RustGlyph.Hash, R.string.sp_words_t, R.string.sp_words_s,
        SpecWords({ it.content.mutedWords }, { s, v -> s.withContent { c -> c.copy(mutedWords = v) } }, R.string.sp_words_hint),
    )
    val mutedAccounts = Spec(
        "muted_accounts", RustGlyph.UserMinus, R.string.sp_accounts_t, R.string.sp_accounts_s,
        SpecWords({ it.content.mutedAccounts }, { s, v -> s.withContent { c -> c.copy(mutedAccounts = v) } }, R.string.sp_accounts_hint),
    )
    val maxDuration = choice(
        "max_duration", RustGlyph.Clock, R.string.sp_duration_t, R.string.sp_duration_s,
        listOf(R.string.opt_any, R.string.opt_1min, R.string.opt_3min, R.string.opt_10min),
        { SettingsCodec.durations.indexOf(it.content.maxDurationSec).coerceAtLeast(0) },
        { s, i -> s.withContent { c -> c.copy(maxDurationSec = SettingsCodec.durations[i]) } },
    )

    // ---- Player ----
    val autoplay = toggle("autoplay", RustGlyph.Play, R.string.sp_autoplay_t, R.string.sp_autoplay_s, { it.player.autoplay }, { s, v -> s.withPlayer { p -> p.copy(autoplay = v) } })
    val loop = toggle("loop", RustGlyph.Repeat, R.string.sp_loop_t, R.string.sp_loop_s, { it.player.loop }, { s, v -> s.withPlayer { p -> p.copy(loop = v) } })
    val speed = choice(
        "speed", RustGlyph.Gauge, R.string.sp_speed_t, R.string.sp_speed_s, speedLabels,
        { s -> SettingsCodec.speeds.indexOfFirst { abs(it - s.player.speed) < 0.01f }.coerceAtLeast(0) },
        { s, i -> s.withPlayer { p -> p.copy(speed = SettingsCodec.speeds[i]) } },
    )
    val muted = toggle("muted", RustGlyph.VolumeOff, R.string.sp_muted_t, R.string.sp_muted_s, { it.player.muted }, { s, v -> s.withPlayer { p -> p.copy(muted = v) } })
    val keepOn = toggle("keep_on", RustGlyph.Sun, R.string.sp_keepon_t, R.string.sp_keepon_s, { it.player.keepScreenOn }, { s, v -> s.withPlayer { p -> p.copy(keepScreenOn = v) } })
    val fit = choice(
        "fit", RustGlyph.Maximize, R.string.sp_fit_t, R.string.sp_fit_s,
        listOf(R.string.fit_fit, R.string.fit_fill, R.string.fit_zoom),
        { it.player.fit.ordinal },
        { s, i -> s.withPlayer { p -> p.copy(fit = FitMode.entries[i]) } },
    )
    val showProgress = toggle("show_progress", RustGlyph.Tune, R.string.sp_progress_t, R.string.sp_progress_s, { it.player.showProgress }, { s, v -> s.withPlayer { p -> p.copy(showProgress = v) } })
    val tapToPause = toggle("tap_pause", RustGlyph.Pause, R.string.sp_tap_t, R.string.sp_tap_s, { it.player.tapToPause }, { s, v -> s.withPlayer { p -> p.copy(tapToPause = v) } })
    val doubleTap = toggle("double_tap", RustGlyph.FastForward, R.string.sp_double_t, R.string.sp_double_s, { it.player.doubleTapSeek }, { s, v -> s.withPlayer { p -> p.copy(doubleTapSeek = v) } })
    val maxQuality = choice(
        "max_quality", RustGlyph.Video, R.string.sp_pquality_t, R.string.sp_pquality_s, qualityLabels,
        { it.player.maxQuality.ordinal },
        { s, i -> s.withPlayer { p -> p.copy(maxQuality = Quality.entries[i]) } },
    )
    val capOnCellular = toggle("cellular_cap", RustGlyph.Signal, R.string.sp_cellular_t, R.string.sp_cellular_s, { it.player.capOnCellular }, { s, v -> s.withPlayer { p -> p.copy(capOnCellular = v) } })

    // ---- Interface ----
    val theme = action("open_themes", RustGlyph.Palette, R.string.sp_theme_t, R.string.sp_theme_s)
    val animatedBg = toggle("animated_bg", RustGlyph.Monitor, R.string.sp_animbg_t, R.string.sp_animbg_s, { it.appearance.animatedBackground }, { s, v -> s.withAppearance { a -> a.copy(animatedBackground = v) } })
    val haptics = toggle("haptics", RustGlyph.Bell, R.string.sp_haptics_t, R.string.sp_haptics_s, { it.appearance.haptics }, { s, v -> s.withAppearance { a -> a.copy(haptics = v) } })
    val tabLabels = toggle("tab_labels", RustGlyph.Home, R.string.sp_labels_t, R.string.sp_labels_s, { it.appearance.showTabLabels }, { s, v -> s.withAppearance { a -> a.copy(showTabLabels = v) } })

    // ---- Downloads ----
    val allowVideo = toggle("allow_video", RustGlyph.Video, R.string.sp_dlvideo_t, R.string.sp_dlvideo_s, { it.downloads.allowVideo }, { s, v -> s.withDownloads { d -> d.copy(allowVideo = v) } })
    val allowPhoto = toggle("allow_photo", RustGlyph.Image, R.string.sp_dlphoto_t, R.string.sp_dlphoto_s, { it.downloads.allowPhoto }, { s, v -> s.withDownloads { d -> d.copy(allowPhoto = v) } })
    val dlQuality = choice(
        "dl_quality", RustGlyph.Download, R.string.sp_dlquality_t, R.string.sp_dlquality_s, downloadQualityLabels,
        { it.downloads.quality.ordinal },
        { s, i -> s.withDownloads { d -> d.copy(quality = Quality.entries[i]) } },
    )
    val location = choice(
        "dl_location", RustGlyph.Folder, R.string.sp_location_t, R.string.sp_location_s,
        listOf(R.string.loc_gallery, R.string.loc_downloads),
        { it.downloads.location.ordinal },
        { s, i -> s.withDownloads { d -> d.copy(location = SaveLocation.entries[i]) } },
    )
    val folder = Spec(
        "dl_folder", RustGlyph.Edit, R.string.sp_folder_t, R.string.sp_folder_s,
        SpecText({ it.downloads.folder }, { s, v -> s.withDownloads { d -> d.copy(folder = DownloadPolicy.safeFolder(v)) } }, R.string.sp_folder_hint),
    )
    val wifiOnly = toggle("wifi_only", RustGlyph.Wifi, R.string.sp_wifi_t, R.string.sp_wifi_s, { it.downloads.wifiOnly }, { s, v -> s.withDownloads { d -> d.copy(wifiOnly = v) } })
    val manager = action("open_downloads", RustGlyph.Download, R.string.sp_manager_t, R.string.sp_manager_s, isNew = true)

    // ---- Privacy ----
    val secureWindow = toggle("secure_window", RustGlyph.Lock, R.string.sp_secure_t, R.string.sp_secure_s, { it.privacy.secureWindow }, { s, v -> s.withPrivacy { p -> p.copy(secureWindow = v) } })
    val keepHistory = toggle("keep_history", RustGlyph.Clock, R.string.sp_history_t, R.string.sp_history_s, { it.privacy.keepHistory }, { s, v -> s.withPrivacy { p -> p.copy(keepHistory = v) } })
    val clearHistory = action("clear_history", RustGlyph.Trash, R.string.sp_clearhist_t, R.string.sp_clearhist_s)
    val resetAll = action("reset_all", RustGlyph.Refresh, R.string.sp_reset_t, R.string.sp_reset_s)

    // ---- Notifications ----
    val notifProgress = toggle("notif_progress", RustGlyph.Bell, R.string.sp_nprogress_t, R.string.sp_nprogress_s, { it.notifications.progress }, { s, v -> s.withNotifications { n -> n.copy(progress = v) } })
    val notifDone = toggle("notif_done", RustGlyph.Check, R.string.sp_ndone_t, R.string.sp_ndone_s, { it.notifications.done }, { s, v -> s.withNotifications { n -> n.copy(done = v) } })
    val systemNotif = action("notif_system", RustGlyph.Bell, R.string.sp_nsystem_t, R.string.sp_nsystem_s)

    // ---- Performance ----
    val reduceMotion = toggle("reduce_motion", RustGlyph.Pause, R.string.sp_reduce_t, R.string.sp_reduce_s, { it.performance.reduceMotion }, { s, v -> s.withPerformance { p -> p.copy(reduceMotion = v) } })
    val autoReduce = toggle("auto_reduce", RustGlyph.Bolt, R.string.sp_autoreduce_t, R.string.sp_autoreduce_s, { it.performance.autoReduceOnBatterySaver }, { s, v -> s.withPerformance { p -> p.copy(autoReduceOnBatterySaver = v) } }, enabled = { !it.performance.reduceMotion })
    val showFps = toggle("show_fps", RustGlyph.Gauge, R.string.sp_fps_t, R.string.sp_fps_s, { it.performance.showFps }, { s, v -> s.withPerformance { p -> p.copy(showFps = v) } })
    val clearCache = action("clear_cache", RustGlyph.Trash, R.string.sp_cache_t, R.string.sp_cache_s)
}

object ModCatalog {
    val groups: List<SpecGroup> = listOf(
        SpecGroup("remove", R.string.grp_remove, RustGlyph.Crown, listOf(Specs.hideAds, Specs.hideLive, Specs.hidePhotos, Specs.hideStories, Specs.hideReposts, Specs.hideFriends, Specs.hideShop), ModCategory.CONTENT),
        SpecGroup("filters", R.string.grp_filters, RustGlyph.Hash, listOf(Specs.mutedWords, Specs.mutedAccounts, Specs.maxDuration), ModCategory.CONTENT),
        SpecGroup("playback", R.string.grp_playback, RustGlyph.Play, listOf(Specs.autoplay, Specs.loop, Specs.speed, Specs.muted, Specs.keepOn), ModCategory.PLAYER),
        SpecGroup("controls", R.string.grp_controls, RustGlyph.Tune, listOf(Specs.fit, Specs.showProgress, Specs.tapToPause, Specs.doubleTap), ModCategory.PLAYER),
        SpecGroup("pquality", R.string.grp_quality, RustGlyph.Video, listOf(Specs.maxQuality, Specs.capOnCellular), ModCategory.PLAYER),
        SpecGroup("look", R.string.grp_look, RustGlyph.Palette, listOf(Specs.theme, Specs.animatedBg, Specs.haptics, Specs.tabLabels), ModCategory.INTERFACE),
        SpecGroup("downloads", R.string.grp_downloads, RustGlyph.Download, listOf(Specs.allowVideo, Specs.allowPhoto, Specs.dlQuality, Specs.location, Specs.folder, Specs.wifiOnly, Specs.manager), ModCategory.DOWNLOADS),
    )
}

object SectionCatalog {
    val privacy = listOf(
        SpecGroup("privacy", R.string.grp_privacy, RustGlyph.Lock, listOf(Specs.secureWindow, Specs.keepHistory)),
        SpecGroup("data", R.string.grp_data, RustGlyph.Trash, listOf(Specs.clearHistory, Specs.resetAll)),
    )
    val notifications = listOf(
        SpecGroup("notif", R.string.grp_notifications, RustGlyph.Bell, listOf(Specs.notifProgress, Specs.notifDone, Specs.systemNotif)),
    )
    val performance = listOf(
        SpecGroup("motion", R.string.grp_motion, RustGlyph.Gauge, listOf(Specs.reduceMotion, Specs.autoReduce, Specs.capOnCellular)),
        SpecGroup("diag", R.string.grp_diagnostics, RustGlyph.Bars, listOf(Specs.showFps, Specs.clearCache)),
    )
    val appearance = listOf(
        SpecGroup("look", R.string.grp_look, RustGlyph.Palette, listOf(Specs.theme, Specs.animatedBg, Specs.haptics, Specs.tabLabels)),
        SpecGroup("motion", R.string.grp_motion, RustGlyph.Gauge, listOf(Specs.reduceMotion, Specs.autoReduce)),
    )

    class Entry(val spec: Spec, @StringRes val groupTitle: Int, val route: String)

    /** Everything searchable from the Settings screen. The first occurrence of an option wins. */
    val index: List<Entry> by lazy {
        val out = ArrayList<Entry>()
        val seen = HashSet<String>()
        fun add(groups: List<SpecGroup>, routeOf: (SpecGroup) -> String) {
            for (g in groups) for (s in g.specs) if (seen.add(s.id)) out += Entry(s, g.title, routeOf(g))
        }
        add(ModCatalog.groups) { Routes.mod(it.category?.key ?: "all") }
        add(privacy) { Routes.SettingsPrivacy }
        add(notifications) { Routes.SettingsNotifications }
        add(performance) { Routes.SettingsPerformance }
        add(appearance) { Routes.SettingsAppearance }
        out
    }
}

/** Display name of the active theme (used as the value of the "Theme" row). */
fun themeName(s: AppSettings): String = PaletteResolver.resolve(s.appearance.themeId, s.appearance.customAccent).name
