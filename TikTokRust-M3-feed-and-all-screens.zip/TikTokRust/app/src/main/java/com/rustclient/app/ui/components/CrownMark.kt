package com.rustclient.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rustclient.app.ui.theme.LocalMotion
import com.rustclient.app.ui.theme.Rust

private const val CROWN_BODY = "M3 8 L7.5 12 L12 5 L16.5 12 L21 8 L19.5 18 H4.5 Z"

/** The brand mark: a gradient crown with a breathing glow. Re-tints with the active theme. */
@Composable
fun CrownMark(
    modifier: Modifier = Modifier,
    size: Dp = 96.dp,
    animated: Boolean = true,
) {
    val p = Rust.palette
    val body = remember { PathParser().parsePathString(CROWN_BODY).toPath() }
    val breatheState: State<Float> = if (animated && !LocalMotion.current.reduce) {
        rememberInfiniteTransition(label = "crown").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "breathe",
        )
    } else {
        remember { mutableStateOf(0.4f) }
    }
    val t = breatheState.value
    Canvas(modifier.size(size)) {
        val dim = this.size.minDimension
        val glowRadius = dim * 0.62f
        drawCircle(
            Brush.radialGradient(
                listOf(p.accent.copy(alpha = 0.30f + 0.22f * t), Color.Transparent),
                center = center,
                radius = glowRadius,
            ),
            radius = glowRadius,
            center = center,
        )
        scale(1f + 0.03f * t, pivot = center) {
            scale(dim / 24f, pivot = Offset.Zero) {
                drawPath(
                    body,
                    Brush.verticalGradient(listOf(p.accentBright, p.accent, p.accentDeep), startY = 4f, endY = 19f),
                )
                drawPath(
                    body,
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.95f), p.accentBright.copy(alpha = 0.4f)),
                        start = Offset(3f, 4f),
                        end = Offset(21f, 19f),
                    ),
                    style = Stroke(1.1f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
                drawRoundRect(
                    Brush.horizontalGradient(listOf(p.accentBright, p.accent, p.accentBright), startX = 4f, endX = 20f),
                    topLeft = Offset(4.5f, 19.7f),
                    size = Size(15f, 2.1f),
                    cornerRadius = CornerRadius(1.05f),
                )
                listOf(Offset(3f, 8f), Offset(12f, 5f), Offset(21f, 8f)).forEach { c ->
                    drawCircle(Color.White, radius = 1.35f, center = c)
                    drawCircle(p.accentBright, radius = 0.7f, center = c)
                }
            }
        }
    }
}
