package com.rustclient.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.rustclient.core.MediaKind
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.socialDataStore by preferencesDataStore(name = "rust_social")

/** A post the user made from a file on the device. [uri] stays readable through a persisted grant. */
data class PostRecord(val id: String, val uri: String, val kind: MediaKind, val caption: String, val createdAt: Long)

/** Everything "social" that exists on this device: follows, likes, saves, own posts. No server involved. */
data class Social(
    val following: Set<String> = emptySet(),
    val liked: Set<String> = emptySet(),
    val saved: Set<String> = emptySet(),
    val posts: List<PostRecord> = emptyList(),
    val inboxSeenAt: Long = 0L,
)

class SocialStore(private val context: Context) {
    private val kFollowing = stringSetPreferencesKey("following")
    private val kLiked = stringSetPreferencesKey("liked")
    private val kSaved = stringSetPreferencesKey("saved")
    private val kPosts = stringPreferencesKey("posts")
    private val kSeen = longPreferencesKey("inbox_seen")

    val social: Flow<Social> = context.socialDataStore.data.map { decode(it) }

    suspend fun update(transform: (Social) -> Social) {
        context.socialDataStore.edit { prefs -> write(prefs, transform(decode(prefs))) }
    }

    suspend fun clear() {
        context.socialDataStore.edit { it.clear() }
    }

    private fun decode(p: Preferences) = Social(
        following = p[kFollowing] ?: emptySet(),
        liked = p[kLiked] ?: emptySet(),
        saved = p[kSaved] ?: emptySet(),
        posts = parsePosts(p[kPosts]),
        inboxSeenAt = p[kSeen] ?: 0L,
    )

    private fun write(p: MutablePreferences, s: Social) {
        p[kFollowing] = s.following
        p[kLiked] = s.liked
        p[kSaved] = s.saved
        p[kPosts] = encodePosts(s.posts)
        p[kSeen] = s.inboxSeenAt
    }

    private fun parsePosts(json: String?): List<PostRecord> {
        if (json.isNullOrEmpty()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PostRecord(o.getString("id"), o.getString("uri"), MediaKind.valueOf(o.getString("kind")), o.getString("caption"), o.getLong("at"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun encodePosts(list: List<PostRecord>): String {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("uri", r.uri).put("kind", r.kind.name).put("caption", r.caption).put("at", r.createdAt))
        }
        return arr.toString()
    }
}
