package com.rustclient.app.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.rustclient.core.AccentPalette

object ThemeIds {
    const val CUSTOM = "custom"
}

/** Maps the persisted theme id (+ custom accent) to a palette. Unknown ids fall back to Midnight. */
object PaletteResolver {
    val presets: List<Pair<String, RustPalette>> = listOf(
        "midnight" to RustPalettes.Midnight,
        "purple_neon" to RustPalettes.PurpleNeon,
        "cyber_blue" to RustPalettes.CyberBlue,
        "crimson" to RustPalettes.Crimson,
        "matrix" to RustPalettes.Matrix,
        "sakura" to RustPalettes.Sakura,
    )

    fun custom(accent: Int): RustPalette {
        val p = AccentPalette.derive(accent)
        return RustPalette(
            name = "Custom",
            accentDeep = Color(p.deep),
            accent = Color(p.accent),
            accentBright = Color(p.bright),
            onAccent = Color(p.onAccent),
            glowA = Color(p.glowA),
            glowB = Color(p.glowB),
            bgTop = Color(p.bgTop),
            bgBottom = Color(p.bgBottom),
            surface = Color(p.surface),
        )
    }

    fun resolve(id: String, customAccent: Int): RustPalette =
        if (id == ThemeIds.CUSTOM) custom(customAccent) else presets.firstOrNull { it.first == id }?.second ?: RustPalettes.Midnight

    fun presetIndex(id: String): Int = presets.indexOfFirst { it.first == id }
}

/** Motion preferences resolved from settings (+ battery saver). Components read this instead of settings. */
data class MotionSpec(
    val reduce: Boolean = false,
    val animatedBackground: Boolean = true,
    val haptics: Boolean = true,
)

val LocalMotion = staticCompositionLocalOf { MotionSpec() }
