package com.rustclient.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*

/** Height of the bottom bar without the system navigation inset. */
val BottomBarHeight = 64.dp

data class BarItem(
    val key: String,
    val glyph: RustGlyph?,
    val label: String,
    val badge: String? = null,
    val isCreate: Boolean = false,
)

@Composable
fun RustBottomBar(
    items: List<BarItem>,
    selectedKey: String?,
    onSelect: (BarItem) -> Unit,
    modifier: Modifier = Modifier,
    showLabels: Boolean = true,
) {
    val p = Rust.palette
    Column(modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, p.accent.copy(alpha = 0.55f), Color.Transparent),
                    ),
                ),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(p.bgBottom.copy(alpha = 0.92f), p.bgBottom.copy(alpha = 0.98f))),
                )
                .navigationBarsPadding()
                .height(BottomBarHeight - 1.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { item ->
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    if (item.isCreate) {
                        CreateButton(item.label) { onSelect(item) }
                    } else {
                        BarTab(item, item.key == selectedKey, showLabels) { onSelect(item) }
                    }
                }
            }
        }
    }
}

@Composable
private fun BarTab(item: BarItem, selected: Boolean, showLabels: Boolean, onClick: () -> Unit) {
    val p = Rust.palette
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "tab",
    )
    val c = sel.coerceIn(0f, 1f)
    val tint = lerp(RustNeutral.TextTertiary, p.accentBright, c)
    Column(
        Modifier
            .fillMaxSize()
            .pressable(onClick, pressedScale = 0.92f)
            .semantics {
                role = Role.Tab
                this.selected = selected
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.drawBehind {
                val r = 24.dp.toPx()
                drawCircle(
                    Brush.radialGradient(
                        listOf(p.accent.copy(alpha = 0.40f * c), Color.Transparent),
                        center = center,
                        radius = r,
                    ),
                    radius = r,
                    center = center,
                )
            },
        ) {
            item.glyph?.let {
                RustIcon(
                    it,
                    Modifier.graphicsLayer {
                        val s = 1f + 0.08f * sel
                        scaleX = s
                        scaleY = s
                    },
                    tint = tint,
                    size = 24.dp,
                )
            }
            item.badge?.let {
                CountBadge(it, Modifier.align(Alignment.TopEnd).offset(x = 14.dp, y = (-6).dp))
            }
        }
        if (showLabels) {
            Spacer(Modifier.height(3.dp))
            RustText(item.label, RustType.caption, color = tint, maxLines = 1)
        }
    }
}

/** White "+" with cyan / red offset layers that snap together on press. */
@Composable
private fun CreateButton(label: String, onClick: () -> Unit) {
    val haptics = LocalHapticFeedback.current
    val motion = LocalMotion.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val spread by animateFloatAsState(
        targetValue = if (pressed) 1f else 4f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "chroma",
    )
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, RustMotion.press, label = "createScale")
    Box(
        Modifier
            .size(width = 50.dp, height = 32.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = source,
                indication = null,
                onClickLabel = label,
                role = Role.Button,
            ) {
                if (motion.haptics) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        val layer = Modifier.size(width = 42.dp, height = 32.dp)
        Box(layer.offset { IntOffset(-spread.dp.roundToPx(), 0) }.clip(RustShape.create).background(RustNeutral.Cyan))
        Box(layer.offset { IntOffset(spread.dp.roundToPx(), 0) }.clip(RustShape.create).background(RustNeutral.Danger))
        Box(layer.clip(RustShape.create).background(Color.White), contentAlignment = Alignment.Center) {
            RustIcon(RustGlyph.Plus, tint = Color(0xFF0A0710), size = 22.dp, strokeWidth = 2.6f)
        }
    }
}

@Composable
fun RustTopBar(
    title: String,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(60.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (onBack != null) GlassIconButton(RustGlyph.ChevronLeft, onBack, stringResource(R.string.back))
        RustText(title, RustType.screenTitle, Modifier.weight(1f), maxLines = 1)
        actions()
    }
}
