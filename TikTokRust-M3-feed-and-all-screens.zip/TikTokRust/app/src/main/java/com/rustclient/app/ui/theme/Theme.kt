package com.rustclient.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow

@Composable
fun RustTheme(
    palette: RustPalette = RustPalettes.Midnight,
    content: @Composable () -> Unit,
) {
    val p = animatePalette(palette)
    val scheme = darkColorScheme(
        primary = p.accent,
        onPrimary = p.onAccent,
        secondary = p.accentBright,
        background = p.bgBottom,
        onBackground = RustNeutral.TextPrimary,
        surface = p.surface,
        onSurface = RustNeutral.TextPrimary,
        surfaceVariant = p.surface,
        onSurfaceVariant = RustNeutral.TextSecondary,
        outline = RustNeutral.Hairline,
        error = RustNeutral.Danger,
    )
    CompositionLocalProvider(LocalRustPalette provides p) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}

/** Text with our tokens: always pass a [RustType] style. */
@Composable
fun RustText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    color: Color = RustNeutral.TextPrimary,
    maxLines: Int = Int.MAX_VALUE,
    textAlign: TextAlign? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        style = style,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = textAlign,
    )
}
