package com.rustclient.app.rust

import com.rustclient.core.CoreEngine
import com.rustclient.core.KotlinCoreEngine

/**
 * Optional native core. Build the crate in /rust (see rust/README.md) and place libs under
 * app/src/main/jniLibs/<abi>/librustcore.so; [isAvailable] then turns true. Until a Rust
 * implementation of [CoreEngine] is registered in [Engines], the Kotlin engine does all the work.
 */
object RustBridge {
    @Volatile private var loaded: Boolean? = null

    val isAvailable: Boolean
        get() = loaded ?: tryLoad().also { loaded = it }

    val version: String?
        get() = if (isAvailable) {
            try { nativeVersion() } catch (e: UnsatisfiedLinkError) { null }
        } else {
            null
        }

    private fun tryLoad(): Boolean = try {
        System.loadLibrary("rustcore")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    } catch (e: SecurityException) {
        false
    }

    @JvmStatic
    private external fun nativeVersion(): String
}

/** The engine every screen uses. Swap [current] to route filtering / quality picking through Rust. */
object Engines {
    @Volatile var current: CoreEngine = KotlinCoreEngine
}
