package com.rustclient.app.data

import androidx.annotation.StringRes
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

data class ToastMsg(@StringRes val res: Int, val arg: String? = null)

/** App-wide one-shot messages; the shell shows them as an animated pill. */
object Toasts {
    private val _events = MutableSharedFlow<ToastMsg>(extraBufferCapacity = 8)
    val events: SharedFlow<ToastMsg> = _events.asSharedFlow()

    fun emit(@StringRes res: Int, arg: String? = null) {
        _events.tryEmit(ToastMsg(res, arg))
    }
}
