package com.rustclient.app.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rustclient.app.R
import com.rustclient.app.data.DlState
import com.rustclient.app.data.DlStatus
import com.rustclient.app.data.DownloadRecord
import com.rustclient.app.data.DownloadStore
import com.rustclient.app.data.DownloadsGateway
import com.rustclient.app.data.Toasts
import com.rustclient.core.AppSettings
import com.rustclient.core.DownloadPolicy
import com.rustclient.core.MediaKind
import com.rustclient.core.Rejection
import com.rustclient.core.UrlCheck
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A download as the UI sees it. [status] is null when the system no longer knows the entry. */
data class DownloadUi(
    val id: Long,
    val fileName: String,
    val kind: MediaKind,
    val url: String,
    val status: DlStatus?,
    val createdAt: Long = 0L,
)

class DownloadsViewModel(app: Application) : AndroidViewModel(app) {
    private val gateway = DownloadsGateway(app)
    private val store = DownloadStore(app)

    private val _items = MutableStateFlow<List<DownloadUi>>(emptyList())
    val items: StateFlow<List<DownloadUi>> = _items.asStateFlow()

    /** Set when the user pasted a TikTok link; the screen explains the policy and offers "Open in TikTok". */
    private val _tiktokLink = MutableStateFlow<String?>(null)
    val tiktokLink: StateFlow<String?> = _tiktokLink.asStateFlow()

    fun dismissTikTokLink() {
        _tiktokLink.value = null
    }

    val hasActive: Boolean
        get() = _items.value.any {
            val s = it.status?.state
            s == DlState.RUNNING || s == DlState.QUEUED || s == DlState.PAUSED
        }

    /** Re-reads system download state. Call it periodically while the screen is visible. */
    suspend fun refresh(keepHistory: Boolean) = withContext(Dispatchers.IO) {
        var records = store.load()
        if (records.isEmpty()) {
            _items.value = emptyList()
            return@withContext
        }
        val status = gateway.query(records.map { it.id })
        val vanished = records.filter { it.id !in status }.map { it.id }.toSet()
        val finished = if (keepHistory) emptySet() else status.filter { it.value.state == DlState.DONE }.keys
        val drop = vanished + finished
        if (drop.isNotEmpty()) {
            store.remove(drop)
            records = records.filter { it.id !in drop }
        }
        _items.value = records.sortedByDescending { it.createdAt }
            .map { DownloadUi(it.id, it.fileName, it.kind, it.url, status[it.id], it.createdAt) }
    }

    fun submit(raw: String, settings: AppSettings) {
        viewModelScope.launch {
            when (val check = DownloadPolicy.check(raw)) {
                is UrlCheck.Rejected -> when (check.reason) {
                    Rejection.TIKTOK_HOST -> _tiktokLink.value = raw.trim()
                    Rejection.NOT_HTTPS -> Toasts.emit(R.string.dl_err_https)
                    else -> Toasts.emit(R.string.dl_err_invalid)
                }
                is UrlCheck.Ok -> enqueueChecked(check, settings)
            }
        }
    }

    private suspend fun enqueueChecked(check: UrlCheck.Ok, s: AppSettings) {
        val declared = check.kind
        var name = check.fileName
        val kind: MediaKind
        if (declared != null) {
            kind = declared
        } else {
            val probe = gateway.probe(check.url)
            if (probe == null) {
                Toasts.emit(R.string.dl_err_network)
                return
            }
            if (probe.code !in 200..299) {
                Toasts.emit(R.string.dl_err_http, probe.code.toString())
                return
            }
            val fromMime = DownloadPolicy.kindFromMime(probe.mime)
            if (fromMime == null) {
                Toasts.emit(R.string.dl_err_type)
                return
            }
            kind = fromMime
            name = DownloadPolicy.withExtension(name, DownloadPolicy.extensionFor(probe.mime, kind))
        }
        val allowed = if (kind == MediaKind.VIDEO) s.downloads.allowVideo else s.downloads.allowPhoto
        if (!allowed) {
            Toasts.emit(if (kind == MediaKind.VIDEO) R.string.dl_err_video_off else R.string.dl_err_photo_off)
            return
        }
        val id = try {
            gateway.enqueue(check.url, name, kind, s.downloads, s.notifications)
        } catch (e: Exception) {
            Toasts.emit(R.string.dl_err_enqueue)
            return
        }
        store.add(DownloadRecord(id, check.url, name, kind, System.currentTimeMillis()))
        Toasts.emit(R.string.dl_started, name)
        refresh(s.privacy.keepHistory)
    }

    fun retry(item: DownloadUi, settings: AppSettings) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                gateway.remove(item.id)
                store.remove(setOf(item.id))
            }
            enqueueChecked(UrlCheck.Ok(item.url, item.kind, item.fileName), settings)
        }
    }

    /** Cancels a running download or deletes the finished file. */
    fun deleteFile(item: DownloadUi, keepHistory: Boolean) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                gateway.remove(item.id)
                store.remove(setOf(item.id))
            }
            refresh(keepHistory)
        }
    }

    /** Forgets the entry but leaves the file on the device. */
    fun forget(item: DownloadUi, keepHistory: Boolean) {
        viewModelScope.launch {
            store.remove(setOf(item.id))
            refresh(keepHistory)
        }
    }

    /** Removes finished and failed entries from the list; files stay on the device. */
    fun clearHistory() {
        viewModelScope.launch {
            val ids = _items.value.filter {
                val s = it.status?.state
                s == null || s == DlState.DONE || s == DlState.FAILED
            }.map { it.id }.toSet()
            store.remove(ids)
            _items.value = _items.value.filter { it.id !in ids }
            Toasts.emit(R.string.toast_history_cleared)
        }
    }
}
