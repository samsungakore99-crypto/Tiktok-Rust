package com.rustclient.app

import android.app.Activity
import android.graphics.Bitmap
import android.view.WindowManager
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rustclient.app.data.AvatarStore
import com.rustclient.app.data.FeedRepository
import com.rustclient.app.data.Launch
import com.rustclient.app.data.Toasts
import com.rustclient.app.data.rememberPowerSave
import com.rustclient.app.rust.Engines
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.feed.FeedActions
import com.rustclient.app.ui.feed.FeedScreen
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.screens.*
import com.rustclient.app.ui.theme.LocalMotion
import com.rustclient.app.ui.theme.MotionSpec
import com.rustclient.app.ui.theme.PaletteResolver
import com.rustclient.app.ui.theme.RustTheme
import com.rustclient.app.vm.AppViewModel
import com.rustclient.app.vm.DownloadsViewModel
import com.rustclient.app.vm.PlayerRequest
import com.rustclient.app.vm.SocialViewModel
import com.rustclient.core.AppSettings
import com.rustclient.core.ContentKind
import com.rustclient.core.FeedItem
import com.rustclient.core.MediaKind
import com.rustclient.core.MediaVariant
import com.rustclient.core.SearchEngine

object Routes {
    const val Home = "home"
    const val Friends = "friends"
    const val Create = "create"
    const val Inbox = "inbox"
    const val Profile = "profile"

    const val Settings = "settings"
    const val SettingsAccount = "settings/account"
    const val SettingsPrivacy = "settings/privacy"
    const val SettingsNotifications = "settings/notifications"
    const val SettingsAppearance = "settings/appearance"
    const val SettingsPerformance = "settings/performance"

    const val ModFunctions = "mod"
    const val ModPattern = "mod?cat={cat}"
    fun mod(category: String = "all") = "mod?cat=$category"

    const val UserPattern = "user/{handle}"
    fun user(handle: String) = "user/$handle"

    const val Themes = "themes"
    const val Downloads = "downloads"
    const val Search = "search"
    const val Player = "player"
    const val About = "about"
    const val Gallery = "gallery"

    val tabs = setOf(Home, Friends, Create, Inbox, Profile)
    val withBottomBar = setOf(Home, Friends, Inbox, Profile, Settings)
}

@Composable
fun RustApp() {
    val vm: AppViewModel = viewModel()
    val downloads: DownloadsViewModel = viewModel()
    val social: SocialViewModel = viewModel()
    val loaded by vm.settings.collectAsStateWithLifecycle()
    val s = loaded
    if (s == null) {
        Box(Modifier.fillMaxSize().background(Color(0xFF04030A)))
        return
    }

    val context = LocalContext.current
    val powerSave = rememberPowerSave()
    val motion = MotionSpec(
        reduce = s.performance.reduceMotion || (s.performance.autoReduceOnBatterySaver && powerSave),
        animatedBackground = s.appearance.animatedBackground,
        haptics = s.appearance.haptics,
    )
    val palette = PaletteResolver.resolve(s.appearance.themeId, s.appearance.customAccent)

    LaunchedEffect(s.privacy.secureWindow) {
        val window = (context as? Activity)?.window ?: return@LaunchedEffect
        if (s.privacy.secureWindow) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    val avatar by produceState<Bitmap?>(null, s.profile.avatarRev) { value = AvatarStore.load(context) }

    RustTheme(palette) {
        CompositionLocalProvider(LocalMotion provides motion) {
            Shell(settings = s, avatar = avatar, vm = vm, downloads = downloads, socialVm = social)
        }
    }
}

private fun isTab(entry: NavBackStackEntry) = entry.destination.route in Routes.tabs

@Composable
private fun Shell(settings: AppSettings, avatar: Bitmap?, vm: AppViewModel, downloads: DownloadsViewModel, socialVm: SocialViewModel) {
    val context = LocalContext.current
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = route in Routes.withBottomBar
    val reduce = LocalMotion.current.reduce
    val social by socialVm.social.collectAsStateWithLifecycle()
    val downloadItems by downloads.items.collectAsStateWithLifecycle()
    val keepHistory = settings.privacy.keepHistory
    val myHandle = settings.profile.handle

    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val barSpace by animateDpAsState(if (showBar) BottomBarHeight else 0.dp, tween(260), label = "barSpace")

    LaunchedEffect(keepHistory) {
        while (true) {
            downloads.refresh(keepHistory)
            kotlinx.coroutines.delay(4000)
        }
    }

    val allItems = remember(social.posts, myHandle) { FeedRepository.all(context.packageName, social, myHandle) }
    val visibleItems = remember(allItems, settings.content) { Engines.current.filter(allItems, settings.content).visible }
    val accounts = remember(allItems) { SearchEngine.accounts(allItems) }
    val unread = downloadItems.count {
        val state = it.status?.state
        (state == com.rustclient.app.data.DlState.DONE || state == com.rustclient.app.data.DlState.FAILED) && it.createdAt > social.inboxSeenAt
    }

    val onUpdate: Update = { transform -> vm.update(transform) }
    val back: () -> Unit = { nav.popBackStack() }
    val open: (String) -> Unit = { target -> nav.navigate(target) { launchSingleTop = true } }
    val goTab: (String) -> Unit = { target ->
        nav.navigate(target) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    val handleAction: (String) -> Unit = { id ->
        when (id) {
            "language" -> Launch.language(context)
            else -> Unit
        }
    }
    val openProfile: (String) -> Unit = { handle -> if (handle == myHandle) goTab(Routes.Profile) else open(Routes.user(handle)) }
    val openPost: (FeedItem) -> Unit = { item ->
        val title = item.caption.ifBlank { item.author }
        when (item.kind) {
            ContentKind.VIDEO, ContentKind.REPOST -> {
                socialVm.openPlayer(PlayerRequest(title, MediaKind.VIDEO, item.variants))
                open(Routes.Player)
            }
            ContentKind.PHOTO -> {
                socialVm.openPlayer(PlayerRequest(title, MediaKind.PHOTO, item.variants, FeedRepository.photoRes(item.id)))
                open(Routes.Player)
            }
            else -> openProfile(item.author.trimStart('@'))
        }
    }
    val feedActions = FeedActions(
        onToggleFollow = { socialVm.toggleFollow(it) },
        onToggleLike = { socialVm.toggleLike(it) },
        onToggleSave = { socialVm.toggleSave(it) },
        onOpenSearch = { open(Routes.Search) },
        onOpenProfile = openProfile,
        onOpenPlayer = openPost,
        onNotInterested = { handle ->
            onUpdate { s ->
                s.copy(content = s.content.copy(mutedAccounts = (s.content.mutedAccounts + handle).distinctBy { it.lowercase() }))
            }
            Toasts.emit(R.string.toast_muted, handle)
        },
        onOpenFilters = { open(Routes.mod("content")) },
        onShare = { item -> Launch.shareText(context, item.author + ": " + item.caption) },
    )

    val items = listOf(
        BarItem(Routes.Home, RustGlyph.Home, stringResource(R.string.tab_home)),
        BarItem(Routes.Friends, RustGlyph.Friends, stringResource(R.string.tab_friends)),
        BarItem(Routes.Create, null, stringResource(R.string.tab_create), isCreate = true),
        BarItem(Routes.Inbox, RustGlyph.Inbox, stringResource(R.string.tab_inbox), badge = if (unread > 0) (if (unread > 99) "99+" else "$unread") else null),
        BarItem(Routes.Profile, RustGlyph.Profile, stringResource(R.string.tab_profile)),
    )

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()

        Box(Modifier.fillMaxSize().padding(bottom = barSpace + navInset)) {
            NavHost(
                navController = nav,
                startDestination = Routes.Home,
                modifier = Modifier.fillMaxSize(),
                enterTransition = {
                    if (reduce) {
                        fadeIn(tween(120))
                    } else if (isTab(initialState) && isTab(targetState)) {
                        fadeIn(tween(240, 60)) + scaleIn(tween(240, 60), 0.98f)
                    } else {
                        slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it / 6 } + fadeIn(tween(260))
                    }
                },
                exitTransition = {
                    if (reduce) {
                        fadeOut(tween(90))
                    } else if (isTab(initialState) && isTab(targetState)) {
                        fadeOut(tween(120))
                    } else {
                        slideOutHorizontally(tween(320, easing = FastOutSlowInEasing)) { -it / 8 } + fadeOut(tween(200))
                    }
                },
                popEnterTransition = {
                    if (reduce) {
                        fadeIn(tween(120))
                    } else {
                        slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { -it / 8 } + fadeIn(tween(260))
                    }
                },
                popExitTransition = {
                    if (reduce) {
                        fadeOut(tween(90))
                    } else {
                        slideOutHorizontally(tween(320, easing = FastOutSlowInEasing)) { it / 6 } + fadeOut(tween(200))
                    }
                },
            ) {
                composable(Routes.Home) { FeedScreen(visibleItems, social, settings, accounts, feedActions) }
                composable(Routes.Friends) {
                    FriendsScreen(
                        following = social.following,
                        suggestions = accounts.filter { it != myHandle },
                        onToggleFollow = { socialVm.toggleFollow(it) },
                        onOpenProfile = openProfile,
                        onOpenSearch = { open(Routes.Search) },
                    )
                }
                composable(Routes.Create) {
                    CreateScreen(
                        onBack = back,
                        onPost = { uri, kind, caption ->
                            socialVm.addPost(uri, kind, caption)
                            nav.popBackStack()
                            goTab(Routes.Profile)
                        },
                    )
                }
                composable(Routes.Inbox) {
                    DisposableEffect(Unit) { onDispose { socialVm.markInboxSeen(System.currentTimeMillis()) } }
                    InboxScreen(events = downloadItems, seenAt = social.inboxSeenAt, onOpen = { open(Routes.Downloads) })
                }
                composable(Routes.Profile) {
                    ProfileScreen(
                        handle = null,
                        settings = settings,
                        avatar = avatar,
                        social = social,
                        allItems = allItems,
                        onBack = null,
                        onEdit = { open(Routes.SettingsAccount) },
                        onSettings = { open(Routes.Settings) },
                        onDownloads = { open(Routes.Downloads) },
                        onToggleFollow = { socialVm.toggleFollow(it) },
                        onOpenPost = openPost,
                        onDeletePost = { socialVm.deletePost(it) },
                    )
                }
                composable(Routes.UserPattern, arguments = listOf(navArgument("handle") { type = NavType.StringType })) { backStackEntry ->
                    ProfileScreen(
                        handle = backStackEntry.arguments?.getString("handle") ?: myHandle,
                        settings = settings,
                        avatar = null,
                        social = social,
                        allItems = allItems,
                        onBack = back,
                        onEdit = {},
                        onSettings = {},
                        onDownloads = {},
                        onToggleFollow = { socialVm.toggleFollow(it) },
                        onOpenPost = openPost,
                        onDeletePost = {},
                    )
                }
                composable(Routes.Search) {
                    SearchScreen(
                        items = visibleItems,
                        social = social,
                        myHandle = myHandle,
                        onBack = back,
                        onToggleFollow = { socialVm.toggleFollow(it) },
                        onOpenProfile = openProfile,
                        onOpenPost = openPost,
                    )
                }
                composable(Routes.Player) {
                    val request by socialVm.player.collectAsStateWithLifecycle()
                    PlayerScreen(request, settings, onClose = back)
                }
                composable(Routes.About) { AboutScreen(onBack = back, onOpenGallery = { open(Routes.Gallery) }) }
                composable(Routes.Gallery) {
                    GalleryScreen(
                        selectedPalette = PaletteResolver.presetIndex(settings.appearance.themeId),
                        onSelectPalette = { index ->
                            onUpdate { s -> s.copy(appearance = s.appearance.copy(themeId = PaletteResolver.presets[index].first)) }
                        },
                    )
                }

                composable(Routes.Settings) {
                    SettingsScreen(settings, avatar, onNavigate = open, onBack = back, onAction = handleAction)
                }
                composable(Routes.SettingsAccount) {
                    AccountScreen(
                        settings = settings,
                        avatar = avatar,
                        onSave = { name, handle, bio ->
                            onUpdate { s -> s.copy(profile = s.profile.copy(displayName = name, handle = handle, bio = bio)) }
                            Toasts.emit(R.string.toast_saved)
                        },
                        onAvatarPicked = { uri -> vm.setAvatar(uri) },
                        onRemoveAvatar = { vm.removeAvatar() },
                        onBack = back,
                        onOpenUrl = { url -> Launch.url(context, url) },
                    )
                }
                composable(Routes.SettingsPrivacy) {
                    PrivacyScreen(
                        settings = settings,
                        onUpdate = onUpdate,
                        onBack = back,
                        onClearHistory = { downloads.clearHistory() },
                        onResetAll = { vm.resetAll() },
                    )
                }
                composable(Routes.SettingsNotifications) { NotificationsScreen(settings, onUpdate, back) }
                composable(Routes.SettingsAppearance) { AppearanceScreen(settings, onUpdate, back, open) }
                composable(Routes.SettingsPerformance) { PerformanceScreen(settings, onUpdate, back) }

                composable(
                    Routes.ModPattern,
                    arguments = listOf(navArgument("cat") {
                        type = NavType.StringType
                        defaultValue = "all"
                    }),
                ) { backStackEntry ->
                    ModFeaturesScreen(
                        initialCategory = backStackEntry.arguments?.getString("cat") ?: "all",
                        settings = settings,
                        onUpdate = onUpdate,
                        onBack = back,
                        onNavigate = open,
                    )
                }
                composable(Routes.Themes) {
                    ThemesScreen(
                        settings = settings,
                        onApply = { id, accent ->
                            onUpdate { s -> s.copy(appearance = s.appearance.copy(themeId = id, customAccent = accent)) }
                            Toasts.emit(R.string.toast_theme_applied)
                        },
                        onBack = back,
                    )
                }
                composable(Routes.Downloads) {
                    DownloadsScreen(
                        vm = downloads,
                        settings = settings,
                        onBack = back,
                        onPlayVideo = { title, uri ->
                            socialVm.openPlayer(PlayerRequest(title, MediaKind.VIDEO, listOf(MediaVariant(uri, 0))))
                            open(Routes.Player)
                        },
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showBar,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(260)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(160)),
        ) {
            RustBottomBar(
                items = items,
                selectedKey = if (route == Routes.Settings) Routes.Profile else route,
                onSelect = { item ->
                    if (item.key == Routes.Create) {
                        open(Routes.Create)
                    } else if (item.key != route) {
                        goTab(item.key)
                    }
                },
                showLabels = settings.appearance.showTabLabels,
            )
        }

        ToastHost(Modifier.align(Alignment.BottomCenter).padding(bottom = barSpace + navInset + 16.dp))
    }
}
