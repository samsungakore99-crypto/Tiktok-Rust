package com.rustclient.app.ui.feed

import android.graphics.Bitmap
import android.net.Uri
import android.view.LayoutInflater
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.rustclient.app.R
import com.rustclient.app.data.DeviceStats
import com.rustclient.app.data.FeedRepository
import com.rustclient.app.data.Social
import com.rustclient.app.data.decodeScaled
import com.rustclient.app.rust.Engines
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.screens.NeonSkyline
import com.rustclient.app.ui.screens.SampleTag
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings
import com.rustclient.core.ContentKind
import com.rustclient.core.FeedItem
import com.rustclient.core.FitMode
import com.rustclient.core.PlayerPrefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FeedActions(
    val onToggleFollow: (String) -> Unit,
    val onToggleLike: (String) -> Unit,
    val onToggleSave: (String) -> Unit,
    val onOpenSearch: () -> Unit,
    val onOpenProfile: (String) -> Unit,
    val onOpenPlayer: (FeedItem) -> Unit,
    val onNotInterested: (String) -> Unit,
    val onOpenFilters: () -> Unit,
    val onShare: (FeedItem) -> Unit,
)

private fun FeedItem.isVideoLike() = kind == ContentKind.VIDEO || kind == ContentKind.REPOST
private fun FeedItem.hasMedia() = isVideoLike() || kind == ContentKind.PHOTO
private fun FeedItem.handle() = author.trimStart('@')

/**
 * The home feed: vertical pager, one shared Media3 player, every player option from Mod Features applied,
 * content filters already applied to [items] by the core engine. Likes, saves and follows are stored on the device.
 */
@OptIn(UnstableApi::class)
@Composable
fun FeedScreen(items: List<FeedItem>, social: Social, settings: AppSettings, accounts: List<String>, actions: FeedActions) {
    val context = LocalContext.current
    val prefs = settings.player
    var tab by rememberSaveable { mutableStateOf(1) }
    val shown = remember(items, social.following, tab) {
        if (tab == 0) items.filter { it.author.trimStart('@') in social.following } else items
    }
    val pager = rememberPagerState(pageCount = { shown.size })
    val scope = rememberCoroutineScope()
    val current = shown.getOrNull(pager.currentPage)

    val exo = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(exo) { onDispose { exo.release() } }
    val metered = remember { DeviceStats.isMetered(context) }
    val variant = current?.takeIf { it.isVideoLike() }?.let {
        Engines.current.pickVariant(it.variants, prefs.maxQuality, metered, prefs.capOnCellular)
    }

    LaunchedEffect(variant?.url) {
        val url = variant?.url
        if (url != null) {
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
        } else {
            exo.stop()
            exo.clearMediaItems()
        }
    }
    LaunchedEffect(variant?.url, prefs.autoplay) { exo.playWhenReady = variant != null && prefs.autoplay }
    LaunchedEffect(prefs.loop) { exo.repeatMode = if (prefs.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF }
    LaunchedEffect(prefs.speed) { exo.setPlaybackSpeed(prefs.speed) }
    LaunchedEffect(prefs.muted) { exo.volume = if (prefs.muted) 0f else 1f }

    val owner = LocalLifecycleOwner.current
    var resumeAfterPause by remember { mutableStateOf(false) }
    DisposableEffect(owner, exo) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                resumeAfterPause = exo.isPlaying
                exo.pause()
            } else if (event == Lifecycle.Event.ON_RESUME && resumeAfterPause) {
                exo.play()
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    var position by remember { mutableStateOf(0L) }
    var duration by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(exo) {
        while (true) {
            position = exo.currentPosition
            duration = exo.duration.coerceAtLeast(0L)
            playing = exo.isPlaying
            delay(100)
        }
    }
    LaunchedEffect(flash) {
        if (flash != null) {
            delay(650)
            flash = null
        }
    }
    val liveIndex = shown.indexOfFirst { it.kind == ContentKind.LIVE }
    val searchLabel = stringResource(R.string.action_search)

    Box(Modifier.fillMaxSize()) {
        if (shown.isEmpty()) {
            EmptyFeed(followingTab = tab == 0, actions = actions)
        } else {
            VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                val item = shown.getOrNull(page)
                if (item != null) {
                    FeedPage(
                        item = item,
                        isCurrent = page == pager.currentPage,
                        exo = exo,
                        playing = playing,
                        prefs = prefs,
                        social = social,
                        accounts = accounts,
                        qualityHeight = variant?.height ?: 0,
                        actions = actions,
                        onSeekFlash = { flash = it },
                    )
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(64.dp)) {
                if (liveIndex >= 0) {
                    Box(
                        Modifier
                            .pressable({ scope.launch { pager.animateScrollToPage(liveIndex) } }, pressedScale = 0.92f)
                            .clip(RustShape.pill)
                            .background(RustNeutral.Danger)
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                    ) { RustText("LIVE", RustType.label, color = Color.White) }
                }
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterHorizontally)) {
                FeedTab(stringResource(R.string.feed_following), tab == 0) { tab = 0 }
                FeedTab(stringResource(R.string.feed_for_you), tab == 1) { tab = 1 }
            }
            Box(Modifier.width(64.dp), contentAlignment = Alignment.CenterEnd) {
                Box(
                    Modifier.size(44.dp).pressable(actions.onOpenSearch, pressedScale = 0.9f).semantics {
                        contentDescription = searchLabel
                        role = Role.Button
                    },
                    contentAlignment = Alignment.Center,
                ) { RustIcon(RustGlyph.Search, tint = Color.White, size = 26.dp) }
            }
        }
        if (current != null && current.isVideoLike() && prefs.showProgress) {
            RustProgress(
                progress = if (duration > 0) position.toFloat() / duration else 0f,
                modifier = Modifier.align(Alignment.BottomCenter),
                height = 3.dp,
            )
        }
        flash?.let {
            RustText(it, RustType.screenTitle, Modifier.align(Alignment.Center), color = Color.White)
        }
    }
}

@Composable
private fun FeedTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val p = Rust.palette
    Column(Modifier.pressable(onClick, pressedScale = 0.95f), horizontalAlignment = Alignment.CenterHorizontally) {
        RustText(label, RustType.sectionTitle, color = if (selected) Color.White else Color.White.copy(alpha = 0.6f), maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(28.dp).height(3.dp).clip(RustShape.pill).background(if (selected) p.accentBright else Color.Transparent))
    }
}

@Composable
private fun EmptyFeed(followingTab: Boolean, actions: FeedActions) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CrownMark(size = 96.dp)
        Spacer(Modifier.height(18.dp))
        RustText(
            stringResource(if (followingTab) R.string.feed_empty_following_t else R.string.feed_empty_filtered_t),
            RustType.screenTitle,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        RustText(
            stringResource(if (followingTab) R.string.feed_empty_following_s else R.string.feed_empty_filtered_s),
            RustType.rowSubtitle,
            color = RustNeutral.TextSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        RustButton(
            stringResource(if (followingTab) R.string.action_search else R.string.feed_filters),
            if (followingTab) actions.onOpenSearch else actions.onOpenFilters,
            icon = if (followingTab) RustGlyph.Search else RustGlyph.Tune,
            height = 46.dp,
        )
    }
}

@Composable
private fun PhotoLayer(item: FeedItem) {
    val context = LocalContext.current
    val res = FeedRepository.photoRes(item.id)
    if (res != null) {
        Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        val url = item.variants.firstOrNull()?.url
        val bitmap by produceState<Bitmap?>(null, url) {
            value = if (url != null) decodeScaled(context, Uri.parse(url), 1280) else null
        }
        bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoLayer(exo: ExoPlayer, isCurrent: Boolean, prefs: PlayerPrefs) {
    val p = Rust.palette
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.accent.copy(alpha = 0.4f), p.bgBottom)))) {
        NeonSkyline(p, Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(320.dp))
        AndroidView(
            factory = { ctx -> LayoutInflater.from(ctx).inflate(R.layout.view_player_texture, null, false) as PlayerView },
            update = { view ->
                view.player = if (isCurrent) exo else null
                view.resizeMode = when (prefs.fit) {
                    FitMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    FitMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    FitMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
                view.keepScreenOn = isCurrent && prefs.keepScreenOn
            },
            modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
private fun HeartBurst(tick: Int, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(tick) {
        if (tick > 0) {
            visible = true
            delay(650)
            visible = false
        }
    }
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = scaleIn(spring(dampingRatio = 0.4f), 0.3f) + fadeIn(tween(80)),
        exit = scaleOut(tween(250), 1.4f) + fadeOut(tween(250)),
    ) { RustIcon(RustGlyph.Heart, tint = RustNeutral.Danger, size = 120.dp, strokeWidth = 2.4f) }
}

@Composable
private fun RailButton(glyph: RustGlyph, label: String, active: Boolean, activeColor: Color, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (active) 1.12f else 1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium), label = "rail")
    Box(
        Modifier.size(46.dp).pressable(onClick, pressedScale = 0.88f).semantics {
            contentDescription = label
            role = Role.Button
        },
        contentAlignment = Alignment.Center,
    ) {
        RustIcon(
            glyph,
            Modifier.graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
            tint = if (active) activeColor else Color.White,
            size = 30.dp,
            strokeWidth = if (active) 2.4f else 1.9f,
        )
    }
}

@Composable
private fun FeedPage(
    item: FeedItem,
    isCurrent: Boolean,
    exo: ExoPlayer,
    playing: Boolean,
    prefs: PlayerPrefs,
    social: Social,
    accounts: List<String>,
    qualityHeight: Int,
    actions: FeedActions,
    onSeekFlash: (String) -> Unit,
) {
    val context = LocalContext.current
    var burst by remember { mutableStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    val liked = item.id in social.liked
    val saved = item.id in social.saved
    val handle = item.handle()
    val following = handle in social.following
    val mine = FeedRepository.isMine(item)
    val likedNow by rememberUpdatedState(liked)
    val actionsNow by rememberUpdatedState(actions)

    Box(
        Modifier.fillMaxSize().pointerInput(item.id, isCurrent, prefs.tapToPause, prefs.doubleTapSeek) {
            detectTapGestures(
                onTap = {
                    if (isCurrent && item.isVideoLike()) {
                        if (exo.playbackState == Player.STATE_ENDED) {
                            exo.seekTo(0)
                            exo.play()
                        } else if (prefs.tapToPause) {
                            if (exo.isPlaying) exo.pause() else exo.play()
                        }
                    }
                },
                onDoubleTap = { offset ->
                    val third = size.width / 3f
                    val seekable = prefs.doubleTapSeek && isCurrent && item.isVideoLike()
                    if (seekable && offset.x < third) {
                        exo.seekTo((exo.currentPosition - 10_000L).coerceAtLeast(0L))
                        onSeekFlash("−10 s")
                    } else if (seekable && offset.x > 2 * third) {
                        val target = exo.currentPosition + 10_000L
                        exo.seekTo(if (exo.duration > 0) minOf(target, exo.duration) else target)
                        onSeekFlash("+10 s")
                    } else if (item.hasMedia()) {
                        if (!likedNow) actionsNow.onToggleLike(item.id)
                        burst++
                    }
                },
            )
        },
    ) {
        when {
            item.isVideoLike() -> VideoLayer(exo, isCurrent, prefs)
            item.kind == ContentKind.PHOTO -> PhotoLayer(item)
            else -> SpecialCard(item, accounts, social.following, actions.onToggleFollow, actions.onOpenProfile)
        }
        if (item.hasMedia()) {
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(280.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)))),
            )
            Column(
                Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 84.dp, bottom = 22.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (item.kind == ContentKind.REPOST) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        RustIcon(RustGlyph.Repeat, tint = Color.White.copy(alpha = 0.8f), size = 16.dp)
                        RustText(stringResource(R.string.feed_reposted), RustType.caption, color = Color.White.copy(alpha = 0.8f))
                    }
                }
                RustText(item.author, RustType.sectionTitle, Modifier.pressable({ actions.onOpenProfile(handle) }, pressedScale = 0.97f), color = Color.White, maxLines = 1)
                if (item.caption.isNotBlank()) RustText(item.caption, RustType.rowTitle, color = Color.White.copy(alpha = 0.9f), maxLines = 3)
                if (item.tags.isNotEmpty()) {
                    RustText(item.tags.joinToString(" ") { "#$it" }, RustType.rowSubtitle, color = Rust.palette.accentBright, maxLines = 1)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!mine) SampleTag()
                    if (isCurrent && item.isVideoLike() && qualityHeight > 0) {
                        RustText("${qualityHeight}p", RustType.caption, color = Color.White.copy(alpha = 0.7f))
                    }
                }
            }
            Column(
                Modifier.align(Alignment.BottomEnd).padding(end = 8.dp, bottom = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(Modifier.padding(bottom = 10.dp)) {
                    Avatar(null, handle, 52.dp, Modifier.pressable({ actions.onOpenProfile(handle) }, pressedScale = 0.92f))
                    if (!following && !mine) {
                        Box(
                            Modifier.align(Alignment.BottomCenter).offset(y = 10.dp).size(24.dp)
                                .pressable({ actions.onToggleFollow(handle) }, pressedScale = 0.85f)
                                .clip(CircleShape).background(RustNeutral.Danger),
                            contentAlignment = Alignment.Center,
                        ) { RustIcon(RustGlyph.Plus, tint = Color.White, size = 14.dp, strokeWidth = 2.6f) }
                    }
                }
                RailButton(RustGlyph.Heart, stringResource(R.string.feed_like), liked, RustNeutral.Danger) { actions.onToggleLike(item.id) }
                RailButton(RustGlyph.Bookmark, stringResource(R.string.feed_save), saved, RustNeutral.Gold) { actions.onToggleSave(item.id) }
                RailButton(RustGlyph.Share, stringResource(R.string.feed_share), false, Color.White) { actions.onShare(item) }
                if (item.isVideoLike()) RailButton(RustGlyph.Maximize, stringResource(R.string.feed_fullscreen), false, Color.White) { actions.onOpenPlayer(item) }
                RailButton(RustGlyph.More, stringResource(R.string.feed_more), false, Color.White) { menu = true }
            }
        }
        if (isCurrent && item.isVideoLike() && !playing) {
            Box(
                Modifier.align(Alignment.Center).size(64.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center,
            ) { RustIcon(RustGlyph.Play, tint = Color.White, size = 30.dp) }
        }
        HeartBurst(burst, Modifier.align(Alignment.Center))
    }
    if (menu) {
        ActionSheetDialog(
            title = item.author,
            actions = listOf(
                SheetAction(stringResource(R.string.feed_open_profile), RustGlyph.Profile, onClick = { actions.onOpenProfile(handle) }),
                SheetAction(stringResource(R.string.feed_filters), RustGlyph.Tune, onClick = { actions.onOpenFilters() }),
            ) + if (mine) {
                emptyList<SheetAction>()
            } else {
                listOf(SheetAction(stringResource(R.string.feed_not_interested, handle), RustGlyph.Block, destructive = true, onClick = { actions.onNotInterested(handle) }))
            },
            onDismiss = { menu = false },
        )
    }
}
