package com.rustclient.app.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Colours that stay the same in every theme. */
object RustNeutral {
    val TextPrimary = Color(0xFFF6F3FF)
    val TextSecondary = Color(0xFFA39CB8)
    val TextTertiary = Color(0xFF746D8A)
    val Hairline = Color(0x14FFFFFF)
    val OffTrack = Color(0xFF2B2638)
    val Success = Color(0xFF34D399)
    val Danger = Color(0xFFFE2C55)
    val Cyan = Color(0xFF25F4EE)
    val Gold = Color(0xFFF5C451)
}

/** Everything that changes when the user picks another theme. */
@Immutable
data class RustPalette(
    val name: String,
    val accentDeep: Color,
    val accent: Color,
    val accentBright: Color,
    val onAccent: Color,
    val glowA: Color,
    val glowB: Color,
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
)

/** Primary gradient used by buttons, active chips and switches. */
val RustPalette.gradient: Brush
    get() = Brush.horizontalGradient(listOf(accentDeep, accent))

private fun palette(
    name: String,
    deep: Long,
    accent: Long,
    bright: Long,
    on: Long,
    glowA: Long,
    glowB: Long,
    top: Long,
    bottom: Long,
    surface: Long,
) = RustPalette(
    name = name,
    accentDeep = Color(deep),
    accent = Color(accent),
    accentBright = Color(bright),
    onAccent = Color(on),
    glowA = Color(glowA),
    glowB = Color(glowB),
    bgTop = Color(top),
    bgBottom = Color(bottom),
    surface = Color(surface),
)

object RustPalettes {
    val Midnight = palette("Midnight", 0xFF5B21D6, 0xFF7B3CFC, 0xFFA27BFF, 0xFFFFFFFF, 0xFF6D28D9, 0xFF2E1A7A, 0xFF0B0618, 0xFF04030A, 0xFF17121F)
    val PurpleNeon = palette("Purple Neon", 0xFF7E22CE, 0xFFA23CFF, 0xFFD17BFF, 0xFFFFFFFF, 0xFFB026FF, 0xFF5B21D6, 0xFF140622, 0xFF06030C, 0xFF1B1127)
    val CyberBlue = palette("Cyber Blue", 0xFF1D4ED8, 0xFF2F7BFF, 0xFF4FD8F7, 0xFFFFFFFF, 0xFF1E6BFF, 0xFF0891B2, 0xFF050E22, 0xFF03060F, 0xFF111A29)
    val Crimson = palette("Crimson", 0xFFB4122F, 0xFFE11D48, 0xFFFF6B88, 0xFFFFFFFF, 0xFFE11D48, 0xFF7F1230, 0xFF1C050C, 0xFF0A0306, 0xFF211218)
    val Matrix = palette("Matrix", 0xFF15803D, 0xFF22C55E, 0xFF86F0A6, 0xFF031A0D, 0xFF16A34A, 0xFF065F46, 0xFF03150B, 0xFF020805, 0xFF101B15)
    val Sakura = palette("Sakura", 0xFFDB2777, 0xFFF472B6, 0xFFFFB3DA, 0xFF2A0A1B, 0xFFEC4899, 0xFFA855F7, 0xFF1C0B15, 0xFF0B050A, 0xFF20131B)

    val all = listOf(Midnight, PurpleNeon, CyberBlue, Crimson, Matrix, Sakura)
}

@Composable
private fun anim(target: Color): Color =
    animateColorAsState(target, tween(450), label = "palette").value

/** Cross-fades every colour of the palette so a theme switch animates the whole UI. */
@Composable
fun animatePalette(t: RustPalette): RustPalette = RustPalette(
    name = t.name,
    accentDeep = anim(t.accentDeep),
    accent = anim(t.accent),
    accentBright = anim(t.accentBright),
    onAccent = anim(t.onAccent),
    glowA = anim(t.glowA),
    glowB = anim(t.glowB),
    bgTop = anim(t.bgTop),
    bgBottom = anim(t.bgBottom),
    surface = anim(t.surface),
)

val LocalRustPalette = compositionLocalOf { RustPalettes.Midnight }

object Rust {
    val palette: RustPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalRustPalette.current
}
