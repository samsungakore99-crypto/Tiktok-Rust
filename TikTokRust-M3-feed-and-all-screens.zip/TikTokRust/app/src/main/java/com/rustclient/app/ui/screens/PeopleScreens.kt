package com.rustclient.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.data.DlState
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.theme.*
import com.rustclient.app.vm.DownloadUi

/** An account with a Follow / Following button. Follows are stored on this device. */
@Composable
fun AccountRow(
    handle: String,
    following: Boolean,
    onToggleFollow: () -> Unit,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.fillMaxWidth().pressable(onOpen, pressedScale = 0.985f).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Avatar(null, handle, 46.dp)
        RustText("@$handle", RustType.rowTitle, Modifier.weight(1f), maxLines = 1)
        RustButton(
            stringResource(if (following) R.string.action_following else R.string.action_follow),
            onToggleFollow,
            style = if (following) ButtonStyle.Ghost else ButtonStyle.Follow,
            height = 36.dp,
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    RustText(text, RustType.label, Modifier.padding(start = 20.dp, top = 8.dp), color = RustNeutral.TextSecondary)
}

/** Friends tab: the accounts you follow, plus suggestions taken from the feed. */
@Composable
fun FriendsScreen(
    following: Set<String>,
    suggestions: List<String>,
    onToggleFollow: (String) -> Unit,
    onOpenProfile: (String) -> Unit,
    onOpenSearch: () -> Unit,
) {
    val followed = following.toList().sorted()
    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.tab_friends)) {
            GlassIconButton(RustGlyph.Search, onOpenSearch, stringResource(R.string.action_search))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (followed.isEmpty()) {
                InfoNote(R.string.friends_empty, Modifier.padding(horizontal = 16.dp))
            } else {
                SectionTitle(stringResource(R.string.friends_following, followed.size))
                GlassCard(Modifier.padding(horizontal = 16.dp)) {
                    followed.forEachIndexed { i, handle ->
                        if (i > 0) RowDivider(inset = 72.dp)
                        AccountRow(handle, true, { onToggleFollow(handle) }, { onOpenProfile(handle) })
                    }
                }
            }
            val more = suggestions.filter { it !in following }
            if (more.isNotEmpty()) {
                SectionTitle(stringResource(R.string.friends_suggested))
                GlassCard(Modifier.padding(horizontal = 16.dp)) {
                    more.forEachIndexed { i, handle ->
                        if (i > 0) RowDivider(inset = 72.dp)
                        AccountRow(handle, false, { onToggleFollow(handle) }, { onOpenProfile(handle) })
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Inbox: real events only: finished and failed downloads. The tab badge counts the unseen ones. */
@Composable
fun InboxScreen(events: List<DownloadUi>, seenAt: Long, onOpen: () -> Unit) {
    val finished = events.filter {
        val s = it.status?.state
        s == DlState.DONE || s == DlState.FAILED
    }.sortedByDescending { it.createdAt }
    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.tab_inbox))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (finished.isEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    CrownMark(size = 96.dp)
                    RustText(stringResource(R.string.inbox_empty_t), RustType.screenTitle, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    RustText(
                        stringResource(R.string.inbox_empty_s),
                        RustType.rowSubtitle,
                        color = RustNeutral.TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            } else {
                GlassCard(Modifier.padding(horizontal = 16.dp)) {
                    finished.forEachIndexed { i, event ->
                        if (i > 0) RowDivider()
                        val failed = event.status?.state == DlState.FAILED
                        SettingsRow(
                            glyph = if (failed) RustGlyph.Close else RustGlyph.Download,
                            title = stringResource(if (failed) R.string.inbox_failed else R.string.inbox_done),
                            subtitle = event.fileName,
                            onClick = onOpen,
                            emphasized = event.createdAt > seenAt,
                            trailing = {
                                if (event.createdAt > seenAt) {
                                    Box(Modifier.size(9.dp).clip(RustShape.pill).background(Rust.palette.accentBright))
                                }
                            },
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
