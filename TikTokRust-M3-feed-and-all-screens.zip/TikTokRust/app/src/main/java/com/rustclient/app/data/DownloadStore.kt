package com.rustclient.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.rustclient.core.MediaKind
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private val Context.downloadsDataStore by preferencesDataStore(name = "rust_downloads")

/** What the app remembers about a download; live state comes from the system DownloadManager. */
data class DownloadRecord(
    val id: Long,
    val url: String,
    val fileName: String,
    val kind: MediaKind,
    val createdAt: Long,
)

class DownloadStore(private val context: Context) {
    private val key = stringPreferencesKey("records")

    suspend fun load(): List<DownloadRecord> = parse(context.downloadsDataStore.data.first()[key])

    suspend fun add(record: DownloadRecord) = mutate { it + record }

    suspend fun remove(ids: Set<Long>) = mutate { list -> list.filter { it.id !in ids } }

    suspend fun clear() = mutate { emptyList() }

    private suspend fun mutate(change: (List<DownloadRecord>) -> List<DownloadRecord>) {
        context.downloadsDataStore.edit { prefs -> prefs[key] = encode(change(parse(prefs[key]))) }
    }

    private fun parse(json: String?): List<DownloadRecord> {
        if (json.isNullOrEmpty()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                DownloadRecord(o.getLong("id"), o.getString("url"), o.getString("name"), MediaKind.valueOf(o.getString("kind")), o.getLong("at"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun encode(list: List<DownloadRecord>): String {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("url", r.url).put("name", r.fileName).put("kind", r.kind.name).put("at", r.createdAt))
        }
        return arr.toString()
    }
}
