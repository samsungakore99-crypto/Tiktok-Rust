package com.rustclient.app.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.Routes
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*

private val FilterChips = listOf("Все", "Контент", "Плеер", "Интерфейс", "Загрузки")

/**
 * Component gallery. Lives on the Home tab until the feed lands; every control here is the real
 * component the product screens will use. The theme chips re-colour the whole app live.
 */
@Composable
fun GalleryScreen(selectedPalette: Int, onSelectPalette: (Int) -> Unit) {
    var chip by rememberSaveable { mutableStateOf(0) }
    var ads by rememberSaveable { mutableStateOf(true) }
    var live by rememberSaveable { mutableStateOf(false) }
    var saveVideo by rememberSaveable { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        RustTopBar(title = stringResource(R.string.gallery_title)) {
            CrownMark(size = 34.dp, animated = false)
        }
        HeroBanner(
            stringResource(R.string.brand_name),
            stringResource(R.string.brand_tagline),
            Modifier.padding(horizontal = 16.dp),
        )

        SectionLabel("Тема оформления")
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            RustPalettes.all.forEachIndexed { index, palette ->
                PillChip(palette.name, index == selectedPalette, { onSelectPalette(index) })
            }
        }

        SectionLabel("Фильтры")
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilterChips.forEachIndexed { index, label ->
                PillChip(label, index == chip, { chip = index })
            }
            GlassIconButton(RustGlyph.Tune, {}, "Настроить фильтры")
        }

        SectionLabel("Кнопки")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            RustButton("Применить тему", {}, Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RustButton("Изменить", {}, Modifier.weight(1f), ButtonStyle.Ghost, height = 46.dp)
                RustButton("Подписаться", {}, Modifier.weight(1f), ButtonStyle.Follow, height = 46.dp)
            }
        }

        SectionLabel("Переключатели")
        SectionCard("Удаление и скрытие контента", RustGlyph.Crown, Modifier.padding(horizontal = 16.dp)) {
            SettingsRow(
                glyph = RustGlyph.Block,
                title = "Убрать рекламу",
                subtitle = "Полностью скрыть рекламные блоки",
                trailing = { RustSwitch(checked = ads, onCheckedChange = { ads = it }) },
            )
            RowDivider()
            SettingsRow(
                glyph = RustGlyph.Live,
                title = "Убрать прямые эфиры",
                subtitle = "Скрыть LIVE из ленты и поиска",
                trailing = { RustSwitch(checked = live, onCheckedChange = { live = it }) },
            )
            RowDivider()
            SettingsRow(
                glyph = RustGlyph.Download,
                title = "Скачивание видео",
                subtitle = "Сохранять видео в оригинальном качестве",
                trailing = { RustSwitch(checked = saveVideo, onCheckedChange = { saveVideo = it }) },
            )
        }

        SectionLabel("Плитки")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(RustGlyph.Bolt, "Память", "1.2 ГБ", Modifier.weight(1f), status = "Хорошо")
            StatTile(RustGlyph.Bars, "FPS", "60 FPS", Modifier.weight(1f), status = "Отлично")
            StatTile(RustGlyph.Palette, "Темы", "${RustPalettes.all.size} тем", Modifier.weight(1f))
        }

        SectionLabel("Метки")
        Row(
            Modifier.padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NewBadge(stringResource(R.string.badge_new))
            CountBadge("99+")
            RustIcon(RustGlyph.Crown, tint = RustNeutral.Gold, size = 22.dp)
        }
        Spacer(Modifier.height(28.dp))
    }
}

private class HubRow(
    val route: String,
    val glyph: RustGlyph,
    @StringRes val title: Int,
    @StringRes val sub: Int,
)

private val HubRows = listOf(
    HubRow(Routes.Settings, RustGlyph.Tune, R.string.route_settings, R.string.sub_settings),
    HubRow(Routes.mod(), RustGlyph.Crown, R.string.route_mod, R.string.sub_mod),
    HubRow(Routes.Themes, RustGlyph.Palette, R.string.route_themes, R.string.sub_themes),
    HubRow(Routes.Downloads, RustGlyph.Download, R.string.route_downloads, R.string.sub_downloads),
    HubRow(Routes.Search, RustGlyph.Search, R.string.route_search, R.string.sub_search),
    HubRow(Routes.Player, RustGlyph.Play, R.string.route_player, R.string.sub_player),
    HubRow(Routes.About, RustGlyph.Info, R.string.route_about, R.string.sub_about),
)

/** Profile tab for now: a launcher into every secondary route, so navigation can be tested end to end. */
@Composable
fun HubScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        RustTopBar(title = stringResource(R.string.tab_profile))
        GlassCard(Modifier.padding(horizontal = 16.dp)) {
            HubRows.forEachIndexed { index, row ->
                if (index > 0) RowDivider()
                SettingsRow(
                    glyph = row.glyph,
                    title = stringResource(row.title),
                    subtitle = stringResource(row.sub),
                    onClick = { onOpen(row.route) },
                    emphasized = row.route == Routes.mod(),
                    trailing = {
                        if (row.route == Routes.mod()) {
                            NewBadge(stringResource(R.string.badge_new))
                        } else {
                            RustIcon(RustGlyph.ChevronRight, tint = RustNeutral.TextTertiary, size = 20.dp)
                        }
                    },
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** Empty state for routes whose real screen is built in a later milestone. */
@Composable
fun PlaceholderScreen(title: String, onBack: (() -> Unit)?) {
    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = title, onBack = onBack)
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 40.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CrownMark(size = 120.dp)
            Spacer(Modifier.height(24.dp))
            RustText(
                stringResource(R.string.soon_title),
                RustType.screenTitle,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            RustText(
                stringResource(R.string.soon_body),
                RustType.rowSubtitle,
                color = RustNeutral.TextSecondary,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(48.dp))
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF04030A, widthDp = 390, heightDp = 1500)
@Composable
private fun GalleryPreview() {
    RustTheme {
        Box(Modifier.fillMaxSize()) {
            AuroraBackground()
            GalleryScreen(selectedPalette = 0, onSelectPalette = {})
        }
    }
}
