package com.rustclient.app.ui.feed

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.screens.NeonSkyline
import com.rustclient.app.ui.screens.SampleTag
import com.rustclient.app.ui.theme.*
import com.rustclient.core.ContentKind
import com.rustclient.core.FeedItem

/** Non-video feed entries (LIVE, Story, Ad, Shop, Friend suggestions). They are sample cards, labelled as such. */
@Composable
fun SpecialCard(
    item: FeedItem,
    accounts: List<String>,
    following: Set<String>,
    onToggleFollow: (String) -> Unit,
    onOpenProfile: (String) -> Unit,
) {
    val p = Rust.palette
    val tint = when (item.kind) {
        ContentKind.LIVE -> RustNeutral.Danger
        ContentKind.AD -> RustNeutral.Gold
        else -> p.accent
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.38f), p.bgTop, p.bgBottom)))) {
        NeonSkyline(p, Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(260.dp))
        Column(
            Modifier.align(Alignment.Center).padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (item.kind) {
                ContentKind.LIVE -> LiveBadgeBig()
                ContentKind.STORY -> Avatar(null, item.author.trimStart('@'), 150.dp)
                ContentKind.AD -> KindPill(stringResource(R.string.kind_ad), RustNeutral.Gold)
                ContentKind.SHOP -> RustIcon(RustGlyph.Shop, tint = p.accentBright, size = 84.dp, strokeWidth = 1.4f)
                ContentKind.FRIEND_SUGGESTION -> Unit
                else -> Unit
            }
            if (item.kind == ContentKind.FRIEND_SUGGESTION) {
                RustText(stringResource(R.string.feed_suggest_title), RustType.screenTitle, color = Color.White)
                val suggestions = accounts.filter { it !in following }.take(3)
                if (suggestions.isEmpty()) {
                    RustText(stringResource(R.string.feed_suggest_none), RustType.rowSubtitle, color = RustNeutral.TextSecondary)
                }
                suggestions.forEach { handle ->
                    Row(
                        Modifier.fillMaxWidth().glass(RustShape.tile).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Avatar(null, handle, 44.dp, Modifier.pressable({ onOpenProfile(handle) }, pressedScale = 0.92f))
                        RustText("@$handle", RustType.rowTitle, Modifier.weight(1f), maxLines = 1)
                        RustButton(stringResource(R.string.action_follow), { onToggleFollow(handle) }, style = ButtonStyle.Follow, height = 36.dp)
                    }
                }
            } else {
                RustText(item.author, RustType.sectionTitle, color = Color.White)
                RustText(item.caption, RustType.screenTitle, color = Color.White, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
            SampleTag()
        }
    }
}

@Composable
private fun KindPill(text: String, color: Color) {
    Box(
        Modifier.clip(RustShape.pill).background(color.copy(alpha = 0.22f)).border(1.dp, color, RustShape.pill)
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) { RustText(text, RustType.label, color = color, maxLines = 1) }
}

@Composable
private fun LiveBadgeBig() {
    val reduce = LocalMotion.current.reduce
    val pulse: State<Float> = if (reduce) {
        remember { mutableStateOf(1f) }
    } else {
        rememberInfiniteTransition(label = "live").animateFloat(
            initialValue = 0.92f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "livePulse",
        )
    }
    Box(
        Modifier
            .graphicsLayer {
                scaleX = pulse.value
                scaleY = pulse.value
            }
            .neonGlow(RustNeutral.Danger, 22.dp, 0.6f)
            .clip(RustShape.pill)
            .background(RustNeutral.Danger)
            .padding(horizontal = 26.dp, vertical = 12.dp),
    ) { RustText("LIVE", RustType.screenTitle.copy(letterSpacing = 3.sp), color = Color.White) }
}
