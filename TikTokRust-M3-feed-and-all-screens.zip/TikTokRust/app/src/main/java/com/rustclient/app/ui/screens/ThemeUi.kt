package com.rustclient.app.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AccentPalette

/** City-at-night silhouette tinted by [palette]; used on theme cards and in the phone preview. */
@Composable
fun NeonSkyline(palette: RustPalette, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val glowCenter = Offset(w * 0.7f, h * 0.35f)
        drawCircle(
            Brush.radialGradient(listOf(palette.glowA.copy(alpha = 0.55f), Color.Transparent), center = glowCenter, radius = w * 0.6f),
            radius = w * 0.6f,
            center = glowCenter,
        )
        drawCircle(palette.accentBright.copy(alpha = 0.9f), radius = w * 0.07f, center = Offset(w * 0.72f, h * 0.26f))
        val heights = floatArrayOf(0.30f, 0.46f, 0.36f, 0.58f, 0.42f, 0.52f, 0.34f)
        val bw = w / heights.size
        heights.forEachIndexed { i, fraction ->
            val top = h * (1f - fraction)
            drawRect(Color.Black.copy(alpha = 0.86f), Offset(i * bw, top), Size(bw * 0.92f, h - top))
            var y = top + bw * 0.25f
            while (y < h - bw * 0.2f) {
                drawRect(palette.accentBright.copy(alpha = 0.55f), Offset(i * bw + bw * 0.18f, y), Size(bw * 0.14f, bw * 0.09f))
                drawRect(palette.accent.copy(alpha = 0.45f), Offset(i * bw + bw * 0.52f, y + bw * 0.1f), Size(bw * 0.14f, bw * 0.09f))
                y += bw * 0.3f
            }
        }
    }
}

@Composable
private fun RailItem(glyph: RustGlyph, count: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        RustIcon(glyph, tint = Color.White, size = 30.dp)
        RustText(count, RustType.caption.copy(fontSize = 11.sp), color = Color.White)
    }
}

@Composable
private fun MockCreate() {
    Box(Modifier.size(width = 56.dp, height = 36.dp), contentAlignment = Alignment.Center) {
        val layer = Modifier.size(width = 46.dp, height = 36.dp)
        Box(layer.offset(x = (-4).dp).clip(RustShape.create).background(RustNeutral.Cyan))
        Box(layer.offset(x = 4.dp).clip(RustShape.create).background(RustNeutral.Danger))
        Box(layer.clip(RustShape.create).background(Color.White), contentAlignment = Alignment.Center) {
            RustIcon(RustGlyph.Plus, tint = Color(0xFF0A0710), size = 24.dp, strokeWidth = 2.6f)
        }
    }
}

@Composable
private fun MockBar(modifier: Modifier = Modifier) {
    val p = Rust.palette
    Column(modifier.fillMaxWidth()) {
        Box(
            Modifier.fillMaxWidth().height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, p.accent.copy(alpha = 0.55f), Color.Transparent))),
        )
        Row(
            Modifier.fillMaxWidth().height(72.dp).background(p.bgBottom.copy(alpha = 0.96f)),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            listOf(RustGlyph.Home, RustGlyph.Friends, null, RustGlyph.Inbox, RustGlyph.Profile).forEachIndexed { index, glyph ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    if (glyph == null) {
                        MockCreate()
                    } else {
                        RustIcon(glyph, tint = if (index == 0) p.accentBright else RustNeutral.TextTertiary, size = 26.dp)
                    }
                }
            }
        }
    }
}

/** The home feed drawn at 360x720 dp with whatever palette is current; scaled down by [PhonePreview]. */
@Composable
private fun FeedMock() {
    val p = Rust.palette
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))) {
        NeonSkyline(p, Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(340.dp))
        Column(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                RustText("9:41", RustType.label, color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RustIcon(RustGlyph.Signal, tint = Color.White, size = 16.dp)
                    RustIcon(RustGlyph.Wifi, tint = Color.White, size = 16.dp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                RustText(stringResource(R.string.pv_following), RustType.sectionTitle, color = Color.White.copy(alpha = 0.6f))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    RustText(stringResource(R.string.pv_for_you), RustType.sectionTitle, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.width(28.dp).height(3.dp).clip(RustShape.pill).background(p.accentBright))
                }
            }
        }
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 14.dp, top = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            Avatar(null, "R", 46.dp)
            RailItem(RustGlyph.Heart, "812K")
            RailItem(RustGlyph.Inbox, "12K")
            RailItem(RustGlyph.Bookmark, "87K")
            RailItem(RustGlyph.Share, "34K")
        }
        Column(
            Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 90.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            RustText("@city.lights", RustType.sectionTitle, color = Color.White)
            RustText("Dream big", RustType.rowTitle, color = Color.White.copy(alpha = 0.85f))
        }
        MockBar(Modifier.align(Alignment.BottomCenter))
    }
}

/** A live, scaled-down render of the app in [palette]. Palette changes cross-fade. */
@Composable
fun PhonePreview(palette: RustPalette, modifier: Modifier = Modifier) {
    val animated = animatePalette(palette)
    val shape = RoundedCornerShape(26.dp)
    CompositionLocalProvider(
        LocalRustPalette provides animated,
        LocalMotion provides MotionSpec(reduce = true, animatedBackground = false, haptics = false),
    ) {
        BoxWithConstraints(
            modifier
                .aspectRatio(0.5f)
                .clip(shape)
                .background(animated.bgBottom)
                .border(2.dp, Brush.linearGradient(listOf(animated.accentBright, animated.accent.copy(alpha = 0.3f))), shape),
        ) {
            val scale = maxWidth.value / 360f
            Box(
                Modifier
                    .requiredSize(360.dp, 720.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        transformOrigin = TransformOrigin(0f, 0f)
                    },
            ) { FeedMock() }
        }
    }
}

@Composable
private fun SliderRow(@StringRes label: Int, value: Float, brush: Brush, thumb: Color, onChange: (Float) -> Unit) {
    Column {
        RustText(stringResource(label), RustType.caption, color = RustNeutral.TextSecondary)
        GradientSlider(value, onChange, brush, thumb)
    }
}

private val QuickColors = listOf(
    0xFF7B3CFC, 0xFF2F7BFF, 0xFF06B6D4, 0xFF22C55E, 0xFFEAB308, 0xFFF97316, 0xFFE11D48, 0xFFEC4899,
).map { it.toInt() }

/** Hue / saturation / brightness sliders, hex field and quick swatches for the custom accent. */
@Composable
fun ColorEditor(color: Int, onColor: (Int) -> Unit, modifier: Modifier = Modifier) {
    var hsv by remember { mutableStateOf(AccentPalette.rgbToHsv(color).toList()) }
    var hexText by remember { mutableStateOf(AccentPalette.toHex(color)) }

    fun push(h: Float, s: Float, v: Float) {
        hsv = listOf(h, s, v)
        val c = AccentPalette.hsvToRgb(h, s, v)
        hexText = AccentPalette.toHex(c)
        onColor(c)
    }

    val hue = hsv[0]
    val sat = hsv[1]
    val value = hsv[2]
    val hueBrush = remember {
        Brush.horizontalGradient(listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { Color(AccentPalette.hsvToRgb(it, 1f, 1f)) })
    }
    val satBrush = Brush.horizontalGradient(
        listOf(Color(AccentPalette.hsvToRgb(hue, 0f, value)), Color(AccentPalette.hsvToRgb(hue, 1f, value))),
    )
    val valueBrush = Brush.horizontalGradient(listOf(Color.Black, Color(AccentPalette.hsvToRgb(hue, sat, 1f))))
    val current = Color(AccentPalette.hsvToRgb(hue, sat, value))

    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SliderRow(R.string.ce_hue, hue / 360f, hueBrush, Color(AccentPalette.hsvToRgb(hue, 1f, 1f))) { push(it * 360f, sat, value) }
        SliderRow(R.string.ce_sat, sat, satBrush, current) { push(hue, it, value) }
        SliderRow(R.string.ce_bright, value, valueBrush, current) { push(hue, sat, it) }
        RustTextField(
            value = hexText,
            onValueChange = { text ->
                hexText = text.take(7)
                AccentPalette.parseHex(text)?.let { c ->
                    hsv = AccentPalette.rgbToHsv(c).toList()
                    onColor(c)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            placeholder = "#7B3CFC",
            leading = RustGlyph.Palette,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            QuickColors.forEach { c ->
                Box(
                    Modifier
                        .size(34.dp)
                        .pressable({
                            hsv = AccentPalette.rgbToHsv(c).toList()
                            hexText = AccentPalette.toHex(c)
                            onColor(c)
                        }, pressedScale = 0.9f)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(2.dp, Color.White.copy(alpha = 0.35f), CircleShape),
                )
            }
        }
    }
}
