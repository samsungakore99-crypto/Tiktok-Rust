package com.rustclient.app.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.Debug
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import java.io.File

/** Real device measurements shown on the Settings screens. */
object DeviceStats {
    /** Proportional set size of this process, in MB. */
    fun appMemoryMb(): Int {
        val info = Debug.MemoryInfo()
        Debug.getMemoryInfo(info)
        return info.totalPss / 1024
    }

    /** Pair(free bytes, total bytes) of shared storage. */
    @Suppress("DEPRECATION")
    fun storage(): Pair<Long, Long> {
        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        return stat.availableBytes to stat.totalBytes
    }

    fun cacheBytes(context: Context): Long =
        listOfNotNull(context.cacheDir, context.externalCacheDir).sumOf { sizeOf(it) }

    fun clearCache(context: Context) {
        listOfNotNull(context.cacheDir, context.externalCacheDir).forEach { dir ->
            dir.listFiles()?.forEach { it.deleteRecursively() }
        }
    }

    fun isMetered(context: Context): Boolean =
        context.getSystemService(ConnectivityManager::class.java)?.isActiveNetworkMetered ?: false

    fun isPowerSave(context: Context): Boolean =
        context.getSystemService(PowerManager::class.java)?.isPowerSaveMode ?: false

    private fun sizeOf(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { sizeOf(it) } ?: 0L)
}

/** Frames rendered per second, measured with the frame clock while the caller is composed. */
@Composable
fun rememberFps(enabled: Boolean = true): State<Int> {
    val fps = remember { mutableStateOf(0) }
    LaunchedEffect(enabled) {
        if (!enabled) return@LaunchedEffect
        var frames = 0
        var windowStart = 0L
        while (true) {
            val now = withFrameNanos { it }
            if (windowStart == 0L) windowStart = now
            frames++
            if (now - windowStart >= 1_000_000_000L) {
                fps.value = frames
                frames = 0
                windowStart = now
            }
        }
    }
    return fps
}

/** App memory in MB, refreshed every two seconds. */
@Composable
fun rememberMemoryMb(): State<Int> {
    val mb = remember { mutableStateOf(DeviceStats.appMemoryMb()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2000)
            mb.value = DeviceStats.appMemoryMb()
        }
    }
    return mb
}

/** Live battery-saver state. */
@Composable
fun rememberPowerSave(): Boolean {
    val context = LocalContext.current
    var on by remember { mutableStateOf(DeviceStats.isPowerSave(context)) }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                on = DeviceStats.isPowerSave(c)
            }
        }
        context.registerReceiver(receiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED))
        onDispose { context.unregisterReceiver(receiver) }
    }
    return on
}
