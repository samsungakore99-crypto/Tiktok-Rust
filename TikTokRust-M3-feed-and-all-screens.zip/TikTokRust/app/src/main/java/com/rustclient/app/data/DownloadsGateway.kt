package com.rustclient.app.data

import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.LruCache
import com.rustclient.app.R
import com.rustclient.core.DownloadPolicy
import com.rustclient.core.DownloadPrefs
import com.rustclient.core.MediaKind
import com.rustclient.core.NotificationPrefs
import com.rustclient.core.SaveLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

enum class DlState { QUEUED, RUNNING, PAUSED, DONE, FAILED }

data class DlStatus(val state: DlState, val downloaded: Long, val total: Long, val reason: Int, val uri: Uri?)

data class Probe(val code: Int, val mime: String?, val size: Long)

data class MediaInfo(val thumb: Bitmap?, val width: Int, val height: Int)

/** Thin wrapper over the system [DownloadManager]: it survives process death, resumes, and shows notifications. */
class DownloadsGateway(private val context: Context) {
    private val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    @Suppress("DEPRECATION")
    fun enqueue(url: String, fileName: String, kind: MediaKind, prefs: DownloadPrefs, notif: NotificationPrefs): Long {
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(fileName)
            .setDescription(context.getString(R.string.dl_notification_desc))
            .setNotificationVisibility(visibility(notif))
        if (prefs.wifiOnly) request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI)
        val sub = DownloadPolicy.safeFolder(prefs.folder) + "/" + fileName
        if (Build.VERSION.SDK_INT >= 29) {
            val dir = when {
                prefs.location == SaveLocation.DOWNLOADS -> Environment.DIRECTORY_DOWNLOADS
                kind == MediaKind.VIDEO -> Environment.DIRECTORY_MOVIES
                else -> Environment.DIRECTORY_PICTURES
            }
            request.setDestinationInExternalPublicDir(dir, sub)
        } else {
            // Android 8/9 would need legacy storage permission for public folders: stay in app storage.
            val dir = if (kind == MediaKind.VIDEO) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
            request.setDestinationInExternalFilesDir(context, dir, sub)
        }
        return dm.enqueue(request)
    }

    private fun visibility(n: NotificationPrefs): Int = when {
        n.progress && n.done -> DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
        n.progress -> DownloadManager.Request.VISIBILITY_VISIBLE
        n.done -> DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_ONLY_COMPLETION
        else -> DownloadManager.Request.VISIBILITY_HIDDEN
    }

    fun query(ids: List<Long>): Map<Long, DlStatus> {
        if (ids.isEmpty()) return emptyMap()
        val out = HashMap<Long, DlStatus>()
        dm.query(DownloadManager.Query().setFilterById(*ids.toLongArray()))?.use { c ->
            val iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val iStatus = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
            val iDone = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val iTotal = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val iReason = c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val state = when (c.getInt(iStatus)) {
                    DownloadManager.STATUS_PENDING -> DlState.QUEUED
                    DownloadManager.STATUS_RUNNING -> DlState.RUNNING
                    DownloadManager.STATUS_PAUSED -> DlState.PAUSED
                    DownloadManager.STATUS_SUCCESSFUL -> DlState.DONE
                    else -> DlState.FAILED
                }
                val uri = if (state == DlState.DONE) dm.getUriForDownloadedFile(id) else null
                out[id] = DlStatus(state, c.getLong(iDone), c.getLong(iTotal), c.getInt(iReason), uri)
            }
        }
        return out
    }

    /** Cancels the download and deletes the file (partial or complete). */
    fun remove(id: Long) {
        dm.remove(id)
    }

    /** HEAD request to learn the content type of a link without a recognisable extension. */
    suspend fun probe(url: String): Probe? = withContext(Dispatchers.IO) {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.instanceFollowRedirects = true
            try {
                Probe(c.responseCode, c.contentType, c.contentLengthLong)
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }
}

/** Thumbnails and real resolution of finished downloads, cached in memory. */
object Thumbs {
    private val cache = LruCache<String, MediaInfo>(48)

    suspend fun info(context: Context, uri: Uri, kind: MediaKind): MediaInfo = withContext(Dispatchers.IO) {
        val key = uri.toString()
        cache.get(key)?.let { return@withContext it }
        val info = try {
            if (kind == MediaKind.VIDEO) video(context, uri) else photo(context, uri)
        } catch (e: Exception) {
            MediaInfo(null, 0, 0)
        }
        cache.put(key, info)
        info
    }

    private fun video(context: Context, uri: Uri): MediaInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val frame = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return MediaInfo(null, 0, 0)
            val w = frame.width
            val h = frame.height
            return MediaInfo(downscale(frame, 256), w, h)
        } finally {
            r.release()
        }
    }

    private fun photo(context: Context, uri: Uri): MediaInfo {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 256 && bounds.outHeight / (sample * 2) >= 256) sample *= 2
        val bmp = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        return MediaInfo(bmp?.let { downscale(it, 256) }, bounds.outWidth, bounds.outHeight)
    }

    private fun downscale(src: Bitmap, maxSide: Int): Bitmap {
        val scale = maxSide.toFloat() / maxOf(src.width, src.height)
        if (scale >= 1f) return src
        return Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = -1
    do {
        v /= 1024.0
        i++
    } while (v >= 1024.0 && i < units.lastIndex)
    return String.format(Locale.getDefault(), if (v >= 100) "%.0f %s" else "%.1f %s", v, units[i])
}
