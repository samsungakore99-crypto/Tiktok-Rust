package com.rustclient.app.ui.icons

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rustclient.app.ui.theme.RustNeutral

/**
 * The app's icon set: one 24x24 grid, 1.9 px round strokes, so every icon has the same weight.
 * Each glyph is a list of SVG path strings.
 */
enum class RustGlyph(vararg val paths: String) {
    Home(
        "M4 11 L12 4 L20 11 V19 A1.5 1.5 0 0 1 18.5 20.5 H5.5 A1.5 1.5 0 0 1 4 19 Z",
        "M10 20.5 V15 H14 V20.5",
    ),
    Friends(
        "M5.8 8 A3.2 3.2 0 1 0 12.2 8 A3.2 3.2 0 1 0 5.8 8 Z",
        "M2.5 19.5 V18.5 A4 4 0 0 1 6.5 14.5 H11.5 A4 4 0 0 1 15.5 18.5 V19.5",
        "M15.5 4.4 A3.2 3.2 0 0 1 15.5 10.8",
        "M18.5 14.8 A4 4 0 0 1 21.5 18.7 V19.5",
    ),
    Inbox(
        "M5 4 H19 A2 2 0 0 1 21 6 V15 A2 2 0 0 1 19 17 H10 L5.5 21 V17 H5 A2 2 0 0 1 3 15 V6 A2 2 0 0 1 5 4 Z",
    ),
    Profile(
        "M8.5 8 A3.5 3.5 0 1 0 15.5 8 A3.5 3.5 0 1 0 8.5 8 Z",
        "M4.5 20 V19.5 A5 5 0 0 1 9.5 14.5 H14.5 A5 5 0 0 1 19.5 19.5 V20",
    ),
    Plus("M12 5 V19 M5 12 H19"),
    Search(
        "M4 11 A7 7 0 1 0 18 11 A7 7 0 1 0 4 11 Z",
        "M20.5 20.5 L16 16",
    ),
    ChevronRight("M9.5 5.5 L16 12 L9.5 18.5"),
    ChevronLeft("M14.5 5.5 L8 12 L14.5 18.5"),
    ChevronDown("M5.5 9.5 L12 16 L18.5 9.5"),
    Crown(
        "M3 8 L7.5 12 L12 5 L16.5 12 L21 8 L19.5 18 H4.5 Z",
        "M5.5 21 H18.5",
    ),
    Tune(
        "M4 7 H11 M16 7 H20 M4 17 H7 M12 17 H20",
        "M11 7 A2.5 2.5 0 1 0 16 7 A2.5 2.5 0 1 0 11 7 Z",
        "M7 17 A2.5 2.5 0 1 0 12 17 A2.5 2.5 0 1 0 7 17 Z",
    ),
    Download(
        "M12 4 V15 M7.5 10.5 L12 15 L16.5 10.5",
        "M4.5 19.5 H19.5",
    ),
    Palette(
        "M12 3 A9 9 0 0 0 12 21 C13.4 21 14 20 13.5 18.8 C12.9 17.4 13.8 16 15.3 16 H17.5 A3.5 3.5 0 0 0 21 12.5 C21 7 17 3 12 3 Z",
        "M7.5 11 V11.01 M10 7.5 V7.51 M14.5 7.5 V7.51",
    ),
    Lock(
        "M6 11 H18 A1.5 1.5 0 0 1 19.5 12.5 V18.5 A1.5 1.5 0 0 1 18 20 H6 A1.5 1.5 0 0 1 4.5 18.5 V12.5 A1.5 1.5 0 0 1 6 11 Z",
        "M8 11 V8 A4 4 0 0 1 16 8 V11",
    ),
    Bell(
        "M6 16 V11 A6 6 0 0 1 18 11 V16 L19.5 18 H4.5 Z",
        "M10 20.5 A2 2 0 0 0 14 20.5",
    ),
    Monitor(
        "M4 5 H20 A1 1 0 0 1 21 6 V16 A1 1 0 0 1 20 17 H4 A1 1 0 0 1 3 16 V6 A1 1 0 0 1 4 5 Z",
        "M9 21 H15 M12 17 V21",
    ),
    Globe(
        "M3 12 A9 9 0 1 0 21 12 A9 9 0 1 0 3 12 Z",
        "M3 12 H21",
        "M12 3 C14.5 5.5 15.5 8.5 15.5 12 C15.5 15.5 14.5 18.5 12 21 C9.5 18.5 8.5 15.5 8.5 12 C8.5 8.5 9.5 5.5 12 3 Z",
    ),
    Info(
        "M3 12 A9 9 0 1 0 21 12 A9 9 0 1 0 3 12 Z",
        "M12 11 V16.5",
        "M12 7.5 V7.51",
    ),
    Bolt("M13 3 L5.5 13.5 H11 L10 21 L18.5 10 H13 Z"),
    Bars("M6 20 V13 M12 20 V5 M18 20 V10"),
    Play("M8 5.5 V18.5 L19 12 Z"),
    Block(
        "M3 12 A9 9 0 1 0 21 12 A9 9 0 1 0 3 12 Z",
        "M5.6 5.6 L18.4 18.4",
    ),
    Live(
        "M4 6.5 H15 A1.5 1.5 0 0 1 16.5 8 V16 A1.5 1.5 0 0 1 15 17.5 H4 A1.5 1.5 0 0 1 2.5 16 V8 A1.5 1.5 0 0 1 4 6.5 Z",
        "M16.5 10.5 L21.5 7.5 V16.5 L16.5 13.5",
    ),
    Image(
        "M5 4 H19 A2 2 0 0 1 21 6 V18 A2 2 0 0 1 19 20 H5 A2 2 0 0 1 3 18 V6 A2 2 0 0 1 5 4 Z",
        "M8.5 9 A1.5 1.5 0 1 0 11.5 9 A1.5 1.5 0 1 0 8.5 9 Z",
        "M3 16 L8.5 11.5 L13 15.5 L16 13 L21 17",
    ),
    Story(
        "M3 12 A9 9 0 1 0 21 12 A9 9 0 1 0 3 12 Z",
        "M9 12 A3 3 0 1 0 15 12 A3 3 0 1 0 9 12 Z",
    ),
    Repeat(
        "M17 2 L20 5 L17 8",
        "M4 11 V9 A4 4 0 0 1 8 5 H20",
        "M7 22 L4 19 L7 16",
        "M20 13 V15 A4 4 0 0 1 16 19 H4",
    ),
    Shop(
        "M5 8 H19 L20 20 H4 Z",
        "M9 8 V7 A3 3 0 0 1 15 7 V8",
    ),
    Hash("M9 4 L7 20 M17 4 L15 20 M4 9 H20 M3.5 15 H19.5"),
    UserMinus(
        "M7 8 A3.5 3.5 0 1 0 14 8 A3.5 3.5 0 1 0 7 8 Z",
        "M2.5 20 V19.5 A5 5 0 0 1 7.5 14.5 H13.5 A5 5 0 0 1 18.5 19.5 V20",
        "M17 8 H22",
    ),
    Clock(
        "M3 12 A9 9 0 1 0 21 12 A9 9 0 1 0 3 12 Z",
        "M12 7 V12 L15.5 14",
    ),
    VolumeOff(
        "M4 9.5 H8 L13 5.5 V18.5 L8 14.5 H4 Z",
        "M16.5 9.5 L21 14.5 M21 9.5 L16.5 14.5",
    ),
    Sun(
        "M8 12 A4 4 0 1 0 16 12 A4 4 0 1 0 8 12 Z",
        "M12 2 V4.5 M12 19.5 V22 M2 12 H4.5 M19.5 12 H22 M4.9 4.9 L6.7 6.7 M17.3 17.3 L19.1 19.1 M4.9 19.1 L6.7 17.3 M17.3 6.7 L19.1 4.9",
    ),
    Maximize(
        "M4 9 V5 A1 1 0 0 1 5 4 H9 M15 4 H19 A1 1 0 0 1 20 5 V9 M20 15 V19 A1 1 0 0 1 19 20 H15 M9 20 H5 A1 1 0 0 1 4 19 V15",
    ),
    Pause("M8 5 V19 M16 5 V19"),
    FastForward("M13 5 L19 12 L13 19 M5 5 L11 12 L5 19"),
    Video(
        "M4 6 H20 A1 1 0 0 1 21 7 V17 A1 1 0 0 1 20 18 H4 A1 1 0 0 1 3 17 V7 A1 1 0 0 1 4 6 Z",
        "M10 9.5 L15 12 L10 14.5 Z",
    ),
    Signal("M4 19 V16 M9 19 V12 M14 19 V8 M19 19 V4"),
    Wifi(
        "M2.5 9.5 A14 14 0 0 1 21.5 9.5",
        "M5.5 13 A9.5 9.5 0 0 1 18.5 13",
        "M8.8 16.4 A5 5 0 0 1 15.2 16.4",
        "M12 20 V20.01",
    ),
    Folder(
        "M3 7 A2 2 0 0 1 5 5 H9 L11 7.5 H19 A2 2 0 0 1 21 9.5 V17 A2 2 0 0 1 19 19 H5 A2 2 0 0 1 3 17 Z",
    ),
    Check("M5 12.5 L10 17.5 L19 7"),
    Trash(
        "M4 7 H20 M10 7 V4.5 A1 1 0 0 1 11 3.5 H13 A1 1 0 0 1 14 4.5 V7",
        "M6 7 L7 19.5 A1.5 1.5 0 0 0 8.5 21 H15.5 A1.5 1.5 0 0 0 17 19.5 L18 7",
        "M10 11 V17 M14 11 V17",
    ),
    Refresh(
        "M20 11 A8 8 0 0 0 5.5 7.5 L3.5 10",
        "M3.5 5.5 V10 H8",
        "M4 13 A8 8 0 0 0 18.5 16.5 L20.5 14",
        "M20.5 18.5 V14 H16",
    ),
    Close("M6 6 L18 18 M18 6 L6 18"),
    More("M5 12 V12.01 M12 12 V12.01 M19 12 V12.01"),
    Edit(
        "M4 20 L8 19 L19 8 L16 5 L5 16 Z",
        "M14 7 L17 10",
    ),
    Heart("M12 20 C5 14.5 3 11.5 3 8.5 A4.8 4.8 0 0 1 12 6.5 A4.8 4.8 0 0 1 21 8.5 C21 11.5 19 14.5 12 20 Z"),
    Bookmark("M6 4 H18 V21 L12 16.5 L6 21 Z"),
    Share("M14 4 L21 11 L14 18 V14 C8 14 5 16 3 20 C3.5 13 7 8.5 14 8 Z"),
    Link(
        "M10 14 A4 4 0 0 0 15.7 14.3 L19 11 A4 4 0 0 0 13.3 5.3 L12 6.6",
        "M14 10 A4 4 0 0 0 8.3 9.7 L5 13 A4 4 0 0 0 10.7 18.7 L12 17.4",
    ),
    Gauge(
        "M4.5 17 A8.5 8.5 0 1 1 19.5 17",
        "M12 13 L15.5 8.5",
    ),
}

@Composable
fun RustIcon(
    glyph: RustGlyph,
    modifier: Modifier = Modifier,
    tint: Color = RustNeutral.TextPrimary,
    size: Dp = 24.dp,
    strokeWidth: Float = 1.9f,
) {
    val parsed = remember(glyph) {
        glyph.paths.map { PathParser().parsePathString(it).toPath() }
    }
    Canvas(modifier.size(size)) {
        val unit = this.size.minDimension / 24f
        val stroke = Stroke(strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
        scale(unit, pivot = Offset.Zero) {
            parsed.forEach { drawPath(it, tint, style = stroke) }
        }
    }
}
