package com.rustclient.app.ui.screens

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings

typealias Update = ((AppSettings) -> AppSettings) -> Unit

@Composable
private fun ValueChevron(value: String?) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (value != null) {
            RustText(value, RustType.chip, Modifier.widthIn(max = 130.dp), color = RustNeutral.TextSecondary, maxLines = 1)
        }
        RustIcon(RustGlyph.ChevronRight, tint = RustNeutral.TextTertiary, size = 20.dp)
    }
}

/** Draws one [Spec] as a row (switch / value picker / action / list editor / text value). */
@Composable
fun SpecRow(
    spec: Spec,
    settings: AppSettings,
    onUpdate: Update,
    onAction: (String) -> Unit,
    modifier: Modifier = Modifier,
    actionValue: (String) -> String? = { null },
) {
    val enabled = spec.enabled(settings)
    var dialog by remember { mutableStateOf(false) }
    val title = stringResource(spec.title)
    val sub = spec.sub?.let { stringResource(it) }
    val rowModifier = modifier.alpha(if (enabled) 1f else 0.45f)

    when (val kind = spec.kind) {
        is SpecToggle -> {
            val on = kind.get(settings)
            val click: (() -> Unit)? = if (enabled) ({ onUpdate { s -> kind.set(s, !kind.get(s)) } }) else null
            SettingsRow(
                glyph = spec.glyph,
                title = title,
                subtitle = sub,
                modifier = rowModifier,
                onClick = click,
                trailing = {
                    RustSwitch(
                        checked = on,
                        onCheckedChange = { v -> if (enabled) onUpdate { s -> kind.set(s, v) } },
                    )
                },
            )
        }
        is SpecChoice -> {
            val labels = kind.labels.map { stringResource(it) }
            val index = kind.index(settings).coerceIn(0, labels.lastIndex)
            SettingsRow(
                glyph = spec.glyph,
                title = title,
                subtitle = sub,
                modifier = rowModifier,
                onClick = if (enabled) ({ dialog = true }) else null,
                trailing = { ValueChevron(labels[index]) },
            )
            if (dialog) {
                ChoiceDialog(
                    title = title,
                    options = labels,
                    selected = index,
                    onSelect = { i -> onUpdate { s -> kind.set(s, i) } },
                    onDismiss = { dialog = false },
                )
            }
        }
        is SpecAction -> {
            SettingsRow(
                glyph = spec.glyph,
                title = title,
                subtitle = sub,
                modifier = rowModifier,
                onClick = { onAction(kind.id) },
                emphasized = spec.isNew,
                trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (spec.isNew) NewBadge(stringResource(R.string.badge_new))
                        ValueChevron(actionValue(kind.id))
                    }
                },
            )
        }
        is SpecWords -> {
            val words = kind.get(settings)
            SettingsRow(
                glyph = spec.glyph,
                title = title,
                subtitle = sub,
                modifier = rowModifier,
                onClick = { dialog = true },
                trailing = { ValueChevron(if (words.isEmpty()) null else words.size.toString()) },
            )
            if (dialog) {
                WordsDialog(
                    title = title,
                    hint = stringResource(kind.hint),
                    words = words,
                    addLabel = stringResource(R.string.action_add),
                    emptyLabel = stringResource(R.string.words_empty),
                    doneLabel = stringResource(R.string.action_done),
                    onChange = { list -> onUpdate { s -> kind.set(s, list) } },
                    onDismiss = { dialog = false },
                )
            }
        }
        is SpecText -> {
            val value = kind.get(settings)
            SettingsRow(
                glyph = spec.glyph,
                title = title,
                subtitle = sub,
                modifier = rowModifier,
                onClick = { dialog = true },
                trailing = { ValueChevron(value) },
            )
            if (dialog) {
                InputDialog(
                    title = title,
                    initial = value,
                    hint = stringResource(kind.hint),
                    confirmLabel = stringResource(R.string.action_save),
                    onConfirm = { v -> onUpdate { s -> kind.set(s, v) } },
                    onDismiss = { dialog = false },
                )
            }
        }
    }
}

/** Options of [group] that pass the search [query] and the "only enabled" switch. */
fun filterSpecs(group: SpecGroup, settings: AppSettings, context: Context, query: String, onlyActive: Boolean): List<Spec> =
    group.specs.filter { spec ->
        val subText = spec.sub?.let { context.getString(it) } ?: ""
        val matches = query.isBlank() ||
            context.getString(spec.title).contains(query, ignoreCase = true) ||
            subText.contains(query, ignoreCase = true)
        matches && (!onlyActive || spec.isActive(settings))
    }

/** A collapsible card with every visible option of [group]. Draws nothing when the filter hides them all. */
@Composable
fun SpecGroupCard(
    group: SpecGroup,
    settings: AppSettings,
    onUpdate: Update,
    onAction: (String) -> Unit,
    modifier: Modifier = Modifier,
    query: String = "",
    onlyActive: Boolean = false,
    actionValue: (String) -> String? = { null },
) {
    val context = LocalContext.current
    val visible = filterSpecs(group, settings, context, query, onlyActive)
    if (visible.isEmpty()) return
    SectionCard(stringResource(group.title), group.glyph, modifier) {
        visible.forEachIndexed { index, spec ->
            if (index > 0) RowDivider()
            SpecRow(spec, settings, onUpdate, onAction, actionValue = actionValue)
        }
    }
}
