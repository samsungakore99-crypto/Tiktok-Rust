package com.rustclient.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.data.Social
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.ContentKind
import com.rustclient.core.FeedItem
import com.rustclient.core.SearchEngine
import kotlinx.coroutines.delay

private fun glyphOf(kind: ContentKind) = when (kind) {
    ContentKind.PHOTO -> RustGlyph.Image
    ContentKind.LIVE -> RustGlyph.Live
    ContentKind.STORY -> RustGlyph.Story
    ContentKind.REPOST -> RustGlyph.Repeat
    ContentKind.SHOP -> RustGlyph.Shop
    ContentKind.AD -> RustGlyph.Block
    ContentKind.FRIEND_SUGGESTION -> RustGlyph.Friends
    ContentKind.VIDEO -> RustGlyph.Play
}

/** Search over the items the feed can show (content filters already applied): accounts, tags, captions. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    items: List<FeedItem>,
    social: Social,
    myHandle: String,
    onBack: () -> Unit,
    onToggleFollow: (String) -> Unit,
    onOpenProfile: (String) -> Unit,
    onOpenPost: (FeedItem) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(120)
        try { focus.requestFocus() } catch (e: IllegalStateException) { /* not attached yet */ }
    }
    val p = Rust.palette
    val result = remember(items, query) { SearchEngine.search(items, query) }
    val tags = remember(items) { SearchEngine.popularTags(items) }
    val accounts = remember(items, myHandle) { SearchEngine.accounts(items).filter { it != myHandle } }
    val searching = query.isNotBlank()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GlassIconButton(RustGlyph.ChevronLeft, onBack, stringResource(R.string.back))
            RustTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f).focusRequester(focus),
                placeholder = stringResource(R.string.search_hint),
                leading = RustGlyph.Search,
                imeAction = ImeAction.Search,
                trailing = {
                    if (searching) {
                        Box(Modifier.size(28.dp).pressable({ query = "" }, pressedScale = 0.85f), contentAlignment = Alignment.Center) {
                            RustIcon(RustGlyph.Close, tint = RustNeutral.TextSecondary, size = 18.dp)
                        }
                    }
                },
            )
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!searching) {
                RustText(stringResource(R.string.search_popular), RustType.label, Modifier.padding(start = 20.dp, top = 6.dp), color = RustNeutral.TextSecondary)
                FlowRow(
                    Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    tags.forEach { tag -> PillChip("#$tag", false, { query = tag }) }
                }
                RustText(stringResource(R.string.search_recommended), RustType.label, Modifier.padding(start = 20.dp, top = 6.dp), color = RustNeutral.TextSecondary)
                GlassCard(Modifier.padding(horizontal = 16.dp)) {
                    accounts.forEachIndexed { i, handle ->
                        if (i > 0) RowDivider(inset = 72.dp)
                        AccountRow(handle, handle in social.following, { onToggleFollow(handle) }, { onOpenProfile(handle) })
                    }
                }
            } else if (result.accounts.isEmpty() && result.posts.isEmpty()) {
                RustText(stringResource(R.string.search_none), RustType.rowSubtitle, Modifier.padding(24.dp), color = RustNeutral.TextSecondary)
            } else {
                if (result.accounts.isNotEmpty()) {
                    GlassCard(Modifier.padding(horizontal = 16.dp)) {
                        result.accounts.forEachIndexed { i, handle ->
                            if (i > 0) RowDivider(inset = 72.dp)
                            AccountRow(handle, handle in social.following, { onToggleFollow(handle) }, { onOpenProfile(handle) })
                        }
                    }
                }
                if (result.posts.isNotEmpty()) {
                    GlassCard(Modifier.padding(horizontal = 16.dp)) {
                        result.posts.forEachIndexed { i, post ->
                            if (i > 0) RowDivider()
                            SettingsRow(
                                glyph = glyphOf(post.kind),
                                title = post.caption.ifBlank { post.author },
                                subtitle = post.author,
                                onClick = { onOpenPost(post) },
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
