package com.rustclient.app.data

import androidx.annotation.DrawableRes
import com.rustclient.app.R
import com.rustclient.core.ContentKind
import com.rustclient.core.FeedItem
import com.rustclient.core.MediaKind
import com.rustclient.core.MediaVariant
import com.rustclient.core.SampleFeed

/**
 * Builds the items the feed shows: the user's own posts (real files from the device) followed by the
 * bundled sample items. The content filters then run over this list through the core engine.
 */
object FeedRepository {
    private fun res(pkg: String, id: Int, height: Int) = MediaVariant("android.resource://$pkg/$id", height)

    fun sampleItems(pkg: String): List<FeedItem> = SampleFeed.items.map { item ->
        val variants = when (item.id) {
            "s1", "s13" -> listOf(res(pkg, R.raw.feed_neon, 540))
            "s7" -> listOf(res(pkg, R.raw.feed_sunset, 540))
            "s10" -> listOf(res(pkg, R.raw.feed_ocean, 540))
            "s12" -> listOf(res(pkg, R.raw.feed_matrix, 540))
            "s14" -> listOf(res(pkg, R.raw.feed_sakura, 540))
            "s6" -> listOf(res(pkg, R.raw.sample_360, 360), res(pkg, R.raw.sample_720, 720), res(pkg, R.raw.sample_1080, 1080))
            else -> emptyList()
        }
        item.copy(variants = variants)
    }

    @DrawableRes
    fun photoRes(id: String): Int? = when (id) {
        "s4" -> R.drawable.photo_1
        "s11" -> R.drawable.photo_2
        else -> null
    }

    fun postItems(posts: List<PostRecord>, handle: String): List<FeedItem> =
        posts.sortedByDescending { it.createdAt }.map { p ->
            FeedItem(
                id = "my:${p.id}",
                kind = if (p.kind == MediaKind.VIDEO) ContentKind.VIDEO else ContentKind.PHOTO,
                author = "@$handle",
                caption = p.caption,
                variants = listOf(MediaVariant(p.uri, 0)),
            )
        }

    fun all(pkg: String, social: Social, handle: String): List<FeedItem> = postItems(social.posts, handle) + sampleItems(pkg)

    fun isMine(item: FeedItem) = item.id.startsWith("my:")
}
