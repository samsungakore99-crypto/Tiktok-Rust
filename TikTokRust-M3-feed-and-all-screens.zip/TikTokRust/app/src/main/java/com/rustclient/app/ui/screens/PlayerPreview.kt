package com.rustclient.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.rustclient.app.R
import com.rustclient.app.data.DeviceStats
import com.rustclient.app.rust.Engines
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings
import com.rustclient.core.FitMode
import com.rustclient.core.MediaVariant
import kotlinx.coroutines.delay

private fun sampleVariants(pkg: String) = listOf(
    MediaVariant("android.resource://$pkg/${R.raw.sample_360}", 360),
    MediaVariant("android.resource://$pkg/${R.raw.sample_720}", 720),
    MediaVariant("android.resource://$pkg/${R.raw.sample_1080}", 1080),
)

@Composable
private fun OverlayBadge(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RustShape.pill)
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        RustText(text, RustType.caption, color = Color.White, maxLines = 1)
    }
}

/**
 * A real Media3 player on a bundled three-quality sample clip. Every player option is applied
 * live (autoplay, loop, speed, mute, fit, progress bar, tap to pause, double-tap seek, screen-on),
 * and the quality options choose the rendition through the same policy the feed player will use.
 */
@OptIn(UnstableApi::class)
@Composable
fun PlayerPreview(settings: AppSettings, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = settings.player
    val metered = remember { DeviceStats.isMetered(context) }
    val variants = remember { sampleVariants(context.packageName) }
    val chosen = remember(prefs.maxQuality, prefs.capOnCellular, metered) {
        Engines.current.pickVariant(variants, prefs.maxQuality, metered, prefs.capOnCellular)
    }
    val exo = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(exo) { onDispose { exo.release() } }

    LaunchedEffect(chosen?.url) {
        val url = chosen?.url ?: return@LaunchedEffect
        exo.setMediaItem(MediaItem.fromUri(url), exo.currentPosition)
        exo.prepare()
    }
    LaunchedEffect(prefs.autoplay, chosen?.url) { exo.playWhenReady = prefs.autoplay }
    LaunchedEffect(prefs.loop) { exo.repeatMode = if (prefs.loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF }
    LaunchedEffect(prefs.speed) { exo.setPlaybackSpeed(prefs.speed) }
    LaunchedEffect(prefs.muted) { exo.volume = if (prefs.muted) 0f else 1f }

    var position by remember { mutableStateOf(0L) }
    var duration by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(exo) {
        while (true) {
            position = exo.currentPosition
            duration = exo.duration.coerceAtLeast(0L)
            playing = exo.isPlaying
            delay(100)
        }
    }
    LaunchedEffect(flash) {
        if (flash != null) {
            delay(650)
            flash = null
        }
    }

    GlassCard(modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RustText(stringResource(R.string.pp_title), RustType.sectionTitle, Modifier.weight(1f), maxLines = 1)
                SampleTag()
            }
            Box(Modifier.fillMaxWidth().height(340.dp).clip(RustShape.tile).background(Color.Black)) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            player = exo
                        }
                    },
                    update = { view ->
                        view.resizeMode = when (prefs.fit) {
                            FitMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            FitMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                            FitMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        }
                        view.keepScreenOn = prefs.keepScreenOn
                    },
                    modifier = Modifier.fillMaxSize(),
                )
                Box(
                    Modifier.fillMaxSize().pointerInput(prefs.tapToPause, prefs.doubleTapSeek) {
                        detectTapGestures(
                            onTap = {
                                if (exo.playbackState == Player.STATE_ENDED) {
                                    exo.seekTo(0)
                                    exo.play()
                                } else if (prefs.tapToPause) {
                                    if (exo.isPlaying) exo.pause() else exo.play()
                                }
                            },
                            onDoubleTap = { offset ->
                                if (prefs.doubleTapSeek) {
                                    val forward = offset.x > size.width / 2
                                    val delta = if (forward) 10_000L else -10_000L
                                    exo.seekTo((exo.currentPosition + delta).coerceIn(0L, duration.coerceAtLeast(1L)))
                                    flash = if (forward) "+10 s" else "−10 s"
                                }
                            },
                        )
                    },
                )
                Row(
                    Modifier.align(Alignment.TopStart).padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    OverlayBadge("${chosen?.height ?: 0}p")
                    if (metered && prefs.capOnCellular) OverlayBadge(stringResource(R.string.pp_data_saver))
                }
                if (prefs.speed != 1f) {
                    OverlayBadge("${prefs.speed}×", Modifier.align(Alignment.TopEnd).padding(10.dp))
                }
                AnimatedVisibility(
                    visible = !playing,
                    modifier = Modifier.align(Alignment.Center),
                    enter = fadeIn() + scaleIn(initialScale = 0.8f),
                    exit = fadeOut() + scaleOut(targetScale = 0.8f),
                ) {
                    Box(Modifier.size(58.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
                        RustIcon(RustGlyph.Play, tint = Color.White, size = 28.dp)
                    }
                }
                flash?.let {
                    RustText(it, RustType.screenTitle, Modifier.align(Alignment.Center), color = Color.White)
                }
                if (prefs.showProgress) {
                    RustProgress(
                        progress = if (duration > 0) position.toFloat() / duration else 0f,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 10.dp),
                        height = 4.dp,
                    )
                }
            }
            RustText(stringResource(R.string.pp_hint), RustType.caption, color = RustNeutral.TextTertiary)
        }
    }
}
