package com.rustclient.app.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import kotlin.math.roundToInt

/** Single-line (or multi-line) text field in the glass style; the border glows on focus. */
@Composable
fun RustTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    leading: RustGlyph? = null,
    singleLine: Boolean = true,
    minHeight: Dp = 50.dp,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Done,
    onImeAction: () -> Unit = {},
    trailing: @Composable (() -> Unit)? = null,
) {
    val p = Rust.palette
    var focused by remember { mutableStateOf(false) }
    val border by animateColorAsState(
        targetValue = if (focused) p.accentBright else p.accent.copy(alpha = 0.25f),
        animationSpec = tween(160),
        label = "field",
    )
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.onFocusChanged { focused = it.isFocused },
        singleLine = singleLine,
        textStyle = RustType.rowTitle.copy(color = RustNeutral.TextPrimary),
        cursorBrush = SolidColor(p.accentBright),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(
            onDone = { onImeAction() },
            onGo = { onImeAction() },
            onSearch = { onImeAction() },
        ),
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = minHeight)
                    .clip(RustShape.tile)
                    .background(p.surface.copy(alpha = 0.92f))
                    .border(1.dp, border, RustShape.tile)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (leading != null) RustIcon(leading, tint = RustNeutral.TextSecondary, size = 20.dp)
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) {
                        RustText(placeholder, RustType.rowTitle, color = RustNeutral.TextTertiary, maxLines = 1)
                    }
                    inner()
                }
                trailing?.invoke()
            }
        },
    )
}

/** Pill segmented control with a spring-animated indicator. */
@Composable
fun SegmentedControl(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = Rust.palette
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(RustShape.pill)
            .background(p.surface)
            .border(1.dp, p.accent.copy(alpha = 0.25f), RustShape.pill)
            .padding(3.dp),
    ) {
        val segment = maxWidth / options.size
        val x by animateDpAsState(
            targetValue = segment * selected,
            animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow),
            label = "segment",
        )
        Box(Modifier.offset(x = x).width(segment).fillMaxHeight().clip(RustShape.pill).background(p.gradient))
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { index, label ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().pressable({ onSelect(index) }, pressedScale = 0.97f),
                    contentAlignment = Alignment.Center,
                ) {
                    RustText(
                        label,
                        RustType.chip,
                        color = if (index == selected) p.onAccent else RustNeutral.TextSecondary,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

@Composable
fun RustProgress(progress: Float, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    val p = Rust.palette
    val animated by animateFloatAsState(progress.coerceIn(0f, 1f), tween(300), label = "progress")
    Box(modifier.fillMaxWidth().height(height).clip(RustShape.pill).background(Color.White.copy(alpha = 0.08f))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(animated).clip(RustShape.pill).background(p.gradient))
    }
}

/** Horizontal slider drawn over any [brush] (hue rainbow, saturation ramp, ...). [value] is 0..1. */
@Composable
fun GradientSlider(
    value: Float,
    onChange: (Float) -> Unit,
    brush: Brush,
    thumbColor: Color,
    modifier: Modifier = Modifier,
) {
    var widthPx by remember { mutableStateOf(1f) }
    val current by rememberUpdatedState(onChange)
    val thumb = 28.dp
    Box(
        modifier
            .fillMaxWidth()
            .height(34.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o -> current((o.x / widthPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    current((change.position.x / widthPx).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(14.dp).clip(RustShape.pill).background(brush))
        Box(
            Modifier
                .offset { IntOffset((value.coerceIn(0f, 1f) * (widthPx - thumb.toPx())).roundToInt(), 0) }
                .size(thumb)
                .clip(CircleShape)
                .background(thumbColor)
                .border(3.dp, Color.White, CircleShape),
        )
    }
}

/** Profile picture with the gradient ring; falls back to the first letter of [initial]. */
@Composable
fun Avatar(bitmap: Bitmap?, initial: String, size: Dp, modifier: Modifier = Modifier) {
    val p = Rust.palette
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.sweepGradient(listOf(p.accentBright, p.accent, p.glowB, p.accentBright)))
            .padding(size * 0.045f),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(Brush.linearGradient(listOf(p.accentDeep, p.surface))),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) {
                Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                RustText(
                    initial.take(1).uppercase(),
                    RustType.screenTitle.copy(fontSize = (size.value * 0.42f).sp),
                    color = Color.White,
                )
            }
        }
    }
}
