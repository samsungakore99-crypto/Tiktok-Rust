package com.rustclient.app.ui.theme

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp

/** 4 dp grid. Screens use 16 dp side padding, cards 22 dp radius. */
object RustShape {
    val card = RoundedCornerShape(22.dp)
    val tile = RoundedCornerShape(18.dp)
    val icon = RoundedCornerShape(13.dp)
    val create = RoundedCornerShape(11.dp)
    val pill = RoundedCornerShape(percent = 50)
}

/**
 * One family, weights carry the hierarchy. To use a brand typeface, drop the .ttf files into
 * res/font and replace [family] with FontFamily(Font(R.font.your_font_regular), ...).
 */
object RustType {
    private val family = FontFamily.SansSerif

    val screenTitle = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp)
    val sectionTitle = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = (-0.1).sp)
    val rowTitle = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 20.sp)
    val rowSubtitle = TextStyle(fontFamily = family, fontWeight = FontWeight.Normal, fontSize = 12.5.sp, lineHeight = 17.sp)
    val chip = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 18.sp)
    val button = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp)
    val caption = TextStyle(fontFamily = family, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.2.sp)
    val value = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp)
    val label = TextStyle(fontFamily = family, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, lineHeight = 18.sp)
}

object RustMotion {
    /** Slightly bouncy spring for every press / toggle. */
    val press = spring<Float>(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium)
}
