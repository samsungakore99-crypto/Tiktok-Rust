package com.rustclient.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.data.Thumbs
import com.rustclient.app.data.Toasts
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.DownloadPolicy
import com.rustclient.core.MediaKind

/** Create: pick a video or photo from the device, add a caption, and it appears in your profile and feed. */
@Composable
fun CreateScreen(onBack: () -> Unit, onPost: (Uri, MediaKind, String) -> Unit) {
    val context = LocalContext.current
    val p = Rust.palette
    var picked by remember { mutableStateOf<Uri?>(null) }
    var kind by remember { mutableStateOf<MediaKind?>(null) }
    var caption by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val k = DownloadPolicy.kindFromMime(context.contentResolver.getType(uri))
            if (k == null) {
                Toasts.emit(R.string.create_unsupported)
            } else {
                picked = uri
                kind = k
            }
        }
    }
    val thumb by produceState<Bitmap?>(null, picked) {
        val uri = picked
        val k = kind
        value = if (uri != null && k != null) Thumbs.info(context, uri, k).thumb else null
    }

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.route_create), onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .pressable({ launcher.launch(arrayOf("video/*", "image/*")) }, pressedScale = 0.985f)
                    .clip(RustShape.card)
                    .background(Brush.verticalGradient(listOf(p.accent.copy(alpha = 0.28f), p.surface)))
                    .border(1.dp, p.accent.copy(alpha = 0.4f), RustShape.card),
                contentAlignment = Alignment.Center,
            ) {
                val bmp = thumb
                if (bmp != null) {
                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        RustIcon(RustGlyph.Plus, tint = p.accentBright, size = 44.dp, strokeWidth = 2.2f)
                        RustText(stringResource(R.string.create_pick), RustType.rowTitle)
                    }
                }
            }
            RustTextField(
                value = caption,
                onValueChange = { caption = it.take(150) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = stringResource(R.string.create_caption_hint),
                singleLine = false,
                minHeight = 84.dp,
            )
            InfoNote(R.string.create_note)
            RustButton(
                stringResource(R.string.create_post),
                {
                    val uri = picked
                    val k = kind
                    if (uri != null && k != null) onPost(uri, k, caption)
                },
                Modifier.fillMaxWidth(),
                enabled = picked != null,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
