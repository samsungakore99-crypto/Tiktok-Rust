package com.rustclient.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.rustclient.core.AppSettings
import com.rustclient.core.SettingsCodec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "rust_settings")

private fun Preferences.toFlatMap(): Map<String, String> =
    asMap().entries.associate { it.key.name to it.value.toString() }

/** Persists [AppSettings] as a flat string map (see [SettingsCodec]). */
class SettingsStore(private val context: Context) {
    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { SettingsCodec.decode(it.toFlatMap()) }

    /** Atomic read-modify-write. */
    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val next = transform(SettingsCodec.decode(prefs.toFlatMap()))
            SettingsCodec.encode(next).forEach { (k, v) -> prefs[stringPreferencesKey(k)] = v }
        }
    }

    suspend fun reset() {
        context.settingsDataStore.edit { it.clear() }
    }
}
