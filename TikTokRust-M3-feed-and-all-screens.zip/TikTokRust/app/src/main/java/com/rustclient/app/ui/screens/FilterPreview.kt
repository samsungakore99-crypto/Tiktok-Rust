package com.rustclient.app.ui.screens

import androidx.annotation.StringRes
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.rust.Engines
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.ContentKind
import com.rustclient.core.ContentRules
import com.rustclient.core.FeedItem
import com.rustclient.core.HideReason
import com.rustclient.core.SampleFeed

private class KindStyle(val glyph: RustGlyph, @StringRes val label: Int, val tint: Color?)

private fun kindStyle(kind: ContentKind): KindStyle = when (kind) {
    ContentKind.VIDEO -> KindStyle(RustGlyph.Play, R.string.kind_video, null)
    ContentKind.PHOTO -> KindStyle(RustGlyph.Image, R.string.kind_photo, null)
    ContentKind.LIVE -> KindStyle(RustGlyph.Live, R.string.kind_live, RustNeutral.Danger)
    ContentKind.STORY -> KindStyle(RustGlyph.Story, R.string.kind_story, null)
    ContentKind.REPOST -> KindStyle(RustGlyph.Repeat, R.string.kind_repost, null)
    ContentKind.AD -> KindStyle(RustGlyph.Block, R.string.kind_ad, RustNeutral.Gold)
    ContentKind.FRIEND_SUGGESTION -> KindStyle(RustGlyph.Friends, R.string.kind_friends, null)
    ContentKind.SHOP -> KindStyle(RustGlyph.Shop, R.string.kind_shop, null)
}

@StringRes
private fun reasonLabel(r: HideReason): Int = when (r) {
    HideReason.KIND -> R.string.reason_kind
    HideReason.KEYWORD -> R.string.reason_keyword
    HideReason.ACCOUNT -> R.string.reason_account
    HideReason.DURATION -> R.string.reason_duration
}

@Composable
private fun FeedChip(item: FeedItem) {
    val p = Rust.palette
    val style = kindStyle(item.kind)
    val tint = style.tint ?: p.accentBright
    Column(
        Modifier
            .padding(end = 8.dp)
            .width(78.dp)
            .height(104.dp)
            .clip(RustShape.tile)
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.28f), p.surface)))
            .border(1.dp, tint.copy(alpha = 0.45f), RustShape.tile)
            .padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        RustIcon(style.glyph, tint = tint, size = 24.dp)
        Column {
            RustText(stringResource(style.label), RustType.caption, color = RustNeutral.TextPrimary, maxLines = 1)
            RustText(item.author, RustType.caption.copy(fontSize = 10.sp), color = RustNeutral.TextSecondary, maxLines = 1)
        }
    }
}

/** Small explanatory note with an info icon. */
@Composable
fun InfoNote(@StringRes text: Int, modifier: Modifier = Modifier) {
    val p = Rust.palette
    Row(
        modifier
            .fillMaxWidth()
            .clip(RustShape.tile)
            .background(p.accent.copy(alpha = 0.10f))
            .border(1.dp, p.accent.copy(alpha = 0.25f), RustShape.tile)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        RustIcon(RustGlyph.Info, tint = p.accentBright, size = 20.dp)
        RustText(stringResource(text), RustType.rowSubtitle, color = RustNeutral.TextSecondary)
    }
}

@Composable
fun SampleTag() {
    val p = Rust.palette
    Box(
        Modifier
            .clip(RustShape.pill)
            .background(p.accent.copy(alpha = 0.18f))
            .border(1.dp, p.accent.copy(alpha = 0.4f), RustShape.pill)
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        RustText(stringResource(R.string.sample_tag), RustType.caption, color = p.accentBright, maxLines = 1)
    }
}

/**
 * Runs the real filter engine over a fixed sample feed so every toggle shows its effect at once.
 * Hidden items collapse with an animation; the numbers come from the same engine the feed will use.
 */
@Composable
fun FilterPreview(rules: ContentRules, modifier: Modifier = Modifier) {
    val result = remember(rules) { Engines.current.filter(SampleFeed.items, rules) }
    val hiddenIds = remember(result) { result.hidden.map { it.item.id }.toSet() }
    val parts = HideReason.entries.mapNotNull { reason ->
        val n = result.hidden.count { it.reason == reason }
        if (n > 0) "$n ${stringResource(reasonLabel(reason))}" else null
    }
    GlassCard(modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RustText(stringResource(R.string.fp_title), RustType.sectionTitle, Modifier.weight(1f), maxLines = 1)
                SampleTag()
            }
            RustText(
                stringResource(R.string.fp_summary, result.visible.size, SampleFeed.items.size),
                RustType.rowSubtitle,
                color = RustNeutral.TextSecondary,
            )
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                SampleFeed.items.forEach { item ->
                    key(item.id) {
                        AnimatedVisibility(
                            visible = item.id !in hiddenIds,
                            enter = fadeIn() + expandHorizontally(),
                            exit = fadeOut() + shrinkHorizontally(),
                        ) { FeedChip(item) }
                    }
                }
            }
            RustText(
                if (parts.isEmpty()) stringResource(R.string.fp_nothing_hidden) else stringResource(R.string.fp_hidden, parts.joinToString(" · ")),
                RustType.caption,
                color = RustNeutral.TextTertiary,
            )
        }
    }
}
