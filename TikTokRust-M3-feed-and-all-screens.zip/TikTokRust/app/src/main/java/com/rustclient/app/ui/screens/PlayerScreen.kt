package com.rustclient.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import android.view.LayoutInflater
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.rustclient.app.R
import com.rustclient.app.data.DeviceStats
import com.rustclient.app.data.decodeScaled
import com.rustclient.app.rust.Engines
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.app.vm.PlayerRequest
import com.rustclient.core.AppSettings
import com.rustclient.core.FitMode
import com.rustclient.core.MediaKind
import com.rustclient.core.SettingsCodec
import kotlinx.coroutines.delay

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(total / 60, total % 60)
}

private fun speedLabel(f: Float) = if (f % 1f == 0f) "${f.toInt()}×" else "${f}×"

@Composable
private fun RoundButton(glyph: RustGlyph, active: Boolean, label: String, onClick: () -> Unit) {
    val p = Rust.palette
    Box(
        Modifier.size(44.dp).pressable(onClick, pressedScale = 0.9f).clip(CircleShape)
            .background(if (active) p.accent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center,
    ) { RustIcon(glyph, tint = if (active) p.accentBright else Color.White, size = 22.dp) }
}

/** Full-screen viewer. Videos get a scrubber, quality menu, speed, loop, mute and scaling; photos are shown edge to edge. */
@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(request: PlayerRequest?, settings: AppSettings, onClose: () -> Unit) {
    if (request == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    if (request.kind == MediaKind.PHOTO) {
        PhotoViewer(request, onClose)
        return
    }

    val context = LocalContext.current
    val p = Rust.palette
    val prefs = settings.player
    val metered = remember { DeviceStats.isMetered(context) }
    var pickedHeight by remember { mutableStateOf<Int?>(null) }
    val variant = pickedHeight?.let { h -> request.variants.firstOrNull { it.height == h } }
        ?: Engines.current.pickVariant(request.variants, prefs.maxQuality, metered, prefs.capOnCellular)
    var speed by remember { mutableStateOf(prefs.speed) }
    var loop by remember { mutableStateOf(prefs.loop) }
    var muted by remember { mutableStateOf(prefs.muted) }
    var fit by remember { mutableStateOf(prefs.fit) }
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(0) }
    var qualityDialog by remember { mutableStateOf(false) }

    val exo = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(exo) { onDispose { exo.release() } }
    LaunchedEffect(variant?.url) {
        val url = variant?.url ?: return@LaunchedEffect
        exo.setMediaItem(MediaItem.fromUri(url), exo.currentPosition)
        exo.prepare()
        exo.playWhenReady = true
    }
    LaunchedEffect(loop) { exo.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF }
    LaunchedEffect(speed) { exo.setPlaybackSpeed(speed) }
    LaunchedEffect(muted) { exo.volume = if (muted) 0f else 1f }

    var position by remember { mutableStateOf(0L) }
    var duration by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(exo) {
        while (true) {
            position = exo.currentPosition
            duration = exo.duration.coerceAtLeast(0L)
            playing = exo.isPlaying
            delay(100)
        }
    }
    LaunchedEffect(controls, playing, touch) {
        if (controls && playing) {
            delay(3000)
            controls = false
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
            detectTapGestures(onTap = {
                controls = !controls
                touch++
            })
        },
    ) {
        AndroidView(
            factory = { ctx -> LayoutInflater.from(ctx).inflate(R.layout.view_player_texture, null, false) as PlayerView },
            update = { view ->
                view.player = exo
                view.resizeMode = when (fit) {
                    FitMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    FitMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    FitMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
                view.keepScreenOn = prefs.keepScreenOn
            },
            modifier = Modifier.fillMaxSize(),
        )
        AnimatedVisibility(visible = controls, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f))) {
                Row(
                    Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    RoundButton(RustGlyph.Close, false, stringResource(R.string.action_close), onClose)
                    RustText(request.title, RustType.sectionTitle, Modifier.weight(1f), color = Color.White, maxLines = 1)
                    if (request.variants.size > 1) {
                        Row(
                            Modifier.pressable({ qualityDialog = true }, pressedScale = 0.95f).clip(RustShape.pill)
                                .background(Color.White.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RustText("${variant?.height ?: 0}p", RustType.chip, color = Color.White)
                            RustIcon(RustGlyph.ChevronDown, tint = Color.White, size = 18.dp)
                        }
                    }
                }
                Box(
                    Modifier.align(Alignment.Center).size(76.dp)
                        .pressable({
                            if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0)
                            if (exo.isPlaying) exo.pause() else exo.play()
                            touch++
                        }, pressedScale = 0.9f)
                        .clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center,
                ) { RustIcon(if (playing) RustGlyph.Pause else RustGlyph.Play, tint = Color.White, size = 36.dp) }
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val fraction = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
                    GradientSlider(
                        value = fraction,
                        onChange = { f ->
                            if (duration > 0) exo.seekTo((f * duration).toLong())
                            touch++
                        },
                        brush = Brush.horizontalGradient(
                            0f to p.accent,
                            fraction to p.accentBright,
                            fraction to Color.White.copy(alpha = 0.22f),
                            1f to Color.White.copy(alpha = 0.22f),
                        ),
                        thumbColor = p.accentBright,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RustText("${formatTime(position)} / ${formatTime(duration)}", RustType.caption, Modifier.weight(1f), color = Color.White)
                        Box(
                            Modifier.height(44.dp).pressable({
                                val speeds = SettingsCodec.speeds
                                speed = speeds[(speeds.indexOfFirst { it == speed } + 1) % speeds.size]
                                touch++
                            }, pressedScale = 0.92f).clip(RustShape.pill).background(Color.White.copy(alpha = 0.12f)).padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center,
                        ) { RustText(speedLabel(speed), RustType.chip, color = Color.White) }
                        RoundButton(RustGlyph.Repeat, loop, "loop") { loop = !loop }
                        RoundButton(RustGlyph.VolumeOff, muted, "mute") { muted = !muted }
                        RoundButton(RustGlyph.Maximize, fit != FitMode.FIT, "fit") { fit = FitMode.entries[(fit.ordinal + 1) % FitMode.entries.size] }
                    }
                }
            }
        }
    }
    if (qualityDialog) {
        val heights = request.variants.sortedByDescending { it.height }.map { it.height }
        val selected = heights.indexOf(variant?.height ?: -1).coerceAtLeast(0)
        ChoiceDialog(
            title = stringResource(R.string.sp_pquality_t),
            options = heights.map { "${it}p" },
            selected = selected,
            onSelect = { i -> pickedHeight = heights[i] },
            onDismiss = { qualityDialog = false },
        )
    }
}

@Composable
private fun PhotoViewer(request: PlayerRequest, onClose: () -> Unit) {
    val context = LocalContext.current
    val url = request.variants.firstOrNull()?.url
    val bitmap by produceState<Bitmap?>(null, url) {
        value = if (request.photoRes == null && url != null) decodeScaled(context, Uri.parse(url), 1600) else null
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val res = request.photoRes
        if (res != null) {
            Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } else {
            bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RoundButton(RustGlyph.Close, false, stringResource(R.string.action_close), onClose)
            RustText(request.title, RustType.sectionTitle, Modifier.weight(1f), color = Color.White, maxLines = 1)
        }
    }
}
