package com.rustclient.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RustShape.card,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(modifier.glass(shape), content = content)
}

/** Rounded-square icon holder used at the start of every settings row. */
@Composable
fun IconTile(
    glyph: RustGlyph,
    modifier: Modifier = Modifier,
    emphasized: Boolean = false,
) {
    val p = Rust.palette
    Box(
        modifier
            .size(42.dp)
            .clip(RustShape.icon)
            .background(
                Brush.linearGradient(
                    listOf(p.accent.copy(alpha = if (emphasized) 0.40f else 0.20f), p.accentDeep.copy(alpha = 0.10f)),
                ),
            )
            .border(1.dp, p.accent.copy(alpha = if (emphasized) 0.55f else 0.35f), RustShape.icon),
        contentAlignment = Alignment.Center,
    ) {
        RustIcon(glyph, tint = p.accentBright, size = 22.dp)
    }
}

@Composable
fun RowDivider(modifier: Modifier = Modifier, inset: Dp = 70.dp) {
    Box(
        modifier
            .fillMaxWidth()
            .padding(start = inset)
            .height(1.dp)
            .background(RustNeutral.Hairline),
    )
}

/** Standard list row: icon tile, title + subtitle, and a trailing slot (chevron by default). */
@Composable
fun SettingsRow(
    glyph: RustGlyph,
    title: String,
    subtitle: String?,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    emphasized: Boolean = false,
    trailing: @Composable () -> Unit = {
        RustIcon(RustGlyph.ChevronRight, tint = RustNeutral.TextTertiary, size = 20.dp)
    },
) {
    Row(
        modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.pressable(onClick, pressedScale = 0.985f) else Modifier)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        IconTile(glyph, emphasized = emphasized)
        Column(Modifier.weight(1f)) {
            RustText(title, RustType.rowTitle, maxLines = 1)
            if (subtitle != null) {
                RustText(subtitle, RustType.rowSubtitle, color = RustNeutral.TextSecondary, maxLines = 2)
            }
        }
        trailing()
    }
}

/** Collapsible group (e.g. "Удаление и скрытие контента") with an animated chevron. */
@Composable
fun SectionCard(
    title: String,
    glyph: RustGlyph,
    modifier: Modifier = Modifier,
    initiallyExpanded: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = Rust.palette
    var expanded by rememberSaveable { mutableStateOf(initiallyExpanded) }
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "chevron",
    )
    GlassCard(modifier) {
        Row(
            Modifier
                .fillMaxWidth()
                .pressable({ expanded = !expanded }, pressedScale = 0.99f)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RustIcon(glyph, tint = p.accentBright, size = 22.dp)
            RustText(title, RustType.sectionTitle, Modifier.weight(1f), maxLines = 1)
            RustIcon(
                RustGlyph.ChevronDown,
                Modifier.graphicsLayer { rotationZ = rotation },
                tint = RustNeutral.TextSecondary,
                size = 22.dp,
            )
        }
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
            exit = shrinkVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeOut(),
        ) {
            Column {
                RowDivider(inset = 0.dp)
                content()
            }
        }
    }
}

/** Compact metric card: icon, label, value and an optional status dot. */
@Composable
fun StatTile(
    glyph: RustGlyph,
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    status: String? = null,
    statusColor: Color = RustNeutral.Success,
) {
    val p = Rust.palette
    GlassCard(modifier, RustShape.tile) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            RustIcon(glyph, tint = p.accentBright, size = 24.dp)
            Column {
                RustText(label, RustType.caption, color = RustNeutral.TextSecondary)
                RustText(value, RustType.value, maxLines = 1)
            }
            if (status != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Box(Modifier.size(6.dp).background(statusColor, CircleShape))
                    RustText(status, RustType.caption, color = statusColor, maxLines = 1)
                }
            }
        }
    }
}

/** Wide feature banner with the crown mark, used at the top of Mod Functions / About. */
@Composable
fun HeroBanner(title: String, subtitle: String, modifier: Modifier = Modifier) {
    val p = Rust.palette
    Row(
        modifier
            .fillMaxWidth()
            .clip(RustShape.card)
            .background(
                Brush.linearGradient(
                    listOf(p.accentDeep.copy(alpha = 0.55f), p.surface, p.accent.copy(alpha = 0.30f)),
                ),
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(p.accentBright.copy(alpha = 0.55f), p.accent.copy(alpha = 0.10f))),
                RustShape.card,
            )
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        CrownMark(size = 76.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            RustText(title, RustType.screenTitle, maxLines = 1)
            RustText(subtitle, RustType.rowSubtitle, color = RustNeutral.TextSecondary, maxLines = 3)
        }
    }
}
