package com.rustclient.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Keeps one square profile picture in app storage (the picker's URI is only temporarily readable). */
object AvatarStore {
    private fun file(context: Context) = File(context.filesDir, "avatar.jpg")

    suspend fun save(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val decoded = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@withContext false
            val side = minOf(decoded.width, decoded.height)
            val square = Bitmap.createBitmap(decoded, (decoded.width - side) / 2, (decoded.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(square, 384, 384, true)
            file(context).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun load(context: Context): Bitmap? = withContext(Dispatchers.IO) {
        file(context).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
    }

    fun delete(context: Context) {
        file(context).delete()
    }
}
