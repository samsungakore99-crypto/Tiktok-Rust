package com.rustclient.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*

/** Neon switch: spring thumb that stretches while pressed, gradient track with a glow when on. */
@Composable
fun RustSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = Rust.palette
    val haptics = LocalHapticFeedback.current
    val motion = LocalMotion.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val progress by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "switch",
    )
    val stretch by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "stretch",
    )
    Canvas(
        modifier
            .size(width = 52.dp, height = 30.dp)
            .toggleable(
                value = checked,
                interactionSource = source,
                indication = null,
                role = Role.Switch,
                onValueChange = {
                    if (motion.haptics) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onCheckedChange(it)
                },
            ),
    ) {
        val w = size.width
        val h = size.height
        val on = progress.coerceIn(0f, 1f)
        val corner = CornerRadius(h / 2f)
        val g = 5.dp.toPx()
        if (on > 0.01f) {
            drawRoundRect(
                color = p.accent.copy(alpha = 0.20f * on),
                topLeft = Offset(-g, -g * 0.6f),
                size = Size(w + g * 2f, h + g * 1.2f),
                cornerRadius = CornerRadius(h / 2f + g),
            )
        }
        drawRoundRect(color = lerp(RustNeutral.OffTrack, p.accent, on), cornerRadius = corner)
        drawRoundRect(
            brush = Brush.horizontalGradient(listOf(p.accentDeep, p.accentBright), startX = 0f, endX = w),
            cornerRadius = corner,
            alpha = on,
        )
        val pad = 3.dp.toPx()
        val thumbH = h - pad * 2f
        val thumbW = thumbH + stretch * 5.dp.toPx()
        val x = pad + (w - pad * 2f - thumbW) * progress
        val thumbCorner = CornerRadius(thumbH / 2f)
        drawRoundRect(
            color = Color.Black.copy(alpha = 0.28f),
            topLeft = Offset(x, pad + 1.dp.toPx()),
            size = Size(thumbW, thumbH),
            cornerRadius = thumbCorner,
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(x, pad),
            size = Size(thumbW, thumbH),
            cornerRadius = thumbCorner,
        )
    }
}

/** Filter pill. Selecting it fades in the accent gradient and a glow. */
@Composable
fun PillChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = Rust.palette
    val fill by animateFloatAsState(if (selected) 1f else 0f, tween(260), label = "chip")
    Box(
        modifier
            .height(40.dp)
            .pressable(onClick)
            .neonGlow(p.accent, 12.dp, 0.55f * fill)
            .clip(RustShape.pill)
            .background(p.surface)
            .drawBehind { drawRect(p.gradient, alpha = fill.coerceIn(0f, 1f)) }
            .border(1.dp, p.accent.copy(alpha = 0.30f * (1f - fill.coerceIn(0f, 1f))), RustShape.pill)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        RustText(
            text,
            RustType.chip,
            color = lerp(RustNeutral.TextSecondary, p.onAccent, fill.coerceIn(0f, 1f)),
            maxLines = 1,
        )
    }
}

enum class ButtonStyle { Primary, Ghost, Follow }

@Composable
fun RustButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: ButtonStyle = ButtonStyle.Primary,
    icon: RustGlyph? = null,
    height: Dp = 52.dp,
    enabled: Boolean = true,
) {
    val p = Rust.palette
    val shape = RustShape.pill
    val contentColor = when (style) {
        ButtonStyle.Primary -> p.onAccent
        ButtonStyle.Ghost -> p.accentBright
        ButtonStyle.Follow -> Color.White
    }
    val base = modifier.height(height).alpha(if (enabled) 1f else 0.45f).pressable(onClick, enabled = enabled, pressedScale = 0.96f)
    val surface = when (style) {
        ButtonStyle.Primary -> base
            .neonGlow(p.accent, 20.dp, 0.55f)
            .clip(shape)
            .background(p.gradient)
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                        endY = size.height * 0.6f,
                    ),
                )
            }
        ButtonStyle.Ghost -> base
            .clip(shape)
            .background(p.accent.copy(alpha = 0.10f))
            .border(1.dp, p.accent.copy(alpha = 0.75f), shape)
        ButtonStyle.Follow -> base
            .clip(shape)
            .background(RustNeutral.Danger)
    }
    Row(
        surface.padding(horizontal = 22.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) RustIcon(icon, tint = contentColor, size = 20.dp)
        RustText(text, RustType.button, color = contentColor, maxLines = 1)
    }
}

/** Red unread counter, e.g. "99+". */
@Composable
fun CountBadge(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .defaultMinSize(minWidth = 20.dp)
            .height(16.dp)
            .clip(RustShape.pill)
            .background(RustNeutral.Danger)
            .padding(horizontal = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
        RustText(
            text,
            RustType.caption.copy(fontSize = 10.sp, lineHeight = 12.sp, fontWeight = FontWeight.Bold),
            color = Color.White,
            maxLines = 1,
        )
    }
}

/** Accent pill for new features, e.g. "NEW". */
@Composable
fun NewBadge(text: String, modifier: Modifier = Modifier) {
    val p = Rust.palette
    Box(
        modifier
            .height(22.dp)
            .clip(RustShape.pill)
            .background(p.gradient)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        RustText(text, RustType.caption.copy(fontWeight = FontWeight.Bold), color = p.onAccent, maxLines = 1)
    }
}

/** Round glass button for top bars. [label] is the accessibility description. */
@Composable
fun GlassIconButton(
    glyph: RustGlyph,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
) {
    val p = Rust.palette
    Box(
        modifier
            .size(40.dp)
            .pressable(onClick, pressedScale = 0.9f)
            .clip(CircleShape)
            .background(p.surface.copy(alpha = 0.85f))
            .border(1.dp, p.accent.copy(alpha = 0.25f), CircleShape)
            .semantics {
                contentDescription = label
                role = Role.Button
            },
        contentAlignment = Alignment.Center,
    ) {
        RustIcon(glyph, tint = RustNeutral.TextPrimary, size = 22.dp)
    }
}
