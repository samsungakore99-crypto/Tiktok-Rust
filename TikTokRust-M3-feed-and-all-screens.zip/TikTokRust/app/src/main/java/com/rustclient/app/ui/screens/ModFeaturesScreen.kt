package com.rustclient.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*
import com.rustclient.app.R
import com.rustclient.app.Routes
import com.rustclient.app.ui.components.*
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.theme.*
import com.rustclient.core.AppSettings

/**
 * Mod Features: category chips, search, "only enabled" filter, per-category reset, collapsible
 * groups of real switches, plus a live preview for the Content and Player categories.
 */
@Composable
fun ModFeaturesScreen(
    initialCategory: String,
    settings: AppSettings,
    onUpdate: Update,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val context = LocalContext.current
    var categoryKey by rememberSaveable { mutableStateOf(ModCategory.from(initialCategory).key) }
    var query by rememberSaveable { mutableStateOf("") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var onlyActive by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    val category = ModCategory.from(categoryKey)
    val groups = ModCatalog.groups.filter { category == ModCategory.ALL || it.category == category }
    val anyVisible = groups.any { filterSpecs(it, settings, context, query, onlyActive).isNotEmpty() }
    val onAction: (String) -> Unit = { id ->
        when (id) {
            "open_themes" -> onNavigate(Routes.Themes)
            "open_downloads" -> onNavigate(Routes.Downloads)
            else -> Unit
        }
    }
    val side = Modifier.padding(horizontal = 16.dp)

    Column(Modifier.fillMaxSize()) {
        RustTopBar(title = stringResource(R.string.route_mod), onBack = onBack) {
            GlassIconButton(
                if (searching) RustGlyph.Close else RustGlyph.Search,
                {
                    searching = !searching
                    if (!searching) query = ""
                },
                stringResource(R.string.action_search),
            )
            CrownMark(size = 34.dp, animated = false)
        }
        AnimatedVisibility(visible = searching) {
            RustTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = stringResource(R.string.search_features_hint),
                leading = RustGlyph.Search,
                imeAction = ImeAction.Search,
            )
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            HeroBanner(stringResource(R.string.brand_name), stringResource(R.string.brand_tagline), side)
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ModCategory.entries.forEach { c ->
                    PillChip(stringResource(c.label), c == category, { categoryKey = c.key })
                }
                GlassIconButton(RustGlyph.Tune, { menu = true }, stringResource(R.string.menu_options))
            }
            if (category == ModCategory.CONTENT) {
                InfoNote(R.string.info_filters, side)
                FilterPreview(settings.content, side)
            }
            if (category == ModCategory.PLAYER) PlayerPreview(settings, side)
            if (category == ModCategory.DOWNLOADS) InfoNote(R.string.info_downloads, side)
            groups.forEach { group ->
                SpecGroupCard(
                    group = group,
                    settings = settings,
                    onUpdate = onUpdate,
                    onAction = onAction,
                    modifier = side,
                    query = query,
                    onlyActive = onlyActive,
                    actionValue = { id -> if (id == "open_themes") themeName(settings) else null },
                )
            }
            if (!anyVisible) {
                RustText(
                    stringResource(R.string.search_none),
                    RustType.rowSubtitle,
                    Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    color = RustNeutral.TextSecondary,
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (menu) {
        ActionSheetDialog(
            title = stringResource(R.string.menu_options),
            actions = listOf(
                SheetAction(
                    stringResource(if (onlyActive) R.string.menu_show_all else R.string.menu_only_enabled),
                    RustGlyph.Check,
                    onClick = { onlyActive = !onlyActive },
                ),
                SheetAction(
                    stringResource(R.string.menu_reset_visible),
                    RustGlyph.Refresh,
                    destructive = true,
                    onClick = { confirmReset = true },
                ),
            ),
            onDismiss = { menu = false },
        )
    }
    if (confirmReset) {
        ConfirmDialog(
            title = stringResource(R.string.menu_reset_visible),
            message = stringResource(R.string.confirm_reset_visible),
            confirmLabel = stringResource(R.string.action_reset),
            cancelLabel = stringResource(R.string.action_cancel),
            onConfirm = {
                onUpdate { s -> groups.flatMap { it.specs }.distinct().fold(s) { acc, spec -> spec.resetIn(acc) } }
            },
            onDismiss = { confirmReset = false },
            destructive = true,
        )
    }
}
