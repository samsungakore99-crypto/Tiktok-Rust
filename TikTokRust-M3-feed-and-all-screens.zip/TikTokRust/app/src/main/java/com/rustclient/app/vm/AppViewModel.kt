package com.rustclient.app.vm

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rustclient.app.R
import com.rustclient.app.data.AvatarStore
import com.rustclient.app.data.SettingsStore
import com.rustclient.app.data.Toasts
import com.rustclient.core.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Single source of truth for persisted settings. `null` until DataStore delivers the first value. */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)

    val settings: StateFlow<AppSettings?> = store.settings
        .map<AppSettings, AppSettings?> { it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { store.update(transform) }
    }

    fun resetAll() {
        viewModelScope.launch {
            store.reset()
            AvatarStore.delete(getApplication<Application>())
            Toasts.emit(R.string.toast_reset_done)
        }
    }

    fun setAvatar(uri: Uri) {
        viewModelScope.launch {
            if (AvatarStore.save(getApplication<Application>(), uri)) {
                store.update { it.copy(profile = it.profile.copy(avatarRev = it.profile.avatarRev + 1)) }
            } else {
                Toasts.emit(R.string.toast_avatar_failed)
            }
        }
    }

    fun removeAvatar() {
        viewModelScope.launch {
            AvatarStore.delete(getApplication<Application>())
            store.update { it.copy(profile = it.profile.copy(avatarRev = it.profile.avatarRev + 1)) }
        }
    }
}
