package com.rustclient.app.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.rustclient.app.ui.icons.RustGlyph
import com.rustclient.app.ui.icons.RustIcon
import com.rustclient.app.ui.theme.*
import com.rustclient.core.SettingsCodec

/** Opaque base + glass overlay so text stays readable over the dimmed app. */
@Composable
fun RustDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val p = Rust.palette
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .background(p.bgTop, RustShape.card)
                .glass(RustShape.card, 0.55f)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content,
        )
    }
}

@Composable
fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val p = Rust.palette
    RustDialog(onDismiss) {
        RustText(title, RustType.screenTitle)
        Column(Modifier.verticalScroll(rememberScrollState()).heightIn(max = 380.dp)) {
            options.forEachIndexed { index, label ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .pressable({
                            onSelect(index)
                            onDismiss()
                        }, pressedScale = 0.98f)
                        .padding(vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    RustText(
                        label,
                        RustType.rowTitle,
                        Modifier.weight(1f),
                        color = if (index == selected) p.accentBright else RustNeutral.TextPrimary,
                    )
                    if (index == selected) RustIcon(RustGlyph.Check, tint = p.accentBright, size = 20.dp)
                }
                if (index < options.lastIndex) RowDivider(inset = 0.dp)
            }
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    cancelLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    destructive: Boolean = false,
) {
    RustDialog(onDismiss) {
        RustText(title, RustType.screenTitle)
        RustText(
            message,
            RustType.rowSubtitle.copy(fontSize = 14.sp, lineHeight = 20.sp),
            color = RustNeutral.TextSecondary,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RustButton(cancelLabel, onDismiss, Modifier.weight(1f), ButtonStyle.Ghost, height = 46.dp)
            RustButton(
                confirmLabel,
                {
                    onConfirm()
                    onDismiss()
                },
                Modifier.weight(1f),
                if (destructive) ButtonStyle.Follow else ButtonStyle.Primary,
                height = 46.dp,
            )
        }
    }
}

@Composable
fun InputDialog(
    title: String,
    initial: String,
    hint: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    RustDialog(onDismiss) {
        RustText(title, RustType.screenTitle)
        RustTextField(
            text,
            { text = it },
            Modifier.fillMaxWidth(),
            placeholder = hint,
            onImeAction = {
                onConfirm(text)
                onDismiss()
            },
        )
        RustButton(
            confirmLabel,
            {
                onConfirm(text)
                onDismiss()
            },
            Modifier.fillMaxWidth(),
            height = 46.dp,
        )
    }
}

/** Editor for a list of short strings (muted words / accounts): add with Enter, tap a chip to remove. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordsDialog(
    title: String,
    hint: String,
    words: List<String>,
    addLabel: String,
    emptyLabel: String,
    doneLabel: String,
    onChange: (List<String>) -> Unit,
    onDismiss: () -> Unit,
) {
    val p = Rust.palette
    var input by remember { mutableStateOf("") }
    fun add() {
        val word = SettingsCodec.cleanWord(input)
        if (word.isNotEmpty() && words.none { it.equals(word, ignoreCase = true) }) onChange(words + word)
        input = ""
    }
    RustDialog(onDismiss) {
        RustText(title, RustType.screenTitle)
        RustTextField(
            input,
            { input = it },
            Modifier.fillMaxWidth(),
            placeholder = hint,
            onImeAction = { add() },
            trailing = { GlassIconButton(RustGlyph.Plus, { add() }, addLabel, Modifier.size(34.dp)) },
        )
        if (words.isEmpty()) RustText(emptyLabel, RustType.rowSubtitle, color = RustNeutral.TextTertiary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            words.forEach { word ->
                Row(
                    Modifier
                        .clip(RustShape.pill)
                        .background(p.accent.copy(alpha = 0.18f))
                        .border(1.dp, p.accent.copy(alpha = 0.4f), RustShape.pill)
                        .pressable({ onChange(words - word) }, pressedScale = 0.95f)
                        .padding(start = 12.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    RustText(word, RustType.chip, maxLines = 1)
                    RustIcon(RustGlyph.Close, tint = RustNeutral.TextSecondary, size = 16.dp)
                }
            }
        }
        RustButton(doneLabel, onDismiss, Modifier.fillMaxWidth(), height = 46.dp)
    }
}

class SheetAction(
    val label: String,
    val glyph: RustGlyph,
    val destructive: Boolean = false,
    val onClick: () -> Unit,
)

@Composable
fun ActionSheetDialog(title: String, actions: List<SheetAction>, onDismiss: () -> Unit) {
    val p = Rust.palette
    RustDialog(onDismiss) {
        RustText(title, RustType.sectionTitle, maxLines = 2)
        actions.forEach { action ->
            val color = if (action.destructive) RustNeutral.Danger else RustNeutral.TextPrimary
            Row(
                Modifier
                    .fillMaxWidth()
                    .pressable({
                        action.onClick()
                        onDismiss()
                    }, pressedScale = 0.98f)
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                RustIcon(action.glyph, tint = if (action.destructive) RustNeutral.Danger else p.accentBright, size = 22.dp)
                RustText(action.label, RustType.rowTitle, color = color)
            }
        }
    }
}
