package com.rustclient.core

/** Everything a feed can contain. Filters and the live preview work on these kinds. */
enum class ContentKind { VIDEO, PHOTO, LIVE, STORY, REPOST, AD, FRIEND_SUGGESTION, SHOP }

/** One playable rendition of a video (progressive file or stream URL). */
data class MediaVariant(val url: String, val height: Int, val bitrateKbps: Int = 0)

data class FeedItem(
    val id: String,
    val kind: ContentKind,
    val author: String,
    val caption: String = "",
    val tags: List<String> = emptyList(),
    val durationSec: Int = 0,
    val variants: List<MediaVariant> = emptyList(),
)
