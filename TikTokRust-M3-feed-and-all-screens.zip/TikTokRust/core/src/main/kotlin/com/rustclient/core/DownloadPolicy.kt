package com.rustclient.core

import java.net.URI

enum class MediaKind { VIDEO, PHOTO }

enum class Rejection { EMPTY, NOT_HTTPS, INVALID, TIKTOK_HOST }

sealed interface UrlCheck {
    /** [kind] is null when the extension is unknown and the server must be asked (HEAD). */
    data class Ok(val url: String, val kind: MediaKind?, val fileName: String) : UrlCheck
    data class Rejected(val reason: Rejection) : UrlCheck
}

/**
 * What the download manager accepts. Only direct HTTPS links to media files are allowed, and
 * TikTok hosts are refused: TikTok offers no API to fetch video files, and saving is only
 * permitted through its own Save button when the creator allows downloads.
 */
object DownloadPolicy {
    private val videoExt = setOf("mp4", "m4v", "mov", "webm", "mkv", "3gp")
    private val photoExt = setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "avif")
    private val blockedHosts = listOf(
        "tiktok.com", "tiktokv.com", "tiktokcdn.com", "tiktokcdn-us.com", "musical.ly", "byteoversea.com", "ibytedtos.com",
    )

    fun isBlockedHost(host: String): Boolean {
        val h = host.lowercase().trimEnd('.')
        return blockedHosts.any { h == it || h.endsWith(".$it") }
    }

    fun check(raw: String): UrlCheck {
        val text = raw.trim()
        if (text.isEmpty()) return UrlCheck.Rejected(Rejection.EMPTY)
        val uri = try { URI(text) } catch (e: Exception) { return UrlCheck.Rejected(Rejection.INVALID) }
        val scheme = uri.scheme?.lowercase() ?: return UrlCheck.Rejected(Rejection.INVALID)
        val host = uri.host ?: return UrlCheck.Rejected(Rejection.INVALID)
        if (isBlockedHost(host)) return UrlCheck.Rejected(Rejection.TIKTOK_HOST)
        if (scheme != "https") return UrlCheck.Rejected(if (scheme == "http") Rejection.NOT_HTTPS else Rejection.INVALID)
        val last = (uri.path ?: "").substringAfterLast('/')
        val decoded = last // URI.path is already percent-decoded
        val ext = decoded.substringAfterLast('.', "").lowercase()
        val kind = when (ext) {
            in videoExt -> MediaKind.VIDEO
            in photoExt -> MediaKind.PHOTO
            else -> null
        }
        return UrlCheck.Ok(text, kind, safeFileName(decoded, "download"))
    }

    fun kindFromMime(mime: String?): MediaKind? {
        val m = mime?.substringBefore(';')?.trim()?.lowercase() ?: return null
        return when {
            m.startsWith("video/") -> MediaKind.VIDEO
            m.startsWith("image/") -> MediaKind.PHOTO
            else -> null
        }
    }

    fun extensionFor(mime: String?, kind: MediaKind): String {
        val m = mime?.substringBefore(';')?.trim()?.lowercase()
        return when (m) {
            "video/mp4" -> "mp4"
            "video/webm" -> "webm"
            "video/quicktime" -> "mov"
            "video/x-matroska" -> "mkv"
            "image/jpeg" -> "jpg"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/gif" -> "gif"
            else -> if (kind == MediaKind.VIDEO) "mp4" else "jpg"
        }
    }

    /** File-system safe name: no separators or control characters, at most 80 chars, never empty. */
    fun safeFileName(name: String, fallback: String): String {
        val cleaned = name.map { if (it.isISOControl() || it in "\\/:*?\"<>|") '_' else it }
            .joinToString("").trim().trim('.').take(80)
        return cleaned.ifBlank { fallback }
    }

    fun withExtension(name: String, ext: String): String =
        if (name.substringAfterLast('.', "").lowercase() in videoExt + photoExt) name else "$name.$ext"

    /** One folder level under Movies/Pictures/Download. */
    fun safeFolder(raw: String): String {
        val cleaned = raw.filter { it.isLetterOrDigit() || it == ' ' || it == '_' || it == '-' }.trim().take(40)
        return cleaned.ifBlank { "TikTokRust" }
    }
}
