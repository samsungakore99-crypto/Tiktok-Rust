package com.rustclient.core

enum class HideReason { KIND, KEYWORD, ACCOUNT, DURATION }

data class Hidden(val item: FeedItem, val reason: HideReason)

data class FilterResult(val visible: List<FeedItem>, val hidden: List<Hidden>)

interface FeedFilter {
    fun apply(items: List<FeedItem>, rules: ContentRules): FilterResult
}

/** Reference implementation. A native (Rust) engine must return identical results. */
object KotlinFeedFilter : FeedFilter {
    private val tokenSplit = Regex("[^\\p{L}\\p{N}_]+")

    override fun apply(items: List<FeedItem>, rules: ContentRules): FilterResult {
        val visible = ArrayList<FeedItem>(items.size)
        val hidden = ArrayList<Hidden>()
        for (item in items) {
            val reason = reasonToHide(item, rules)
            if (reason == null) visible += item else hidden += Hidden(item, reason)
        }
        return FilterResult(visible, hidden)
    }

    fun reasonToHide(item: FeedItem, rules: ContentRules): HideReason? {
        if (kindHidden(item.kind, rules)) return HideReason.KIND

        val author = item.author.trimStart('@').lowercase()
        if (rules.mutedAccounts.any { it.trimStart('@').lowercase() == author }) return HideReason.ACCOUNT

        if (rules.mutedWords.isNotEmpty()) {
            val caption = item.caption.lowercase()
            val tokens = caption.split(tokenSplit).filter { it.isNotEmpty() } + item.tags.map { it.trimStart('#').lowercase() }
            for (raw in rules.mutedWords) {
                val word = raw.trim().trimStart('#').lowercase()
                if (word.isEmpty()) continue
                val hit = if (word.any { it.isWhitespace() }) caption.contains(word) else word in tokens
                if (hit) return HideReason.KEYWORD
            }
        }

        if (rules.maxDurationSec > 0 && item.durationSec > rules.maxDurationSec) return HideReason.DURATION
        return null
    }

    private fun kindHidden(kind: ContentKind, r: ContentRules): Boolean = when (kind) {
        ContentKind.VIDEO -> false
        ContentKind.PHOTO -> r.hidePhotos
        ContentKind.LIVE -> r.hideLive
        ContentKind.STORY -> r.hideStories
        ContentKind.REPOST -> r.hideReposts
        ContentKind.AD -> r.hideAds
        ContentKind.FRIEND_SUGGESTION -> r.hideFriendSuggestions
        ContentKind.SHOP -> r.hideShop
    }
}
