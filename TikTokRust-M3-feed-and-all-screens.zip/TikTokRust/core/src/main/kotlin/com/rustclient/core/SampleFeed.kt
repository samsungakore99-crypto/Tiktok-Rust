package com.rustclient.core

/** Demo items used only by the live filter preview. Clearly labelled as sample data in the UI. */
object SampleFeed {
    val items: List<FeedItem> = listOf(
        FeedItem("s1", ContentKind.VIDEO, "@city.lights", "Rooftop sunset over the skyline", listOf("sunset", "city"), 24),
        FeedItem("s2", ContentKind.AD, "@sponsored", "Try the new sneakers", listOf("ad"), 15),
        FeedItem("s3", ContentKind.LIVE, "@night.radio", "Live: late night lo-fi", listOf("lofi", "live"), 0),
        FeedItem("s4", ContentKind.PHOTO, "@paper.crane", "Origami cranes, step by step", listOf("origami"), 0),
        FeedItem("s5", ContentKind.STORY, "@kai.moves", "Morning routine", emptyList(), 8),
        FeedItem("s6", ContentKind.REPOST, "@lena.draws", "Reposted: speed painting", listOf("art"), 42),
        FeedItem("s7", ContentKind.VIDEO, "@street.eats", "Best noodles in town", listOf("food"), 58),
        FeedItem("s8", ContentKind.FRIEND_SUGGESTION, "@new.friends", "People you may know", emptyList(), 0),
        FeedItem("s9", ContentKind.SHOP, "@gear.shop", "Camera straps, 20% off", listOf("shop"), 0),
        FeedItem("s10", ContentKind.VIDEO, "@long.takes", "Full album walkthrough", listOf("music"), 420),
        FeedItem("s11", ContentKind.PHOTO, "@city.lights", "Neon alley photo dump", listOf("neon", "city"), 0),
        FeedItem("s12", ContentKind.VIDEO, "@spoiler.zone", "Season finale reaction", listOf("spoilers"), 31),
        FeedItem("s13", ContentKind.REPOST, "@kai.moves", "Reposted: parkour line", listOf("parkour"), 19),
        FeedItem("s14", ContentKind.VIDEO, "@paper.crane", "Cats vs cucumbers compilation", listOf("cats"), 36),
    )
}
