package com.rustclient.core

/**
 * The seam for a native core. The app talks only to this interface; [KotlinCoreEngine] is the
 * reference implementation and a Rust-backed engine (JNI) can replace it without touching the UI.
 * Data crosses the boundary as plain values: see [SettingsCodec] for the flat-map settings shape.
 */
interface CoreEngine {
    val name: String
    fun filter(items: List<FeedItem>, rules: ContentRules): FilterResult
    fun pickVariant(variants: List<MediaVariant>, preferred: Quality, metered: Boolean, capOnCellular: Boolean): MediaVariant?
}

object KotlinCoreEngine : CoreEngine {
    override val name: String = "Kotlin"

    override fun filter(items: List<FeedItem>, rules: ContentRules): FilterResult =
        KotlinFeedFilter.apply(items, rules)

    override fun pickVariant(
        variants: List<MediaVariant>,
        preferred: Quality,
        metered: Boolean,
        capOnCellular: Boolean,
    ): MediaVariant? = QualityPolicy.pick(variants, preferred, metered, capOnCellular)
}
