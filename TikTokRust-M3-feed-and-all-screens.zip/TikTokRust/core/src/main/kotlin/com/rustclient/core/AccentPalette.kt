package com.rustclient.core

import kotlin.math.abs
import kotlin.math.pow

/** ARGB ints, so this stays free of any UI toolkit. */
data class PaletteInts(
    val deep: Int,
    val accent: Int,
    val bright: Int,
    val onAccent: Int,
    val glowA: Int,
    val glowB: Int,
    val bgTop: Int,
    val bgBottom: Int,
    val surface: Int,
)

/** Builds a complete theme from one custom accent colour. */
object AccentPalette {
    private const val WHITE = -1 // 0xFFFFFFFF

    /** Returns [hue 0..360, saturation 0..1, value 0..1]. */
    fun rgbToHsv(argb: Int): FloatArray {
        val r = (argb shr 16 and 0xFF) / 255f
        val g = (argb shr 8 and 0xFF) / 255f
        val b = (argb and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val d = max - min
        val h = when {
            d == 0f -> 0f
            max == r -> 60f * (((g - b) / d) % 6f)
            max == g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
        return floatArrayOf((h + 360f) % 360f, if (max == 0f) 0f else d / max, max)
    }

    fun hsvToRgb(h: Float, s: Float, v: Float): Int {
        val hh = ((h % 360f) + 360f) % 360f
        val c = v * s
        val x = c * (1f - abs((hh / 60f) % 2f - 1f))
        val m = v - c
        val (r, g, b) = when ((hh / 60f).toInt()) {
            0 -> Triple(c, x, 0f)
            1 -> Triple(x, c, 0f)
            2 -> Triple(0f, c, x)
            3 -> Triple(0f, x, c)
            4 -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        fun ch(f: Float) = ((f + m) * 255f + 0.5f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(r) shl 16) or (ch(g) shl 8) or ch(b)
    }

    fun luminance(argb: Int): Double {
        fun lin(c: Int): Double {
            val f = c / 255.0
            return if (f <= 0.03928) f / 12.92 else ((f + 0.055) / 1.055).pow(2.4)
        }
        return 0.2126 * lin(argb shr 16 and 0xFF) + 0.7152 * lin(argb shr 8 and 0xFF) + 0.0722 * lin(argb and 0xFF)
    }

    fun contrast(a: Int, b: Int): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }

    fun toHex(argb: Int): String = "#%06X".format(argb and 0xFFFFFF)

    fun parseHex(text: String): Int? {
        val t = text.trim().removePrefix("#")
        if (t.length != 6 || !t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
        return (0xFF shl 24) or t.toInt(16)
    }

    fun derive(argb: Int): PaletteInts {
        val hsv = rgbToHsv(argb)
        val h = hsv[0]
        val s = hsv[1].coerceIn(0.45f, 1f)
        val v = hsv[2].coerceIn(0.62f, 1f)
        val accent = hsvToRgb(h, s, v)
        val onAccent = if (contrast(accent, WHITE) >= 3.0) WHITE else hsvToRgb(h, 0.8f, 0.10f)
        return PaletteInts(
            deep = hsvToRgb(h, s, v * 0.72f),
            accent = accent,
            bright = hsvToRgb(h, s * 0.55f, 1f),
            onAccent = onAccent,
            glowA = accent,
            glowB = hsvToRgb(h + 18f, 0.8f, 0.5f),
            bgTop = hsvToRgb(h, 0.75f, 0.10f),
            bgBottom = hsvToRgb(h, 0.60f, 0.035f),
            surface = hsvToRgb(h, 0.35f, 0.115f),
        )
    }
}
