package com.rustclient.core

data class SearchResult(val accounts: List<String>, val posts: List<FeedItem>)

/** Account / tag / text search over feed items. Pure logic, so a native core can reproduce it exactly. */
object SearchEngine {
    /** Distinct author handles (without "@"), in order of first appearance. Ads and suggestion blocks are not accounts. */
    fun accounts(items: List<FeedItem>): List<String> =
        items.filter { it.kind != ContentKind.AD && it.kind != ContentKind.FRIEND_SUGGESTION }
            .map { it.author.trimStart('@') }
            .distinct()

    /** Most used tags, most frequent first, ties alphabetical. */
    fun popularTags(items: List<FeedItem>, limit: Int = 8): List<String> {
        val counts = HashMap<String, Int>()
        for (item in items) {
            for (tag in item.tags) {
                val t = tag.trimStart('#').lowercase()
                if (t.isNotEmpty() && t != "ad") counts[t] = (counts[t] ?: 0) + 1
            }
        }
        return counts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(limit)
            .map { it.key }
    }

    fun search(items: List<FeedItem>, query: String): SearchResult {
        val q = query.trim().trimStart('#', '@').lowercase()
        if (q.isEmpty()) return SearchResult(emptyList(), emptyList())
        val posts = items.filter { item ->
            item.kind != ContentKind.AD && item.kind != ContentKind.FRIEND_SUGGESTION &&
                (item.caption.lowercase().contains(q) || item.author.lowercase().contains(q) || item.tags.any { it.lowercase().contains(q) })
        }
        return SearchResult(accounts(items).filter { it.lowercase().contains(q) }, posts)
    }
}
