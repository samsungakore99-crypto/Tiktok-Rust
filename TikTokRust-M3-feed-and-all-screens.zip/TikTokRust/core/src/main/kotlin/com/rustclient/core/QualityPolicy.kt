package com.rustclient.core

object QualityPolicy {
    /** Height cap applied on metered (mobile) networks when the data saver is on. */
    const val CELLULAR_CAP = 480

    fun effectiveCap(preferred: Quality, metered: Boolean, capOnCellular: Boolean): Int {
        var cap = if (preferred == Quality.AUTO) Int.MAX_VALUE else preferred.height
        if (metered && capOnCellular) cap = minOf(cap, CELLULAR_CAP)
        return cap
    }

    /** Best variant not taller than [cap]; if every variant is taller, the smallest one. */
    fun pick(variants: List<MediaVariant>, cap: Int): MediaVariant? {
        if (variants.isEmpty()) return null
        return variants.filter { it.height <= cap }.maxByOrNull { it.height } ?: variants.minByOrNull { it.height }
    }

    fun pick(variants: List<MediaVariant>, preferred: Quality, metered: Boolean, capOnCellular: Boolean): MediaVariant? =
        pick(variants, effectiveCap(preferred, metered, capOnCellular))
}
