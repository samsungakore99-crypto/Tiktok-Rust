package com.rustclient.core

import kotlin.math.abs

/**
 * Flat string map <-> [AppSettings]. DataStore stores the map; the same shape can cross a JNI
 * boundary unchanged, which keeps the persistence layer ready for a native (Rust) core.
 * Unknown / corrupt values fall back to defaults, so old installs never crash on new keys.
 */
object SettingsCodec {
    private const val SEP = '\u001F'

    val speeds: List<Float> = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    val durations: List<Int> = listOf(0, 60, 180, 600)

    fun encode(s: AppSettings): Map<String, String> = linkedMapOf(
        "profile.name" to s.profile.displayName,
        "profile.handle" to s.profile.handle,
        "profile.bio" to s.profile.bio,
        "profile.avatarRev" to s.profile.avatarRev.toString(),
        "appearance.theme" to s.appearance.themeId,
        "appearance.accent" to s.appearance.customAccent.toString(),
        "appearance.animatedBg" to s.appearance.animatedBackground.toString(),
        "appearance.tabLabels" to s.appearance.showTabLabels.toString(),
        "appearance.haptics" to s.appearance.haptics.toString(),
        "content.hideAds" to s.content.hideAds.toString(),
        "content.hideLive" to s.content.hideLive.toString(),
        "content.hidePhotos" to s.content.hidePhotos.toString(),
        "content.hideStories" to s.content.hideStories.toString(),
        "content.hideReposts" to s.content.hideReposts.toString(),
        "content.hideFriends" to s.content.hideFriendSuggestions.toString(),
        "content.hideShop" to s.content.hideShop.toString(),
        "content.words" to s.content.mutedWords.joinToString(SEP.toString()),
        "content.accounts" to s.content.mutedAccounts.joinToString(SEP.toString()),
        "content.maxDuration" to s.content.maxDurationSec.toString(),
        "player.autoplay" to s.player.autoplay.toString(),
        "player.loop" to s.player.loop.toString(),
        "player.speed" to s.player.speed.toString(),
        "player.muted" to s.player.muted.toString(),
        "player.fit" to s.player.fit.name,
        "player.progress" to s.player.showProgress.toString(),
        "player.keepOn" to s.player.keepScreenOn.toString(),
        "player.tapPause" to s.player.tapToPause.toString(),
        "player.doubleTap" to s.player.doubleTapSeek.toString(),
        "player.quality" to s.player.maxQuality.name,
        "player.cellularCap" to s.player.capOnCellular.toString(),
        "downloads.video" to s.downloads.allowVideo.toString(),
        "downloads.photo" to s.downloads.allowPhoto.toString(),
        "downloads.quality" to s.downloads.quality.name,
        "downloads.location" to s.downloads.location.name,
        "downloads.folder" to s.downloads.folder,
        "downloads.wifiOnly" to s.downloads.wifiOnly.toString(),
        "privacy.secure" to s.privacy.secureWindow.toString(),
        "privacy.history" to s.privacy.keepHistory.toString(),
        "notif.progress" to s.notifications.progress.toString(),
        "notif.done" to s.notifications.done.toString(),
        "perf.reduce" to s.performance.reduceMotion.toString(),
        "perf.auto" to s.performance.autoReduceOnBatterySaver.toString(),
        "perf.fps" to s.performance.showFps.toString(),
    )

    fun decode(m: Map<String, String>): AppSettings {
        val d = AppSettings()
        fun b(k: String, def: Boolean) = m[k]?.toBooleanStrictOrNull() ?: def
        fun i(k: String, def: Int) = m[k]?.toIntOrNull() ?: def
        fun s(k: String, def: String) = m[k] ?: def
        fun l(k: String, def: List<String>): List<String> =
            m[k]?.let { v -> if (v.isEmpty()) emptyList() else v.split(SEP) } ?: def

        return AppSettings(
            profile = ProfilePrefs(
                displayName = cleanName(s("profile.name", d.profile.displayName), d.profile.displayName),
                handle = cleanHandle(s("profile.handle", d.profile.handle), d.profile.handle),
                bio = cleanBio(s("profile.bio", d.profile.bio)),
                avatarRev = i("profile.avatarRev", d.profile.avatarRev).coerceAtLeast(0),
            ),
            appearance = AppearancePrefs(
                themeId = s("appearance.theme", d.appearance.themeId),
                customAccent = i("appearance.accent", d.appearance.customAccent),
                animatedBackground = b("appearance.animatedBg", d.appearance.animatedBackground),
                showTabLabels = b("appearance.tabLabels", d.appearance.showTabLabels),
                haptics = b("appearance.haptics", d.appearance.haptics),
            ),
            content = ContentRules(
                hideAds = b("content.hideAds", d.content.hideAds),
                hideLive = b("content.hideLive", d.content.hideLive),
                hidePhotos = b("content.hidePhotos", d.content.hidePhotos),
                hideStories = b("content.hideStories", d.content.hideStories),
                hideReposts = b("content.hideReposts", d.content.hideReposts),
                hideFriendSuggestions = b("content.hideFriends", d.content.hideFriendSuggestions),
                hideShop = b("content.hideShop", d.content.hideShop),
                mutedWords = cleanList(l("content.words", d.content.mutedWords)),
                mutedAccounts = cleanList(l("content.accounts", d.content.mutedAccounts)),
                maxDurationSec = nearest(durations, i("content.maxDuration", 0)),
            ),
            player = PlayerPrefs(
                autoplay = b("player.autoplay", d.player.autoplay),
                loop = b("player.loop", d.player.loop),
                speed = nearestSpeed(m["player.speed"]?.toFloatOrNull() ?: d.player.speed),
                muted = b("player.muted", d.player.muted),
                fit = pick(m["player.fit"], FitMode.entries, d.player.fit),
                showProgress = b("player.progress", d.player.showProgress),
                keepScreenOn = b("player.keepOn", d.player.keepScreenOn),
                tapToPause = b("player.tapPause", d.player.tapToPause),
                doubleTapSeek = b("player.doubleTap", d.player.doubleTapSeek),
                maxQuality = pick(m["player.quality"], Quality.entries, d.player.maxQuality),
                capOnCellular = b("player.cellularCap", d.player.capOnCellular),
            ),
            downloads = DownloadPrefs(
                allowVideo = b("downloads.video", d.downloads.allowVideo),
                allowPhoto = b("downloads.photo", d.downloads.allowPhoto),
                quality = pick(m["downloads.quality"], Quality.entries, d.downloads.quality),
                location = pick(m["downloads.location"], SaveLocation.entries, d.downloads.location),
                folder = DownloadPolicy.safeFolder(s("downloads.folder", d.downloads.folder)),
                wifiOnly = b("downloads.wifiOnly", d.downloads.wifiOnly),
            ),
            privacy = PrivacyPrefs(
                secureWindow = b("privacy.secure", d.privacy.secureWindow),
                keepHistory = b("privacy.history", d.privacy.keepHistory),
            ),
            notifications = NotificationPrefs(
                progress = b("notif.progress", d.notifications.progress),
                done = b("notif.done", d.notifications.done),
            ),
            performance = PerformancePrefs(
                reduceMotion = b("perf.reduce", d.performance.reduceMotion),
                autoReduceOnBatterySaver = b("perf.auto", d.performance.autoReduceOnBatterySaver),
                showFps = b("perf.fps", d.performance.showFps),
            ),
        )
    }

    private fun <E : Enum<E>> pick(v: String?, all: List<E>, def: E): E = all.firstOrNull { it.name == v } ?: def

    private fun nearest(options: List<Int>, v: Int): Int = options.minByOrNull { abs(it - v) } ?: options.first()

    private fun nearestSpeed(v: Float): Float = speeds.minByOrNull { abs(it - v) } ?: 1f

    fun cleanName(raw: String, fallback: String = "TikTok Rust"): String =
        raw.filter { !it.isISOControl() }.trim().take(32).ifBlank { fallback }

    fun cleanHandle(raw: String, fallback: String = "tiktok_rust"): String =
        raw.lowercase().filter { it in 'a'..'z' || it in '0'..'9' || it == '_' || it == '.' }.take(24).ifBlank { fallback }

    fun cleanBio(raw: String): String = raw.filter { !it.isISOControl() || it == '\n' }.trim().take(120)

    /** One muted word / account: no control chars, no leading #/@, at most 40 chars. */
    fun cleanWord(raw: String): String =
        raw.filter { !it.isISOControl() }.trim().trimStart('#', '@').trim().take(40)

    private fun cleanList(list: List<String>): List<String> =
        list.map { cleanWord(it) }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }.take(50)
}
