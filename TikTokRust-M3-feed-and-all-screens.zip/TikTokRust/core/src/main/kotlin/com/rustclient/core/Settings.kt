package com.rustclient.core

enum class Quality(val height: Int) { AUTO(0), P360(360), P480(480), P720(720), P1080(1080) }
enum class FitMode { FIT, FILL, ZOOM }
enum class SaveLocation { GALLERY, DOWNLOADS }

data class ProfilePrefs(
    val displayName: String = "TikTok Rust",
    val handle: String = "tiktok_rust",
    val bio: String = "",
    val avatarRev: Int = 0,
)

data class AppearancePrefs(
    val themeId: String = "midnight",
    val customAccent: Int = 0xFF7B3CFC.toInt(),
    val animatedBackground: Boolean = true,
    val showTabLabels: Boolean = true,
    val haptics: Boolean = true,
)

data class ContentRules(
    val hideAds: Boolean = true,
    val hideLive: Boolean = false,
    val hidePhotos: Boolean = false,
    val hideStories: Boolean = false,
    val hideReposts: Boolean = false,
    val hideFriendSuggestions: Boolean = false,
    val hideShop: Boolean = false,
    val mutedWords: List<String> = emptyList(),
    val mutedAccounts: List<String> = emptyList(),
    val maxDurationSec: Int = 0,
)

data class PlayerPrefs(
    val autoplay: Boolean = true,
    val loop: Boolean = true,
    val speed: Float = 1f,
    val muted: Boolean = false,
    val fit: FitMode = FitMode.FIT,
    val showProgress: Boolean = true,
    val keepScreenOn: Boolean = true,
    val tapToPause: Boolean = true,
    val doubleTapSeek: Boolean = true,
    val maxQuality: Quality = Quality.AUTO,
    val capOnCellular: Boolean = true,
)

data class DownloadPrefs(
    val allowVideo: Boolean = true,
    val allowPhoto: Boolean = true,
    val quality: Quality = Quality.AUTO,
    val location: SaveLocation = SaveLocation.GALLERY,
    val folder: String = "TikTokRust",
    val wifiOnly: Boolean = false,
)

data class PrivacyPrefs(val secureWindow: Boolean = false, val keepHistory: Boolean = true)
data class NotificationPrefs(val progress: Boolean = true, val done: Boolean = true)
data class PerformancePrefs(
    val reduceMotion: Boolean = false,
    val autoReduceOnBatterySaver: Boolean = true,
    val showFps: Boolean = true,
)

data class AppSettings(
    val profile: ProfilePrefs = ProfilePrefs(),
    val appearance: AppearancePrefs = AppearancePrefs(),
    val content: ContentRules = ContentRules(),
    val player: PlayerPrefs = PlayerPrefs(),
    val downloads: DownloadPrefs = DownloadPrefs(),
    val privacy: PrivacyPrefs = PrivacyPrefs(),
    val notifications: NotificationPrefs = NotificationPrefs(),
    val performance: PerformancePrefs = PerformancePrefs(),
)
