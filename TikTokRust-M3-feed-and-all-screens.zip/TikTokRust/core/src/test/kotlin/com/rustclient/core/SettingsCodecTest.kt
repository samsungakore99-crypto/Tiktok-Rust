package com.rustclient.core

import org.junit.Assert.assertEquals
import org.junit.Test

class SettingsCodecTest {
    @Test fun defaultsRoundTrip() = assertEquals(AppSettings(), SettingsCodec.decode(SettingsCodec.encode(AppSettings())))

    @Test fun customisedRoundTrip() {
        val s = AppSettings(
            profile = ProfilePrefs("Kai", "kai.moves", "hi\nthere", 3),
            appearance = AppearancePrefs("custom", 0xFF22AA88.toInt(), animatedBackground = false, showTabLabels = false, haptics = false),
            content = ContentRules(hideLive = true, hidePhotos = true, mutedWords = listOf("spoilers", "step by step"), mutedAccounts = listOf("kai"), maxDurationSec = 180),
            player = PlayerPrefs(autoplay = false, loop = false, speed = 1.5f, muted = true, fit = FitMode.ZOOM, maxQuality = Quality.P720, capOnCellular = false),
            downloads = DownloadPrefs(allowPhoto = false, quality = Quality.P480, location = SaveLocation.DOWNLOADS, folder = "My Clips", wifiOnly = true),
            privacy = PrivacyPrefs(secureWindow = true, keepHistory = false),
            notifications = NotificationPrefs(progress = false, done = true),
            performance = PerformancePrefs(reduceMotion = true, autoReduceOnBatterySaver = false, showFps = false),
        )
        assertEquals(s, SettingsCodec.decode(SettingsCodec.encode(s)))
    }

    @Test fun corruptValuesFallBackToSafeDefaults() {
        val s = SettingsCodec.decode(
            mapOf("player.speed" to "9.9", "player.fit" to "BOGUS", "content.maxDuration" to "x", "downloads.folder" to "../..", "profile.handle" to "!!", "profile.name" to " "),
        )
        assertEquals(2f, s.player.speed)
        assertEquals(FitMode.FIT, s.player.fit)
        assertEquals(0, s.content.maxDurationSec)
        assertEquals("TikTokRust", s.downloads.folder)
        assertEquals("tiktok_rust", s.profile.handle)
        assertEquals("TikTok Rust", s.profile.displayName)
    }

    @Test fun wordListsAreCleanedAndDeduplicated() {
        val s = SettingsCodec.decode(mapOf("content.words" to "#Spoilers\u001Fspoilers\u001F \u001F@kai"))
        assertEquals(listOf("Spoilers", "kai"), s.content.mutedWords)
    }
}
