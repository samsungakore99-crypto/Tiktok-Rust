package com.rustclient.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchTest {
    private val items = SampleFeed.items

    @Test fun accountsAreDistinctAndExcludeAdsAndSuggestions() {
        val a = SearchEngine.accounts(items)
        assertEquals(9, a.size)
        assertTrue("sponsored" !in a && "new.friends" !in a)
        assertEquals("city.lights", a.first())
    }

    @Test fun popularTagsAreOrderedByFrequencyThenName() {
        val tags = SearchEngine.popularTags(items, 3)
        assertEquals(3, tags.size)
        assertEquals("city", tags.first())
        assertTrue("ad" !in SearchEngine.popularTags(items, 50))
    }

    @Test fun searchMatchesTagsAuthorsAndCaptions() {
        assertEquals(listOf("s14"), SearchEngine.search(items, "cats").posts.map { it.id })
        val kai = SearchEngine.search(items, "@kai")
        assertEquals(listOf("kai.moves"), kai.accounts)
        assertEquals(listOf("s5", "s13"), kai.posts.map { it.id })
        assertEquals(listOf("s11"), SearchEngine.search(items, "neon").posts.map { it.id })
    }

    @Test fun adsNeverAppearAndBlankQueryIsEmpty() {
        assertTrue(SearchEngine.search(items, "sneakers").posts.isEmpty())
        val empty = SearchEngine.search(items, "  ")
        assertTrue(empty.accounts.isEmpty() && empty.posts.isEmpty())
    }
}
