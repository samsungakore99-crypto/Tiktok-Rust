package com.rustclient.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadPolicyTest {
    @Test fun acceptsDirectHttpsMedia() {
        val ok = DownloadPolicy.check("https://example.com/media/My%20Clip.mp4") as UrlCheck.Ok
        assertEquals(MediaKind.VIDEO, ok.kind)
        assertEquals("My Clip.mp4", ok.fileName)
        assertEquals(MediaKind.PHOTO, (DownloadPolicy.check("https://example.com/a.JPG") as UrlCheck.Ok).kind)
    }

    @Test fun unknownExtensionNeedsProbe() = assertNull((DownloadPolicy.check("https://example.com/get?id=7") as UrlCheck.Ok).kind)

    @Test fun rejections() {
        assertEquals(Rejection.EMPTY, (DownloadPolicy.check("  ") as UrlCheck.Rejected).reason)
        assertEquals(Rejection.NOT_HTTPS, (DownloadPolicy.check("http://example.com/a.mp4") as UrlCheck.Rejected).reason)
        assertEquals(Rejection.INVALID, (DownloadPolicy.check("not a url") as UrlCheck.Rejected).reason)
        assertEquals(Rejection.INVALID, (DownloadPolicy.check("ftp://example.com/a.mp4") as UrlCheck.Rejected).reason)
    }

    @Test fun tiktokHostsAreRefused() {
        for (u in listOf("https://www.tiktok.com/@a/video/1", "https://vm.tiktok.com/abc/", "https://v16.tiktokcdn.com/x.mp4", "http://m.tiktok.com/v/1")) {
            assertEquals(u, Rejection.TIKTOK_HOST, (DownloadPolicy.check(u) as UrlCheck.Rejected).reason)
        }
        assertTrue(!DownloadPolicy.isBlockedHost("nottiktok.com"))
    }

    @Test fun mimeAndNames() {
        assertEquals(MediaKind.VIDEO, DownloadPolicy.kindFromMime("video/mp4; charset=x"))
        assertEquals(MediaKind.PHOTO, DownloadPolicy.kindFromMime("image/png"))
        assertNull(DownloadPolicy.kindFromMime("application/octet-stream"))
        assertEquals("a_b_c.mp4", DownloadPolicy.safeFileName("a/b\\c.mp4", "x"))
        assertEquals("x", DownloadPolicy.safeFileName("...", "x"))
        assertEquals("clip.mp4", DownloadPolicy.withExtension("clip", "mp4"))
        assertEquals("clip.mp4", DownloadPolicy.withExtension("clip.mp4", "mp4"))
        assertEquals("TikTokRust", DownloadPolicy.safeFolder("../.."))
        assertEquals("My Clips", DownloadPolicy.safeFolder("My Clips"))
    }
}
