package com.rustclient.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class AccentPaletteTest {
    @Test fun hsvRoundTrip() {
        for (c in listOf(0xFF7B3CFC.toInt(), 0xFF22C55E.toInt(), 0xFFE11D48.toInt(), 0xFFF5C451.toInt())) {
            val hsv = AccentPalette.rgbToHsv(c)
            val back = AccentPalette.hsvToRgb(hsv[0], hsv[1], hsv[2])
            for (shift in listOf(16, 8, 0)) assertTrue(abs((c shr shift and 0xFF) - (back shr shift and 0xFF)) <= 1)
        }
    }

    @Test fun hexParsing() {
        assertEquals(0xFF7B3CFC.toInt(), AccentPalette.parseHex("#7b3cfc"))
        assertNull(AccentPalette.parseHex("#12345"))
        assertNull(AccentPalette.parseHex("zzzzzz"))
        assertEquals("#7B3CFC", AccentPalette.toHex(0xFF7B3CFC.toInt()))
    }

    @Test fun derivedPaletteKeepsHueAndIsReadable() {
        for (c in listOf(0xFF7B3CFC.toInt(), 0xFF22C55E.toInt(), 0xFFFFE066.toInt(), 0xFF808080.toInt(), 0xFF000000.toInt())) {
            val p = AccentPalette.derive(c)
            assertTrue("button text must be readable", AccentPalette.contrast(p.accent, p.onAccent) >= 3.0)
            assertTrue("background must stay dark", AccentPalette.luminance(p.bgBottom) < 0.02)
            assertTrue(AccentPalette.luminance(p.bright) > AccentPalette.luminance(p.deep))
        }
    }
}
