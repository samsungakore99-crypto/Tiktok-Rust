package com.rustclient.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FeedFilterTest {
    private val items = SampleFeed.items

    private fun hiddenIds(rules: ContentRules) = KotlinFeedFilter.apply(items, rules).hidden.map { it.item.id }.toSet()

    @Test fun defaultsHideOnlyAds() = assertEquals(setOf("s2"), hiddenIds(ContentRules()))

    @Test fun kindToggles() {
        val r = ContentRules(hideAds = false, hideLive = true, hidePhotos = true, hideStories = true, hideReposts = true, hideFriendSuggestions = true, hideShop = true)
        assertEquals(setOf("s3", "s4", "s11", "s5", "s6", "s13", "s8", "s9"), hiddenIds(r))
    }

    @Test fun nothingHiddenWhenAllOff() = assertTrue(hiddenIds(ContentRules(hideAds = false)).isEmpty())

    @Test fun mutedWordMatchesTagsAndWholeWordsOnly() {
        assertEquals(setOf("s12"), hiddenIds(ContentRules(hideAds = false, mutedWords = listOf("#spoilers"))))
        assertTrue(hiddenIds(ContentRules(hideAds = false, mutedWords = listOf("cat"))).isEmpty()) // "cats" is a different word
        assertEquals(setOf("s14"), hiddenIds(ContentRules(hideAds = false, mutedWords = listOf("cats"))))
    }

    @Test fun mutedPhrase() =
        assertEquals(setOf("s4"), hiddenIds(ContentRules(hideAds = false, mutedWords = listOf("step by step"))))

    @Test fun mutedAccountIgnoresAtSignAndCase() =
        assertEquals(setOf("s5", "s13"), hiddenIds(ContentRules(hideAds = false, mutedAccounts = listOf("@Kai.Moves"))))

    @Test fun maxDuration() =
        assertEquals(setOf("s10"), hiddenIds(ContentRules(hideAds = false, maxDurationSec = 180)))

    @Test fun reasonIsReported() {
        val res = KotlinFeedFilter.apply(items, ContentRules(hideAds = true, maxDurationSec = 60))
        assertEquals(HideReason.KIND, res.hidden.first { it.item.id == "s2" }.reason)
        assertEquals(HideReason.DURATION, res.hidden.first { it.item.id == "s10" }.reason)
        assertNull(KotlinFeedFilter.reasonToHide(items.first { it.id == "s1" }, ContentRules()))
    }

    @Test fun visibleAndHiddenPartitionTheInput() {
        val res = KotlinFeedFilter.apply(items, ContentRules(hideLive = true, hidePhotos = true))
        assertEquals(items.size, res.visible.size + res.hidden.size)
    }
}
