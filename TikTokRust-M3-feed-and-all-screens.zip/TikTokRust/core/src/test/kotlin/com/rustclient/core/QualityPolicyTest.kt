package com.rustclient.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class QualityPolicyTest {
    private val v = listOf(MediaVariant("a", 360), MediaVariant("b", 720), MediaVariant("c", 1080))

    @Test fun autoPicksHighest() = assertEquals(1080, QualityPolicy.pick(v, Quality.AUTO, false, true)?.height)

    @Test fun capPicksBestNotTaller() = assertEquals(720, QualityPolicy.pick(v, Quality.P720, false, true)?.height)

    @Test fun cellularCapAppliesOnlyWhenMeteredAndEnabled() {
        assertEquals(360, QualityPolicy.pick(v, Quality.AUTO, true, true)?.height) // 480 cap -> best <= 480 is 360
        assertEquals(1080, QualityPolicy.pick(v, Quality.AUTO, true, false)?.height)
        assertEquals(1080, QualityPolicy.pick(v, Quality.AUTO, false, true)?.height)
    }

    @Test fun fallsBackToSmallestWhenAllTooTall() =
        assertEquals(720, QualityPolicy.pick(listOf(MediaVariant("x", 720), MediaVariant("y", 1080)), Quality.P360, false, true)?.height)

    @Test fun emptyVariants() = assertNull(QualityPolicy.pick(emptyList(), Quality.AUTO, false, true))
}
