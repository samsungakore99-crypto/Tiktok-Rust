# Rust core (skeleton)

The app never talks to native code directly. Everything goes through `CoreEngine`
(`core/src/main/kotlin/com/rustclient/core/CoreEngine.kt`); `Engines.current` decides which
implementation runs. Today that is `KotlinCoreEngine`.

## What a Rust engine has to do
`CoreEngine` has two operations:

| Operation | Input | Output |
|---|---|---|
| `filter(items, rules)` | feed items + `ContentRules` | visible items, hidden items with a reason (KIND / KEYWORD / ACCOUNT / DURATION) |
| `pickVariant(variants, preferred, metered, capOnCellular)` | renditions + preferences | the chosen rendition or none |

Settings cross the boundary as the flat `Map<String, String>` produced by `SettingsCodec.encode`.
The Kotlin unit tests in `core/src/test` are the behavioural spec: run the same fixtures
against the native engine and require identical results.

## Build
```
cargo install cargo-ndk
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
cd rust
cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o ../app/src/main/jniLibs build --release
```
Once `librustcore.so` is packaged, `RustBridge.isAvailable` becomes true and the Performance
screen shows the native version. To route work through Rust, add a `RustCoreEngine : CoreEngine`
(JNI wrapper) and set `Engines.current = RustCoreEngine`.

Status: only `nativeVersion()` exists. The crate has not been compiled yet.
