//! Native core skeleton. It is NOT wired into the Gradle build and was not compiled in the
//! environment this milestone was written in; it exists to fix the JNI naming and the layout.

use jni::objects::JClass;
use jni::sys::jstring;
use jni::JNIEnv;

/// Bound to `com.rustclient.app.rust.RustBridge.nativeVersion()`.
#[no_mangle]
pub extern "system" fn Java_com_rustclient_app_rust_RustBridge_nativeVersion(
    mut env: JNIEnv,
    _class: JClass,
) -> jstring {
    env.new_string(env!("CARGO_PKG_VERSION"))
        .expect("failed to create Java string")
        .into_raw()
}
